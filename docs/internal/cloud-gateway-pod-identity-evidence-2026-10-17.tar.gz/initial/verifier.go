// Package gatewaypodidentity verifies current Kubernetes Pod identity through an
// explicitly configured Kubernetes API. It does not grant product authority.
package gatewaypodidentity

import (
	"context"
	"errors"
	"fmt"
	"time"
)

const Profile = "kubernetes-tokenreview-pod-v1"
const MaximumCalls = 13
const MaximumStageDuration = 5 * time.Second

var ErrDenied = errors.New("pod identity denied")

// Config contains operator-selected trust. ReviewerCredentialFile is reread for
// each verification and must be a protected current-user-owned regular file.
type Config struct {
	IntegrationID          string
	Endpoint               string
	CABundlePEM            []byte
	AllowedCIDRs           []string
	ClusterUID             string
	Audience               string
	Namespace              string
	ReviewerCredentialFile string
}

// RequestBinding binds the observation digest to the exact caller request.
type RequestBinding struct{ RequestID, Method, ExactTarget, BodySHA256 string }

// Proof has no token accessor. All formatting is redacted.
type Proof struct {
	token   []byte
	binding RequestBinding
}

func (Proof) String() string                                       { return "[redacted pod proof]" }
func (Proof) GoString() string                                     { return "[redacted pod proof]" }
func (Proof) Format(s fmt.State, verb rune)                        { _, _ = s.Write([]byte("[redacted pod proof]")) }
func NewProof(token []byte, binding RequestBinding) (Proof, error) { return Proof{}, ErrDenied }

type VerifiedPod struct {
	Profile, IntegrationID, ClusterUID, Namespace          string
	ServiceAccountName, ServiceAccountUID, PodName, PodUID string
	ReplicaSetUID, DeploymentUID, NodeUID, BootID          string
	ObservedAt, TokenExpiresAt, ExpiresAt                  time.Time
	FactsSHA256                                            string
}

// Verifier owns the pinned transport. Closing it prevents further observations.
type Verifier struct{}

func New(config Config) (*Verifier, error) { return nil, ErrDenied }
func (*Verifier) Verify(ctx context.Context, proof Proof) (VerifiedPod, error) {
	return VerifiedPod{}, ErrDenied
}

// Ready checks local configuration/credential readiness, without a provider call.
func (*Verifier) Ready(ctx context.Context) error { return ErrDenied }
func (*Verifier) Close() error                    { return nil }
