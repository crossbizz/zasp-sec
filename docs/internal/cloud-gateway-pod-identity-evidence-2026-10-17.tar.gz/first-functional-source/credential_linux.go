//go:build linux

package gatewaypodidentity

import (
	"io"
	"os"
	"path/filepath"
	"syscall"
)

// Reopen every time to observe operator rotation. No file bytes or OS error
// messages escape the verifier. The parent directory is operator trust.
func reviewerCredential(path string) ([]byte, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return nil, ErrDenied
	}
	f, e := os.OpenFile(path, os.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_NONBLOCK, 0)
	if e != nil {
		return nil, ErrDenied
	}
	defer f.Close()
	stat, e := f.Stat()
	if e != nil {
		return nil, ErrDenied
	}
	native, ok := stat.Sys().(*syscall.Stat_t)
	if !ok || !stat.Mode().IsRegular() || stat.Mode().Perm() != 0600 || stat.Mode()&(os.ModeSetuid|os.ModeSetgid|os.ModeSticky) != 0 || native.Uid != uint32(os.Getuid()) || native.Nlink != 1 || stat.Size() < 1 || stat.Size() > 16384 {
		return nil, ErrDenied
	}
	raw, e := io.ReadAll(io.LimitReader(f, 16385))
	after, e2 := f.Stat()
	pathStat, e3 := os.Lstat(path)
	if e != nil || e2 != nil || e3 != nil || !os.SameFile(stat, after) || !os.SameFile(stat, pathStat) || after.Mode() != stat.Mode() || after.Size() != stat.Size() || !after.ModTime().Equal(stat.ModTime()) || !bearer(raw, 16384) {
		clear(raw)
		return nil, ErrDenied
	}
	return raw, nil
}
