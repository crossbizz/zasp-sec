import hashlib, json, os, subprocess, sys, tempfile
from pathlib import Path
phase = 'source-before'
observed_test = 'none'
def report_failure(kind, value, traceback):
    # Fixed phases and allowlisted test heads only; no exception text,
    # tokens, environment values or untrusted provider bodies in annotations.
    print(f'::error title=Gateway component verification failed::phase={phase}; test={observed_test}; exception={kind.__name__}', flush=True)
    sys.__excepthook__(kind, value, traceback)
sys.excepthook = report_failure
package = 'github.com/zasp-ai/zasp-sec/services/gatewaypodidentity'
heads = {
    'TestProjectedPodIdentityThirteenCallChain',
    'TestProjectedPodIdentityAuthenticatedClaimsAndJSON',
    'TestProjectedPodIdentityCurrentOwnershipAndDoubleRead',
    'TestProjectedPodIdentityTransportBoundsAndDeadline',
    'TestProjectedPodIdentitySecretReadinessAndLifecycle',
    'TestReviewerPublisherProjectedRotationAndConsumer',
    'TestReviewerPublisherSourceAndDestinationSafety',
    'TestReviewerPublisherCancellationExpiryAndOwnership',
}
def check_sources():
    manifest = json.loads(Path('.github/connector-native-compile-source-pins.json').read_text())
    paths = [entry['path'] for entry in manifest['sources']]
    assert len(paths) == len(set(paths))
    required = {str(p) for p in Path('services/gatewaypodidentity').rglob('*.go')}
    required.update({'services/gatewaypodidentity/go.mod', '.github/workflows/gateway-pod-identity-components.yml'})
    assert required.issubset(paths)
    for entry in manifest['sources']:
        raw = Path(entry['path']).read_bytes()
        assert len(raw) == entry['bytes'], entry['path']
        assert hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
check_sources()
phase = 'grouped-tests'
with tempfile.TemporaryFile() as output:
    result = subprocess.run(['go', 'test', '-C', 'services/gatewaypodidentity', '-race', '-p', '1', '-count=1', '-timeout=45s', '-json', '.'], stdout=output, stderr=subprocess.STDOUT)
    output.seek(0)
    counts = {name: {'run': 0, 'pass': 0} for name in heads}
    lifecycle = {'start': 0, 'pass': 0}
    for raw in output:
        print(raw.decode('utf-8', errors='strict'), end='')
        event = json.loads(raw)
        observed_test = event.get('Test') if event.get('Test') in heads else 'none-or-unrecognized'
        assert event.get('Package') == package
        assert event.get('Action') in {'start', 'run', 'pass', 'output'}
        if 'Test' in event:
            assert event['Action'] in {'run', 'pass', 'output'} and event['Test'] in counts
            if event['Action'] in {'run', 'pass'}:
                counts[event['Test']][event['Action']] += 1
        else:
            assert event['Action'] in {'start', 'pass', 'output'}
            if event['Action'] in lifecycle:
                lifecycle[event['Action']] += 1
    assert result.returncode == 0 and lifecycle == {'start': 1, 'pass': 1}
    assert all(count == {'run': 1, 'pass': 1} for count in counts.values()), counts
# The original package and all eight grouped checks run above. The new
# thin operator command is compiled separately; no CLI test PASS is invented.
phase = 'command-compilation'
observed_test = 'none'
with tempfile.TemporaryDirectory() as directory:
    command = subprocess.run(['go', 'build', '-C', 'services/gatewaypodidentity', '-o', str(Path(directory) / 'gateway-reviewer-publisher'), './cmd/gateway-reviewer-publisher'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=90)
    print(command.stdout.decode('utf-8', errors='strict'), end='')
    assert command.returncode == 0, 'reviewer publisher command compilation failed'
phase = 'source-after'
check_sources()
print('Eight configured-provider and publisher component groups passed; command compiled; native and deployed acceptance remain separate.')
