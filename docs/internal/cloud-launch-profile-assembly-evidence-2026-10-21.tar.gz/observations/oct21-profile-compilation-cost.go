package main
import("encoding/json";"os";"runtime";"time";"github.com/zasp-ai/zasp-sec/services/platform/migrations")
func main(){
 type Row struct{Name string `json:"name"`;ElapsedMS int64 `json:"elapsed_ms"`;AllocatedBytes uint64 `json:"allocated_bytes"`;Pin string `json:"pin"`;OK bool `json:"ok"`}
 rows:=[]Row{}
 for _, round:=range []string{"first","repeat"}{
  for _, call:=range []struct{name string;fn func()(string,error)}{{"activation",migrations.ApprovalActivationProfileChecksum},{"settlement",migrations.ApprovalSettlementAuditProfileChecksum}}{
   var before,after runtime.MemStats;runtime.ReadMemStats(&before);started:=time.Now();pin,err:=call.fn();runtime.ReadMemStats(&after);rows=append(rows,Row{round+"-"+call.name,time.Since(started).Milliseconds(),after.TotalAlloc-before.TotalAlloc,pin,err==nil});if err!=nil{json.NewEncoder(os.Stdout).Encode(rows);os.Exit(1)}
  }
 }
 json.NewEncoder(os.Stdout).Encode(rows)
}
