from pathlib import Path
import csv,io,json,hashlib,collections
root=Path('/workspace/zasp-node-coverage-retention')
p=root/'docs/internal/implementation_production_availability_v1.5.tsv'
before=p.read_bytes(); rows=list(csv.DictReader(io.StringIO(before.decode()),delimiter='\t'))
assert len(rows)==728 and len({x['id'] for x in rows})==728
assert collections.Counter(x['production_class'] for x in rows)=={'production-available':509,'component-only':158,'blocked/external':61}
notes={
'M8-05':'2026-10-21 existing OpenRouter secret-read/decrypt release contract now checks exact namespace, key, service and encryption context; Terraform/runtime permissions unchanged; selected component RED/GREEN only',
'M8-08b':'2026-10-21 fresh connector/approval profile assembly renders enforcement once per invocation, reducing activation/settlement allocations about66percent with byte-identical SQL/checksums; grouped race regressions and UI build pass; hosted startup/deployed acceptance remains open',
'M8-09a':'2026-10-21 shared worker connector/approval profile compiler avoids duplicate immutable enforcement renders while preserving fresh live readiness and authority checks; exact SQL/checksum and grouped race verification only; deployed worker acceptance remains open'}
for row in rows:
    if row['id'] in notes:
        row['current_evidence']+='; '+notes[row['id']]+'; cloud-launch-profile-assembly-checkpoint-2026-10-21.json; no promotion'
out=io.StringIO(newline=''); writer=csv.DictWriter(out,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n'); writer.writeheader();writer.writerows(rows)
p.write_text(out.getvalue())
after=list(csv.DictReader(io.StringIO(p.read_text()),delimiter='\t'))
old=list(csv.DictReader(io.StringIO(before.decode()),delimiter='\t'))
for a,b in zip(old,after):
    assert a['id']==b['id']
    assert all(a[k]==b[k] for k in a if k!='current_evidence')
    assert (a!=b)==(a['id'] in notes)
(Path('/tmp/oct21-launch-final')/'ledger-before.tsv').write_bytes(before)
report={'total':728,'historical_statuses':dict(collections.Counter(x['ledger_status'] for x in after)),'production_classes':dict(collections.Counter(x['production_class'] for x in after)),'nonproduction':219,'promotions':0,'changed_evidence_rows':list(notes),'beforeSHA256':hashlib.sha256(before).hexdigest(),'afterSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'ownersSHA256':hashlib.sha256((root/'docs/internal/implementation_production_availability_owners_v1.5.tsv').read_bytes()).hexdigest(),'unchanged_all_other_fields':True,'preparation_failure':'Initial expected-class spelling blocked-external mismatched actual immutable blocked/external; assertion refused before any file write; corrected to exact existing value, no category changed.'}
(Path('/tmp/oct21-launch-final')/'ledger-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
