import hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/zasp-node-coverage-retention')
manifest=root/'.github/connector-native-compile-source-pins.json'
original=manifest.read_bytes()
data=json.loads(original)
assert len(data['sources'])==925
paths=[x['path'] for x in data['sources']]
assert len(set(paths))==925
new='services/platform/migrations/connector_approval_assembly_test.go'
assert new not in paths
changed=['services/platform/migrations/production_connector_enqueue_provenance.go','services/platform/migrations/production_connector_maintenance.go','services/platform/migrations/production_approval_activation_profile.go','deploy/production/release-contract.test.mjs']
workflow='.github/workflows/connector-native-draft-compile.yml'
runners=['scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs']
for p in changed+[workflow]+runners:
    assert p in paths,p
for p in ['.github/connector-native-compile-source-pins.json',workflow]+runners:
    (Path('/tmp/oct21-launch-final')/(Path(p).name+'.before')).write_bytes((root/p).read_bytes())
w=(root/workflow).read_text()
assert w.count("assert len(source['sources']) == 925")==2
(root/workflow).write_text(w.replace("assert len(source['sources']) == 925","assert len(source['sources']) == 926"))
def sha(p): return hashlib.sha256((root/p).read_bytes()).hexdigest()
for p in runners:
    src=(root/p).read_text()
    match=re.search(r'const pins = (\{.*?\n\});',src,re.S)
    assert match
    pins=json.loads(match[1])
    for item in changed+[workflow]:
        assert item in pins,item
        pins[item]=sha(item)
    assert new not in pins
    pins[new]=sha(new)
    (root/p).write_text(src[:match.start(1)]+json.dumps(pins,indent=2)+src[match.end(1):])
data['sources'].append({'path':new,'sha256':sha(new),'bytes':(root/new).stat().st_size,'currentBasePreimageSHA256':None,'historicalPreimageSHA256':None})
for item in data['sources']:
    p=item['path']
    item['sha256']=sha(p)
    item['bytes']=(root/p).stat().st_size
assert [x['path'] for x in data['sources']][:-1]==paths
data['startupAssemblySourceAssociationBase']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
data['startupAssemblyPredecessorManifestSHA256']=hashlib.sha256(original).hexdigest()
manifest.write_text(json.dumps(data,indent=2)+'\n')
report={'bindings':len(data['sources']),'predecessorSHA256':hashlib.sha256(original).hexdigest(),'newTest':new,'changed':[]}
old=json.loads(original)
for before,after in zip(old['sources'],data['sources']):
    if before!=after:
        assert before['path'] in changed+[workflow]+runners,before['path']
        assert all(before[k]==after[k] for k in before if k not in ['sha256','bytes'])
        report['changed'].append({'path':after['path'],'beforeSHA256':before['sha256'],'afterSHA256':after['sha256']})
assert len(report['changed'])==7
for item in data['sources']:
    assert sha(item['path'])==item['sha256']
    assert (root/item['path']).stat().st_size==item['bytes']
for p in runners:
    pins=json.loads(re.search(r'const pins = (\{.*?\n\});',(root/p).read_text(),re.S)[1])
    for name in changed+[workflow,new]: assert pins[name]==sha(name)
(Path('/tmp/oct21-launch-final')/'custody-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
