import subprocess, pathlib, json, os, time, collections, sys
root=pathlib.Path('/workspace/zasp-node-coverage-retention'); evidence=pathlib.Path('/tmp/gateway-authority-recovery-evidence-20261017'); phase=sys.argv[1]
env=os.environ.copy();env.update(PATH='/workspace/.zasp-tools/go/bin:/workspace/.zasp-tools/node/node-v22.23.1-linux-x64/bin:'+env['PATH'],GOTOOLCHAIN='local',GOFLAGS='-mod=readonly',GOPROXY='off',GOCACHE='/workspace/.zasp-tools/go-cache',GOMODCACHE='/workspace/.zasp-tools/module-cache',GOMAXPROCS='2',GOMEMLIMIT='1GiB',GOGC='50')
for label,cwd,args in [('shared','services/platform',['./gatewayenrollmentwire','./gatewayenrollmentcustody']),('cli','cmd/agentsecctl',['.'])]:
 cmd=['go','test','-race','-p=1','-count=1','-timeout=120s','-json','-run','^(TestGatewayCurrentAuthority|TestGatewayAuthorityRecovery)',*args];start=time.monotonic()
 with (evidence/f'{phase}-{label}.jsonl').open('wb') as out,(evidence/f'{phase}-{label}.stderr').open('wb') as err:
  result=subprocess.run(cmd,cwd=root/cwd,env=env,stdout=out,stderr=err,check=False,timeout=300,preexec_fn=lambda:os.umask(0o027))
 counts=collections.Counter();names=[]
 for line in (evidence/f'{phase}-{label}.jsonl').read_text().splitlines():
  try: event=json.loads(line)
  except ValueError:continue
  if event.get('Test') and event.get('Action') in ('pass','fail','skip'):counts[event['Action']]+=1; names.append({'package':event['Package'],'name':event['Test'],'action':event['Action']})
 receipt={'command':cmd,'cwd':cwd,'exit_code':result.returncode,'elapsed_seconds':round(time.monotonic()-start,2),'named':dict(counts),'results':names,'qualification':'Actual local application tests only. Zero named setup failures do not prove behavior or compilation. No native/deployed evidence.'};(evidence/f'{phase}-{label}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'phase':phase,'label':label,'exit_code':result.returncode,'named':dict(counts)}),flush=True)
