import json, re, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts').resolve()))
from validate_agent_read_components import check_sources, load_events, validate_events
expected = {'github.com/zasp-ai/zasp-sec/services/platform/gatewayenrollmentwire': ['TestGatewayCurrentAuthorityClosedTupleAndFreshness',
                                                                         'TestGatewayCurrentAuthorityStrictOriginalThirteenFields',
                                                                         'TestGatewayCurrentAuthorityExactRetainedKeyGetProof'],
 'github.com/zasp-ai/zasp-sec/services/platform/gatewayenrollmentcustody': ['TestGatewayAuthorityRecoveryLiveCapabilityPreservesUnknownEnrollment',
                                                                            'TestGatewayAuthorityRecoveryRestartHistoryIsNeverLive',
                                                                            'TestGatewayAuthorityRecoveryOrphansAliasesAndClosedHandles'],
 'github.com/zasp-ai/zasp-sec/cmd/agentsecctl': ['TestGatewayAuthorityRecoveryCommandLostEnrollmentAndExpiredToken',
                                                 'TestGatewayAuthorityRecoveryCommandFreshRetryPreservesHistory',
                                                 'TestGatewayAuthorityRecoveryCommandRefusesInvalidEvidenceAndInputs']}
required = frozenset(['.github/workflows/connector-native-draft-compile.yml',
 'cmd/agentsecctl/gateway_authority_recovery.go',
 'cmd/agentsecctl/gateway_authority_recovery_test.go',
 'cmd/agentsecctl/gateway_enrollment.go',
 'cmd/agentsecctl/gateway_enrollment_test.go',
 'cmd/agentsecctl/go.mod',
 'cmd/agentsecctl/go.sum',
 'cmd/agentsecctl/release.go',
 'scripts/validate_agent_read_components.py',
 'scripts/validate_agent_read_components_test.py',
 'services/platform/gatewaycontrol/client.go',
 'services/platform/gatewaycontrol/contract.go',
 'services/platform/gatewaycontrol/http.go',
 'services/platform/gatewaycontrol/postgres.go',
 'services/platform/gatewayenrollmentcustody/custody.go',
 'services/platform/gatewayenrollmentcustody/custody_test.go',
 'services/platform/gatewayenrollmentcustody/files_linux.go',
 'services/platform/gatewayenrollmentcustody/files_other.go',
 'services/platform/gatewayenrollmentcustody/publication.go',
 'services/platform/gatewayenrollmentcustody/recovery.go',
 'services/platform/gatewayenrollmentcustody/recovery_test.go',
 'services/platform/gatewayenrollmentwire/authority.go',
 'services/platform/gatewayenrollmentwire/authority_test.go',
 'services/platform/gatewayenrollmentwire/wire.go',
 'services/platform/gatewayenrollmentwire/wire_test.go',
 'services/platform/go.mod',
 'services/platform/go.sum',
 'services/platform/internal/cacheownership/ownership.go',
 'services/platform/internal/cacheownership/ownership_linux.go',
 'services/platform/internal/cacheownership/ownership_other.go',
 'services/platform/internal/cacheownership/ownership_test.go',
 'services/platform/migrations/sql/0015_runtime_data_plane.up.sql',
 'services/platform/migrations/sql/0080_authorization_worker_gateway_writers.sql'])
assert len(expected) == 3 and sum(map(len, expected.values())) == 9
assert all(len(names) == len(set(names)) and all('/' not in n and 'Postgres' not in n for n in names) for names in expected.values())
print(json.dumps(check_sources(Path.cwd(), '.github/connector-native-compile-source-pins.json', required), sort_keys=True))
status = 0
modules = {'services/platform': ['./gatewayenrollmentwire', './gatewayenrollmentcustody'], 'cmd/agentsecctl': ['.']}
with Path('gateway-authority-recovery-components.jsonl').open('wb') as out, Path('gateway-authority-recovery-components.stderr').open('wb') as err:
    for module, packages in modules.items():
        prefix = 'github.com/zasp-ai/zasp-sec/' + module
        heads = [n for package, names in expected.items() if package == prefix or package.startswith(prefix + '/') for n in names]
        assert heads
        command = ['go','test','-C',module,'-race','-p=1','-count=1','-timeout=3m','-json','-run','^('+'|'.join(map(re.escape, heads))+')$',*packages]
        result = subprocess.run(command, stdout=out, stderr=err, timeout=600, check=False)
        if result.returncode != 0 and status == 0:
            status = result.returncode
print(json.dumps(validate_events(load_events('gateway-authority-recovery-components.jsonl'), status, expected), sort_keys=True))
