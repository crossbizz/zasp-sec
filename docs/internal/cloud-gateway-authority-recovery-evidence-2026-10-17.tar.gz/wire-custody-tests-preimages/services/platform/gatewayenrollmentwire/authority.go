package gatewayenrollmentwire

import (
	"net/http"
	"time"
)

// CurrentAuthority is the existing device authority response, not an enrollment
// receipt or a cryptographically signed server response.
type CurrentAuthority struct {
	OrganizationID       string    `json:"organization_id"`
	WorkspaceID          string    `json:"workspace_id"`
	EnvironmentID        string    `json:"environment_id"`
	DeviceID             string    `json:"device_id"`
	DeviceVersion        uint64    `json:"device_version"`
	ReplayFloor          uint64    `json:"replay_floor"`
	CredentialID         string    `json:"credential_id"`
	CredentialGeneration uint64    `json:"credential_generation"`
	KeyID                string    `json:"key_id"`
	Algorithm            string    `json:"algorithm"`
	PublicKey            string    `json:"public_key"`
	Audience             string    `json:"audience"`
	ExpiresAt            time.Time `json:"expires_at"`
}

func ParseCurrentAuthority([]byte) (CurrentAuthority, error)                   { return CurrentAuthority{}, ErrInvalid }
func MarshalCurrentAuthority(CurrentAuthority) ([]byte, error)                 { return nil, ErrInvalid }
func CurrentAuthorityMatchesRequest(CurrentAuthority, Request, time.Time) bool { return false }
func SignAuthorityRequest(*http.Request, Request, func([]byte) ([]byte, error), time.Time) error {
	return ErrInvalid
}
