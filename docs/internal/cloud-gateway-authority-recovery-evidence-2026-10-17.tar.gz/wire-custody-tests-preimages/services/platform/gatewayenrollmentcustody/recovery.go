package gatewayenrollmentcustody

import "time"

// Recovery is an opaque in-process live-check capability. Saved observations do
// not recreate it and do not authorize the original receipt-only export API.
type Recovery struct{}

func (*Store) BeginRecovery() (*Recovery, error)             { return nil, ErrUnavailable }
func (*Recovery) Source() (string, Snapshot, error)          { return "", Snapshot{}, ErrUnavailable }
func (*Recovery) Sign([]byte) ([]byte, error)                { return nil, ErrUnavailable }
func (*Recovery) Observe([]byte, time.Time, time.Time) error { return ErrUnavailable }
func (*Recovery) ExportCredential(string, time.Time) error   { return ErrUnavailable }
func (*Recovery) Close() error                               { return nil }
