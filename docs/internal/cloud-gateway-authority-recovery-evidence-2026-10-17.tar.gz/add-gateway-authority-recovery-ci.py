from pathlib import Path
import re,json,pprint
r=Path('/workspace/zasp-node-coverage-retention'); e=Path('/tmp/gateway-authority-recovery-evidence-20261017'); w=r/'.github/workflows/connector-native-draft-compile.yml'; original=w.read_bytes();(e/'workflow-before-recovery.yml').write_bytes(original)
expected={}
for directory,test in [('services/platform/gatewayenrollmentwire','authority_test.go'),('services/platform/gatewayenrollmentcustody','recovery_test.go'),('cmd/agentsecctl','gateway_authority_recovery_test.go')]:
 expected['github.com/zasp-ai/zasp-sec/'+directory]=re.findall(r'^func (TestGateway(?:CurrentAuthority|AuthorityRecovery)\w+)\(', (r/directory/test).read_text(),re.M)
assert len(expected)==3 and sum(map(len,expected.values()))==9
required=['.github/workflows/connector-native-draft-compile.yml','scripts/validate_agent_read_components.py','scripts/validate_agent_read_components_test.py','cmd/agentsecctl/gateway_authority_recovery.go','cmd/agentsecctl/gateway_authority_recovery_test.go','cmd/agentsecctl/gateway_enrollment.go','cmd/agentsecctl/gateway_enrollment_test.go','cmd/agentsecctl/release.go','cmd/agentsecctl/go.mod','cmd/agentsecctl/go.sum','services/platform/go.mod','services/platform/go.sum']
for directory in ['services/platform/gatewayenrollmentwire','services/platform/gatewayenrollmentcustody','services/platform/internal/cacheownership']:
 required += [str(p.relative_to(r)) for p in sorted((r/directory).glob('*.go'))]
research=json.load(open(r/'docs/internal/gateway-authority-recovery-design-2026-10-17/source-research.json'));required=sorted(set(required)|{s['path'] for s in research['source_pins']})
script="""import json, re, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts').resolve()))
from validate_agent_read_components import check_sources, load_events, validate_events
expected = EXPECTED
required = frozenset(REQUIRED)
assert len(expected) == 3 and sum(map(len, expected.values())) == 9
assert all(len(names) == len(set(names)) and all('/' not in n and 'Postgres' not in n for n in names) for names in expected.values())
print(json.dumps(check_sources(Path.cwd(), '.github/connector-native-compile-source-pins.json', required), sort_keys=True))
status = 0
modules = {'services/platform': ['./gatewayenrollmentwire', './gatewayenrollmentcustody'], 'cmd/agentsecctl': ['.']}
with Path('gateway-authority-recovery-components.jsonl').open('wb') as out, Path('gateway-authority-recovery-components.stderr').open('wb') as err:
    for module, packages in modules.items():
        prefix = 'github.com/zasp-ai/zasp-sec/' + module
        heads = [n for package, names in expected.items() if package == prefix or package.startswith(prefix + '/') for n in names]
        assert heads
        command = ['go','test','-C',module,'-race','-p=1','-count=1','-timeout=3m','-json','-run','^('+'|'.join(map(re.escape, heads))+')$',*packages]
        result = subprocess.run(command, stdout=out, stderr=err, timeout=600, check=False)
        if result.returncode != 0 and status == 0:
            status = result.returncode
print(json.dumps(validate_events(load_events('gateway-authority-recovery-components.jsonl'), status, expected), sort_keys=True))
""".replace('EXPECTED',pprint.pformat(expected,width=110,sort_dicts=False)).replace('REQUIRED',pprint.pformat(required,width=110))
body='''
  gateway-authority-recovery-components:
    runs-on: ubuntu-24.04
    timeout-minutes: 15
    env:
      GOTOOLCHAIN: local
      GOWORK: 'off'
      GOFLAGS: '-mod=readonly'
      GOMAXPROCS: '2'
    steps:
      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1
        with:
          persist-credentials: false
      - uses: actions/setup-go@924ae3a1cded613372ab5595356fb5720e22ba16
        with:
          go-version: 1.26.8
          cache: false
      - name: Require all nine retained-key recovery component results
        shell: bash
        run: |
          set -euo pipefail
          umask 0027
          test "$(go version)" = 'go version go1.26.8 linux/amd64'
          python3 - <<'PYGATEWAYAUTHORITYRECOVERY'
SCRIPT          PYGATEWAYAUTHORITYRECOVERY
      - name: Preserve component evidence without native or deployed promotion
        if: always()
        uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02
        with:
          name: gateway-authority-recovery-component-evidence
          path: |
            gateway-authority-recovery-components.jsonl
            gateway-authority-recovery-components.stderr
          if-no-files-found: warn
          retention-days: 14
      - name: Confirm checks did not alter tracked source
        if: always()
        run: git diff --exit-code
'''.replace('SCRIPT',''.join('          '+line+'\n' for line in script.splitlines()))
assert b'\n  gateway-authority-recovery-components:' not in original; w.write_text(original.decode()+body)
(e/'component-gate-contract.json').write_text(json.dumps({'expected':expected,'required':required,'named':9,'qualification':'Future required actual roster; declaration is not product execution'},indent=2)+'\n'); compile(script,'recovery-ci','exec'); print('Appended nine-head component gate; Python syntax PASS; required paths',len(required))
