import json,re,hashlib,subprocess
from pathlib import Path
root=Path('/workspace/zasp-node-coverage-retention')
def digest(p): return hashlib.sha256((root/p).read_bytes()).hexdigest()
manifestPath='.github/connector-native-compile-source-pins.json'
before=(root/manifestPath).read_bytes();manifest=json.loads(before);old={x['path']:dict(x) for x in manifest['sources']};assert len(old)==840
changed=set(subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z'],cwd=root).decode().split('\0'))-{''}
custody={'scripts/connector-acceptance-groups.test.mjs','scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs',manifestPath}
closure={p for p in changed if p.startswith(('services/','cmd/','app/','apps/','deploy/','openapi/','scripts/','.github/workflows/','docs/product/'))}
for directory in ['services/platform/gatewayenrollmentwire','services/platform/gatewayenrollmentcustody','cmd/agentsecctl','services/gateway-control']:
 closure.update(str(p.relative_to(root)) for p in (root/directory).rglob('*') if p.is_file() and (p.suffix=='.go' or p.name in ('go.mod','go.sum')))
for p in ['services/platform/go.mod','services/platform/go.sum'] :closure.add(p)
# No unexplained existing-source drift is refreshed.
for p,item in old.items():
 if digest(p)!=item['sha256'] and p not in closure|custody:raise SystemExit('unexplained source drift: '+p)
testPath='scripts/connector-acceptance-groups.test.mjs';source=(root/testPath).read_text();start=source.index('  const required = [');end=source.index('];\n  const compiled',start)
existing=json.loads('['+source[start+len('  const required = ['):end]+']');added=sorted(closure-set(existing));existing.extend(added)
source=source[:start]+'  const required = '+json.dumps(existing,indent=2)+source[end+1:];(root/testPath).write_text(source)
# Literal maps only; preserve every runner statement outside pin maps.
for runner in ['scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs']:
 source=(root/runner).read_text();match=re.search(r'const pins = (\{.*?\n\});',source,re.S);pins=json.loads(match[1]);hm=re.search(r'const helperPins\s*=\s*(\{.*?\n\});',source,re.S);helpers=json.loads(hm[1]);original=pins.copy();originalHelpers=helpers.copy()
 for p in closure|{testPath}:
  if p in helpers:helpers[p]=digest(p)
  else:pins[p]=digest(p)
 source=source[:hm.start(1)]+json.dumps(helpers,indent=2)+source[hm.end(1):]
 match=re.search(r'const pins = (\{.*?\n\});',source,re.S);source=source[:match.start(1)]+json.dumps(pins,indent=2)+source[match.end(1):];(root/runner).write_text(source)
# Preserve old order and every preimage/history field; append new closure bindings.
for p in sorted(closure|custody-{manifestPath}):
 if p not in old:manifest['sources'].append({'path':p,'sha256':digest(p),'bytes':(root/p).stat().st_size,'currentBasePreimageSHA256':None,'historicalPreimageSHA256':None})
changes=[]
for item in manifest['sources']:
 p=item['path'];h=digest(p)
 if h!=item['sha256']:changes.append({'path':p,'predecessorSHA256':item['sha256'],'sha256':h})
 item['sha256']=h;item['bytes']=(root/p).stat().st_size
manifest['gatewayAuthorityRecoverySourceAssociationBase']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();manifest['gatewayAuthorityRecoveryPredecessorManifestSHA256']=hashlib.sha256(before).hexdigest()
(root/manifestPath).write_text(json.dumps(manifest,indent=2)+'\n')
workflow=root/'.github/workflows/connector-native-draft-compile.yml';w=workflow.read_text();assert w.count("assert len(source['sources']) == 840")==2;w=w.replace("assert len(source['sources']) == 840",f"assert len(source['sources']) == {len(manifest['sources'])}");workflow.write_text(w)
# The workflow was added to closure and therefore pins: finalize only this explicitly changed binding.
p='.github/workflows/connector-native-draft-compile.yml'
if p in closure:
 for runner in ['scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs']:
  source=(root/runner).read_text();m=re.search(r'const pins = (\{.*?\n\});',source,re.S);pins=json.loads(m[1]);pins[p]=digest(p);(root/runner).write_text(source[:m.start(1)]+json.dumps(pins,indent=2)+source[m.end(1):])
 for item in manifest['sources']:
  if item['path'] in {p,'scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs'}:item['sha256']=digest(item['path']);item['bytes']=(root/item['path']).stat().st_size
 (root/manifestPath).write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'priorBindings':len(old),'bindings':len(manifest['sources']),'closure':sorted(closure),'addedClosureAssertions':added,'changedExistingBindings':changes,'qualification':'Explicit current-source custody only; no verification or production promotion'}
Path('/tmp/gateway-authority-recovery-evidence-20261017/final-source-custody.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'prior':len(old),'current':len(manifest['sources']),'closure':len(closure)}))
