import { createRequire } from 'node:module';
const require = createRequire('/workspace/zasp-node-coverage-retention/package.json');
const sdkRequire = createRequire(require.resolve('stytch'));
const { EnvHttpProxyAgent, setGlobalDispatcher } = sdkRequire('undici');
setGlobalDispatcher(new EnvHttpProxyAgent());
