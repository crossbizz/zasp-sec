import { createRequire } from 'node:module';
import https from 'node:https';
try {
  const require = createRequire('/workspace/zasp-node-coverage-retention/package.json');
  const sdkRequire = createRequire(require.resolve('stytch'));
  const { EnvHttpProxyAgent, setGlobalDispatcher } = sdkRequire('undici');
  setGlobalDispatcher(new EnvHttpProxyAgent());
  const runtimeRequire = createRequire('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/package.json');
  const { HttpsProxyAgent } = runtimeRequire('https-proxy-agent');
  const proxy = process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy;
  if (!proxy) throw new Error();
  https.globalAgent = new HttpsProxyAgent(proxy);
} catch {
  console.error('Inherited proxy setup unavailable.');
  process.exit(1);
}
