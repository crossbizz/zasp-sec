import json, os, re, subprocess, sys
from pathlib import Path
# Capture the actual unchanged package gate; no synthesized TAP or selected test pattern.
result = subprocess.run(['npm', 'run', 'dependencies:check'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
Path(os.environ['RUNNER_TEMP'], 'dependency-check.stdout').write_bytes(result.stdout)
Path(os.environ['RUNNER_TEMP'], 'dependency-check.stderr').write_bytes(result.stderr)
sys.stdout.buffer.write(result.stdout)
sys.stdout.buffer.flush()
sys.stderr.buffer.write(result.stderr)
sys.stderr.buffer.flush()
assert result.returncode == 0, ('actual dependencies:check failed', result.returncode)
output = result.stdout.decode('utf-8', errors='strict')
expected = set(["vinext's actual image parser preserves icns-valid dimensions", "vinext's actual image parser preserves jxl-valid dimensions", "vinext's actual image parser preserves heif-valid dimensions", "vinext's actual image parser rejects icns-zero-entry without hanging", "vinext's actual image parser rejects jxl-zero-partial without hanging", "vinext's actual image parser rejects heif-zero-ispe without hanging", "core-utils' actual esbuild serves the local fixture without allowing an unrelated origin to read it", "core-utils' actual async and sync TypeScript transforms preserve exported values", 'real drizzle-kit generation retains the nonempty D1 notes schema and defaults'])
subtests = re.findall(r'^# Subtest: (.+)$', output, flags=re.M)
passes = re.findall(r'^ok ([1-9][0-9]*) - (.+)$', output, flags=re.M)
assert len(subtests) == 9 and len(set(subtests)) == 9 and set(subtests) == expected, subtests
assert len(passes) == 9 and {int(i) for i, _ in passes} == set(range(1, 10)), passes
assert {name for _, name in passes} == expected, passes
assert not re.search(r'^not ok\b|^Bail out!|^(?:ok|not ok) [1-9][0-9]*[^\n]*#\s*(?:SKIP|TODO)\b', output, flags=re.M | re.I)
assert re.findall(r'^1\.\.([0-9]+)$', output, flags=re.M) == ['9']
for key, value in {'tests':9, 'suites':0, 'pass':9, 'fail':0, 'cancelled':0, 'skipped':0, 'todo':0}.items():
    assert re.findall(r'^# ' + key + r' ([0-9]+)$', output, flags=re.M) == [str(value)], key
assert output.splitlines().count('Dependency lock valid') == 1, 'actual inventory did not validate'
print('Actual full dependency gate passed all nine original regression names')
