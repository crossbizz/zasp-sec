import hashlib, json, os, sys
from pathlib import Path, PurePosixPath
manifest = Path('.github/connector-native-compile-source-pins.json')
raw = manifest.read_bytes()
source = json.loads(raw)
required = set(['.github/workflows/dependency-process-cleanup-components.yml', 'apps/web/package.json', 'build/dependencies.lock.yaml', 'cmd/agentsecctl/go.mod', 'cmd/agentsecctl/go.sum', 'package-lock.json', 'package.json', 'scripts/dependency-esbuild-regression.test.mjs', 'scripts/dependency-parser-regression.test.mjs', 'scripts/fixtures/dependency-esbuild-regression-child.mjs', 'scripts/fixtures/dependency-parser-regression-child.mjs', 'scripts/run-dependency-regressions.py', 'scripts/run-dependency-regressions.test.py', 'scripts/validate-dependencies.mjs', 'scripts/validate-dependencies.test.mjs', 'services/event-ingest/go.mod', 'services/event-ingest/go.sum', 'services/gateway-control/go.mod', 'services/gateway-control/go.sum', 'services/gatewaypodidentity/go.mod', 'services/health/go.mod', 'services/platform/go.mod', 'services/platform/go.sum', 'services/runtime-gateway/go.mod', 'services/runtime-gateway/go.sum', 'services/sensor-agent/go.mod', 'services/sensor-agent/go.sum', 'workers/redteam-node/package.json', 'workers/security-python/build-requirements.lock', 'workers/security-python/cartography/pyproject.toml', 'workers/security-python/cartography/requirements.lock', 'workers/security-python/prowler/pyproject.toml', 'workers/security-python/prowler/requirements.lock', 'workers/security-python/pyproject.toml'])
seen = set()
assert isinstance(source['sources'], list) and source['sources'], 'empty source custody'
for item in source['sources']:
    name = item['path']
    assert isinstance(name, str) and name not in seen, 'duplicate source'
    parts = PurePosixPath(name)
    assert not parts.is_absolute() and '..' not in parts.parts and str(parts) == name
    target = Path(name)
    assert target.is_file() and not target.is_symlink(), name
    data = target.read_bytes()
    assert type(item['bytes']) is int and len(data) == item['bytes'], name
    assert hashlib.sha256(data).hexdigest() == item['sha256'], name
    seen.add(name)
assert required <= seen, 'missing required custody: ' + repr(sorted(required - seen))
snapshot = Path(os.environ['RUNNER_TEMP']) / 'dependency-custody-manifest.json'
if sys.argv[1] == 'before':
    assert not snapshot.exists(), 'stale custody snapshot'
    snapshot.write_bytes(raw)
else:
    assert sys.argv[1] == 'after' and snapshot.read_bytes() == raw, 'custody manifest changed'
print('Complete dependency source custody verified:', len(seen))
