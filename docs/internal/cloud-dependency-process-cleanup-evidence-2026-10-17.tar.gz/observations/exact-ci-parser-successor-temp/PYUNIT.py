import importlib.util, json, os, sys, unittest
from pathlib import Path
spec = importlib.util.spec_from_file_location('dependency_cleanup_components', 'scripts/run-dependency-regressions.test.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
suite = unittest.defaultTestLoader.loadTestsFromModule(module)
def flatten(group):
    for item in group:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item.id()
expected = set(['dependency_cleanup_components.ScopedReaperTests.test_reaps_actual_orphan_while_node_test_runner_remains_active', 'dependency_cleanup_components.ScopedReaperTests.test_preserves_actual_exit_status_output_and_existing_strict_guards', 'dependency_cleanup_components.ScopedReaperTests.test_bounded_cancel_and_timeout_reap_only_owned_descendants'])
actual = list(flatten(suite))
assert len(actual) == 3 and len(set(actual)) == 3 and set(actual) == expected, actual
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = {'expected_ids': sorted(expected), 'actual_ids': actual, 'testsRun': result.testsRun,
          'successful': result.wasSuccessful(), 'failures': len(result.failures),
          'errors': len(result.errors), 'skipped': len(result.skipped),
          'expectedFailures': len(result.expectedFailures), 'unexpectedSuccesses': len(result.unexpectedSuccesses)}
Path(os.environ['RUNNER_TEMP'], 'dependency-cleanup-unittest-result.json').write_text(json.dumps(record, indent=2) + '\n')
assert result.testsRun == 3 and result.wasSuccessful(), record
assert not (result.failures or result.errors or result.skipped or result.expectedFailures or result.unexpectedSuccesses), record
