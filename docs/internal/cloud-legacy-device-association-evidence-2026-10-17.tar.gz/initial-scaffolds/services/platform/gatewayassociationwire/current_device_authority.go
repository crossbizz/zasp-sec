package gatewayassociationwire

import (
	"net/http"
	"time"
)

// SignCurrentDeviceAuthorityRequest uses an existing Device credential and its
// retained key without constructing enrollment lineage. KeyID is validated as a
// local constraint; the existing signature context does not contain keyID.
func SignCurrentDeviceAuthorityRequest(*http.Request, string, string, string, func([]byte) ([]byte, error), time.Time) error {
	return ErrInvalid
}
