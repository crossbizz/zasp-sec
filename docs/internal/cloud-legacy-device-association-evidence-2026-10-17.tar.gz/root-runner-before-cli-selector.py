from pathlib import Path
import os,json,subprocess,hashlib,collections,time,sys
r=Path('/workspace/zasp-node-coverage-retention');e=Path('/tmp/legacy-device-association-evidence-20261017');phase=sys.argv[1];groups=sys.argv[2:];env=os.environ.copy();env.update(PATH='/workspace/.zasp-tools/go/bin:/workspace/.zasp-tools/node/node-v22.23.1-linux-x64/bin:'+env['PATH'],GOTOOLCHAIN='local',GOFLAGS='-mod=readonly',GOPROXY='off',GOCACHE='/workspace/.zasp-tools/go-cache',GOMODCACHE='/workspace/.zasp-tools/module-cache',GOMAXPROCS='2',GOMEMLIMIT='1GiB',GOGC='50')
for group in groups:
 specs={'wire':('services/platform',['./gatewayassociationwire']),'custody':('services/platform',['./gatewayenrollmentcustody']),'cli':('cmd/agentsecctl',['.'])};cwd,packages=specs[group]
 if phase=='initial-red':
  freeze=json.loads((e/(group+'-tests.json')).read_text());rows=freeze.get('sources',[])
  for row in rows:
   p=row['path'];raw=(r/p).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];q=e/'initial-scaffolds'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 cmd=['go','test','-race','-p=1','-count=1','-timeout=120s','-json']
 if not phase.startswith('full'):cmd+=['-run','^TestLegacy']
 cmd+=packages;t=time.monotonic()
 with (e/(phase+'-'+group+'.jsonl')).open('wb') as out,(e/(phase+'-'+group+'.stderr')).open('wb') as err:p=subprocess.run(cmd,cwd=r/cwd,env=env,stdout=out,stderr=err,timeout=240,preexec_fn=lambda:os.umask(0o027))
 counts=collections.Counter();results=[]
 for line in (e/(phase+'-'+group+'.jsonl')).read_text().splitlines():
  try:x=json.loads(line)
  except ValueError:continue
  if x.get('Test') and x.get('Action') in ('pass','fail','skip'):counts[x['Action']]+=1;results.append({k:x[k] for k in ['Package','Test','Action']})
 (e/(phase+'-'+group+'-receipt.json')).write_text(json.dumps({'command':cmd,'cwd':cwd,'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-t,2),'named':dict(counts),'results':results,'qualification':'Actual local application component only; not native/deployed acceptance. Zero named setup/build failures are not behavioral RED or compile proof.'},indent=2)+'\n');print(phase,group,p.returncode,dict(counts),flush=True)
