package gatewayenrollmentcustody

import (
	"fmt"
	associationwire "github.com/zasp-ai/zasp-sec/services/platform/gatewayassociationwire"
	wire "github.com/zasp-ai/zasp-sec/services/platform/gatewayenrollmentwire"
	"io"
	"net/http"
	"time"
)

// Tests-only opaque capabilities; functional release requires executor RED.
type LegacyDeviceStore struct{}
type LegacyAssociation struct{}

func OpenLegacyDevice(string, string, string) (*LegacyDeviceStore, error)      { return nil, ErrUnavailable }
func (*LegacyDeviceStore) SignAuthorityRequest(*http.Request, time.Time) error { return ErrUnavailable }
func (*LegacyDeviceStore) BeginAssociation(associationwire.ChallengeEnvelope, wire.CurrentAuthority, time.Time) (*LegacyAssociation, error) {
	return nil, ErrUnavailable
}
func (*LegacyDeviceStore) Close() error { return nil }
func (*LegacyAssociation) Source() (string, AssociationSnapshot, error) {
	return "", AssociationSnapshot{}, ErrUnavailable
}
func (*LegacyAssociation) Sign([]byte) ([]byte, error) { return nil, ErrUnavailable }
func (*LegacyAssociation) Confirm(associationwire.AcceptResponse, time.Time) error {
	return ErrUnavailable
}
func (*LegacyAssociation) Close() error               { return nil }
func (*LegacyDeviceStore) String() string             { return "[REDACTED]" }
func (*LegacyDeviceStore) GoString() string           { return "[REDACTED]" }
func (*LegacyDeviceStore) Format(s fmt.State, _ rune) { _, _ = io.WriteString(s, "[REDACTED]") }
func (*LegacyAssociation) String() string             { return "[REDACTED]" }
func (*LegacyAssociation) GoString() string           { return "[REDACTED]" }
func (*LegacyAssociation) Format(s fmt.State, _ rune) { _, _ = io.WriteString(s, "[REDACTED]") }
