import json, re, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts').resolve()))
from validate_agent_read_components import check_sources, load_events, validate_events
# Exact heads: a broad TestLegacy selector also selects an unrelated old CLI test.
# Component success does not substitute for original native or deployed acceptance.
expected = {'github.com/zasp-ai/zasp-sec/services/platform/gatewayassociationwire': ['TestLegacyCurrentDeviceAuthorityExistingRequestABI',
                                                                          'TestLegacyCurrentDeviceAuthorityRejectsAliasAndBody',
                                                                          'TestLegacyCurrentDeviceAuthorityRetainedKeyProofRefusals'],
 'github.com/zasp-ai/zasp-sec/services/platform/gatewayenrollmentcustody': ['TestLegacyDeviceAssociationReadonlyCurrentAuthority',
                                                                            'TestLegacyDeviceAssociationReadonlyCurrentAuthority/actual_three_fields_and_durable_intent',
                                                                            'TestLegacyDeviceAssociationReadonlyCurrentAuthority/no_offline_or_repeat_capability',
                                                                            'TestLegacyDeviceAssociationReadonlyCurrentAuthority/source_swap_invalidates_signing',
                                                                            'TestLegacyDeviceAssociationDurableRecovery',
                                                                            'TestLegacyDeviceAssociationDurableRecovery/exact_restart_and_immutable_receipt',
                                                                            'TestLegacyDeviceAssociationDurableRecovery/partial_intent_stage_refused',
                                                                            'TestLegacyDeviceAssociationDurableRecovery/orphan_namespace_refused',
                                                                            'TestLegacyDeviceAssociationSourceAndNamespaceBoundaries',
                                                                            'TestLegacyDeviceAssociationSourceAndNamespaceBoundaries/guard_and_key_consistency',
                                                                            'TestLegacyDeviceAssociationSourceAndNamespaceBoundaries/binding_rotation_refused',
                                                                            'TestLegacyDeviceAssociationSourceAndNamespaceBoundaries/cross_store_export_ancestors'],
 'github.com/zasp-ai/zasp-sec/cmd/agentsecctl': ['TestGatewayLegacyAgentAssociationCommandConnectedCurrentAuthority',
                                                 'TestGatewayLegacyAgentAssociationCommandUnknownRetryRequiresFreshAuthority',
                                                 'TestGatewayLegacyAgentAssociationCommandRefusesTrustAndAuthorityFailures']}
required = frozenset(['.github/workflows/connector-native-draft-compile.yml',
 'cmd/agentsecctl/gateway_agent_association.go',
 'cmd/agentsecctl/gateway_agent_association_test.go',
 'cmd/agentsecctl/gateway_authority_recovery.go',
 'cmd/agentsecctl/gateway_authority_recovery_test.go',
 'cmd/agentsecctl/gateway_enrollment.go',
 'cmd/agentsecctl/gateway_enrollment_test.go',
 'cmd/agentsecctl/gateway_legacy_agent_association.go',
 'cmd/agentsecctl/gateway_legacy_agent_association_test.go',
 'cmd/agentsecctl/go.mod',
 'cmd/agentsecctl/go.sum',
 'cmd/agentsecctl/main.go',
 'cmd/agentsecctl/release.go',
 'scripts/validate_agent_read_components.py',
 'scripts/validate_agent_read_components_test.py',
 'services/platform/gatewayassociationwire/current_device_authority.go',
 'services/platform/gatewayassociationwire/current_device_authority_test.go',
 'services/platform/gatewayassociationwire/testdata/known-answer.json',
 'services/platform/gatewayassociationwire/wire.go',
 'services/platform/gatewayassociationwire/wire_test.go',
 'services/platform/gatewaycontrol/client.go',
 'services/platform/gatewaycontrol/contract.go',
 'services/platform/gatewaycontrol/http.go',
 'services/platform/gatewaycontrol/postgres.go',
 'services/platform/gatewayenrollmentcustody/association.go',
 'services/platform/gatewayenrollmentcustody/association_directory_linux.go',
 'services/platform/gatewayenrollmentcustody/association_directory_other.go',
 'services/platform/gatewayenrollmentcustody/association_export_parent.go',
 'services/platform/gatewayenrollmentcustody/association_test.go',
 'services/platform/gatewayenrollmentcustody/custody.go',
 'services/platform/gatewayenrollmentcustody/custody_test.go',
 'services/platform/gatewayenrollmentcustody/files_linux.go',
 'services/platform/gatewayenrollmentcustody/files_other.go',
 'services/platform/gatewayenrollmentcustody/legacy_association.go',
 'services/platform/gatewayenrollmentcustody/legacy_association_linux.go',
 'services/platform/gatewayenrollmentcustody/legacy_association_other.go',
 'services/platform/gatewayenrollmentcustody/legacy_association_test.go',
 'services/platform/gatewayenrollmentcustody/publication.go',
 'services/platform/gatewayenrollmentcustody/recovery.go',
 'services/platform/gatewayenrollmentcustody/recovery_test.go',
 'services/platform/gatewayenrollmentwire/authority.go',
 'services/platform/gatewayenrollmentwire/authority_test.go',
 'services/platform/gatewayenrollmentwire/wire.go',
 'services/platform/gatewayenrollmentwire/wire_test.go',
 'services/platform/go.mod',
 'services/platform/go.sum',
 'services/platform/internal/cacheownership/ownership.go',
 'services/platform/internal/cacheownership/ownership_linux.go',
 'services/platform/internal/cacheownership/ownership_other.go',
 'services/platform/internal/cacheownership/ownership_test.go',
 'services/platform/migrations/sql/0015_runtime_data_plane.up.sql',
 'services/platform/migrations/sql/0080_authorization_worker_gateway_writers.sql',
 'services/runtime-gateway/production.go'])
assert len(expected) == 3 and sum(map(len, expected.values())) == 18
assert all(len(names) == len(set(names)) and all('Postgres' not in n for n in names) for names in expected.values())
print(json.dumps(check_sources(Path.cwd(), '.github/connector-native-compile-source-pins.json', required), sort_keys=True))
modules = {'cmd/agentsecctl': ['.'],
 'services/platform': ['./gatewayassociationwire', './gatewayenrollmentcustody']}
status = 0
executions = []
with Path('legacy-device-association-components.jsonl').open('wb') as out, Path('legacy-device-association-components.stderr').open('wb') as err:
    for module, packages in modules.items():
        prefix = 'github.com/zasp-ai/zasp-sec/' + module
        heads = [name for package, names in expected.items() if package == prefix or package.startswith(prefix + '/') for name in names if '/' not in name]
        assert heads
        command = ['go','test','-C',module,'-race','-p=1','-count=1','-timeout=3m','-json','-run','^('+'|'.join(map(re.escape, heads))+')$',*packages]
        result = subprocess.run(command, stdout=out, stderr=err, timeout=900, check=False)
        executions.append({'module':module,'command':command,'exit_code':result.returncode,'classification':'component-behavior'})
        if result.returncode != 0 and status == 0:
            status = result.returncode
Path('legacy-device-association-component-executions.json').write_text(json.dumps(executions, indent=2)+'\n')
assert len(executions) == 2
print(json.dumps(validate_events(load_events('legacy-device-association-components.jsonl'), status, expected), sort_keys=True))
