package migrations
import("os";"path/filepath";"testing")
// Compiler extraction diagnostic only, never native/installer/SQL acceptance.
func TestGatewayBootstrapEmitCompiledSQLForGrammarDiagnostic(t *testing.T){
 if os.Getenv("ZASP_GATEWAY_BOOTSTRAP_EMIT_COMPILED_SQL")!="1"{t.Fatal("explicit diagnostic opt-in required")}
 const output="/tmp/gateway-bootstrap-connected-evidence-20261017"
 for _,v:=range []struct{name string;audit bool}{{"normal",false},{"audit",true}}{
  source,pin:=compiledGatewayBootstrapSource(v.audit)
  if source==""||!IsGatewayBootstrapProfileChecksum(pin){t.Fatal("compiled source identity absent")}
  if os.WriteFile(filepath.Join(output,"gateway-bootstrap-compiled-"+v.name+".sql"),[]byte(source),0600)!=nil{t.Fatal("diagnostic SQL output refused")}
  if os.WriteFile(filepath.Join(output,"gateway-bootstrap-compiled-"+v.name+".profile-pin"),[]byte(pin+"\n"),0600)!=nil{t.Fatal("diagnostic compiler pin output refused")}
 }
}
