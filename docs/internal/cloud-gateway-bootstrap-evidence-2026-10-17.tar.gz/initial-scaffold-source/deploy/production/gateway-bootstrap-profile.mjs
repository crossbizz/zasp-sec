export function normalizeGatewayBootstrap(value){if(value===undefined)return undefined;throw new Error('gateway bootstrap deployment rejected');}
export function validateGatewayBootstrapResources(){throw new Error('gateway bootstrap deployment rejected');}
