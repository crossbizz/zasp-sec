// Package gatewayenrollmentwire defines the closed device bootstrap protocol.
package gatewayenrollmentwire

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"time"
)

const TokenSchema = "gateway-enrollment-token-v1"
const RequestSchema = "gateway-enrollment-request-v1"
const ReceiptSchema = "gateway-enrollment-receipt-v1"
const MaximumBytes = 4096
const EnrollmentPath = "/internal/v1/runtime-gateway/enrollments"
const AuthorizationScheme = "ZaspGatewayEnrollmentV1"

var ErrInvalid = errors.New("gateway enrollment rejected")

type TokenBundle struct {
	Schema               string    `json:"schema"`
	OrganizationID       string    `json:"organization_id"`
	WorkspaceID          string    `json:"workspace_id"`
	EnvironmentID        string    `json:"environment_id"`
	DeviceID             string    `json:"device_id"`
	EnrollmentID         string    `json:"enrollment_id"`
	TokenGeneration      uint64    `json:"token_generation"`
	CredentialGeneration uint64    `json:"credential_generation"`
	EnrollmentExpiresAt  time.Time `json:"enrollment_expires_at"`
	Locator              string    `json:"locator"`
	Secret               string    `json:"secret"`
}
type Request struct {
	Schema               string    `json:"schema"`
	OrganizationID       string    `json:"organization_id"`
	WorkspaceID          string    `json:"workspace_id"`
	EnvironmentID        string    `json:"environment_id"`
	DeviceID             string    `json:"device_id"`
	EnrollmentID         string    `json:"enrollment_id"`
	TokenGeneration      uint64    `json:"token_generation"`
	CredentialID         string    `json:"credential_id"`
	CredentialGeneration uint64    `json:"credential_generation"`
	KeyID                string    `json:"key_id"`
	Algorithm            string    `json:"algorithm"`
	PublicKey            string    `json:"public_key"`
	ExpiresAt            time.Time `json:"expires_at"`
}
type Receipt struct {
	Schema               string    `json:"schema"`
	RequestSHA256        string    `json:"request_sha256"`
	OrganizationID       string    `json:"organization_id"`
	WorkspaceID          string    `json:"workspace_id"`
	EnvironmentID        string    `json:"environment_id"`
	DeviceID             string    `json:"device_id"`
	EnrollmentID         string    `json:"enrollment_id"`
	TokenGeneration      uint64    `json:"token_generation"`
	CredentialID         string    `json:"credential_id"`
	CredentialGeneration uint64    `json:"credential_generation"`
	KeyID                string    `json:"key_id"`
	Algorithm            string    `json:"algorithm"`
	PublicKey            string    `json:"public_key"`
	Audience             string    `json:"audience"`
	IssuedAt             time.Time `json:"issued_at"`
	ExpiresAt            time.Time `json:"expires_at"`
	Replayed             bool      `json:"replayed"`
}

func (TokenBundle) String() string                   { return "[REDACTED]" }
func (TokenBundle) GoString() string                 { return "[REDACTED]" }
func (TokenBundle) Format(s fmt.State, _ rune)       { _, _ = io.WriteString(s, "[REDACTED]") }
func ParseTokenBundle([]byte) (TokenBundle, error)   { return TokenBundle{}, ErrInvalid }
func MarshalTokenBundle(TokenBundle) ([]byte, error) { return nil, ErrInvalid }
func ParseRequest([]byte) (Request, error)           { return Request{}, ErrInvalid }
func MarshalRequest(Request) ([]byte, error)         { return nil, ErrInvalid }
func ParseReceipt([]byte) (Receipt, error)           { return Receipt{}, ErrInvalid }
func MarshalReceipt(Receipt) ([]byte, error)         { return nil, ErrInvalid }
func Digest([]byte) string                           { return "" }
func RequestMatchesBundle(Request, TokenBundle) bool { return false }
func ReceiptMatches(Receipt, Request, string) bool   { return false }

// SignRequest preserves the caller's enrollment Authorization header and proves
// possession of the private key corresponding to the strict submitted body.
func SignRequest(*http.Request, []byte, func([]byte) ([]byte, error), time.Time) error {
	return ErrInvalid
}
func VerifyRequest(*http.Request, []byte, time.Time) error { return ErrInvalid }
