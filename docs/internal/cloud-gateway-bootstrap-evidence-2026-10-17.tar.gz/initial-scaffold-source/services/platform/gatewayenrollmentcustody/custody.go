// Package gatewayenrollmentcustody retains original device enrollment intent.
package gatewayenrollmentcustody

import (
	"errors"
	wire "github.com/zasp-ai/zasp-sec/services/platform/gatewayenrollmentwire"
	"time"
)

var ErrUnavailable = errors.New("gateway enrollment custody unavailable")

type State string

const (
	StateAbsent   State = "absent"
	StatePending  State = "pending"
	StateAccepted State = "accepted"
)

type Snapshot struct {
	State      State
	RequestRaw []byte
	Request    wire.Request
}
type Store struct{}

func Supported() bool             { return true }
func Open(string) (*Store, error) { return nil, ErrUnavailable }
func (*Store) Prepare(wire.TokenBundle, string, time.Duration, time.Time) (Snapshot, error) {
	return Snapshot{}, ErrUnavailable
}
func (*Store) Snapshot() (Snapshot, error)   { return Snapshot{}, ErrUnavailable }
func (*Store) Sign([]byte) ([]byte, error)   { return nil, ErrUnavailable }
func (*Store) Accept(wire.Receipt) error     { return ErrUnavailable }
func (*Store) ExportCredential(string) error { return ErrUnavailable }
func (*Store) Close() error                  { return nil }
