package gatewaycontrol

import (
	"context"
	wire "github.com/zasp-ai/zasp-sec/services/platform/gatewayenrollmentwire"
)

const EnrollmentPath = "/internal/v1/runtime-gateway/enrollments"

type EnrollmentRepository interface {
	EnrollmentReady(context.Context) error
	EnrollGateway(context.Context, []byte, []byte, []byte) (wire.Receipt, error)
}

func CommitProductionGatewayEnrollment(context.Context, InstallationTransactionPool, []byte, []byte, []byte) (wire.Receipt, error) {
	return wire.Receipt{}, errPostgresRepository
}
