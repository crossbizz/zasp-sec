import type { APIClient } from "../../../apps/web/api/client";
export type GatewayAttempt = Readonly<{idempotencyKey:string}>;
export function createGatewayAttempt():GatewayAttempt{return {idempotencyKey:`gateway_${globalThis.crypto.randomUUID()}`};}
export function createGatewayBootstrapAPI(_client:APIClient){
 return {
  async createGatewayDevice(_value:{name:string},_attempt?:GatewayAttempt):Promise<unknown>{throw new Error("gateway bootstrap unavailable");},
  async getGatewayDevice(_id:string,_signal?:AbortSignal):Promise<unknown>{throw new Error("gateway bootstrap unavailable");},
  async issueGatewayEnrollment(_id:string,_value:{expected_version:number,ttl_seconds:number},_attempt?:GatewayAttempt):Promise<unknown>{throw new Error("gateway bootstrap unavailable");},
  async revokeGatewayEnrollment(_id:string,_enrollmentID:string,_value:{expected_version:number},_attempt?:GatewayAttempt):Promise<unknown>{throw new Error("gateway bootstrap unavailable");},
 };
}
export type GatewayBootstrapAPI=ReturnType<typeof createGatewayBootstrapAPI>;
