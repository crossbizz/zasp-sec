import type {GatewayBootstrapAPI} from './api';
export type GatewayBootstrapAuthority=Readonly<{key:string,permitted:boolean,fresh:boolean,sessionValid:boolean,isCurrent():boolean}>;
export function ProductionGatewayBootstrapView(_props:{api:GatewayBootstrapAPI,authority:GatewayBootstrapAuthority,onReauthenticate():void}){return <section aria-label="Runtime gateways"><p>Gateway bootstrap unavailable</p></section>;}
