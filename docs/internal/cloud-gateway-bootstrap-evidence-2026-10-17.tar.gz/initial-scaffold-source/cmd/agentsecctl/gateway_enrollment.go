package main

import "time"

// Initial acceptance clock seam only. Command routing and product logic are held
// until root records the grouped baseline. Native database clocks are unchanged.
var gatewayEnrollmentNow = func() time.Time { return time.Now().UTC().Truncate(time.Second) }
