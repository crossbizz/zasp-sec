import base64, hashlib, json, os, signal, subprocess, tempfile, time
from pathlib import Path
out = Path('/tmp/reviewer-token-publisher-evidence-20261017')
binary = out / 'gateway-reviewer-publisher'
def enc(value):
    return base64.urlsafe_b64encode(value).rstrip(b'=').decode()
def token(label):
    return '.'.join([enc(b'{"alg":"RS256","typ":"JWT"}'), enc(json.dumps({'exp': int(time.time()) + 3600, 'fixture': label}, separators=(',', ':')).encode()), enc(b'local-component-signature')]).encode()
record = {'qualification': 'Actual standalone CLI/filesystem/rotation/SIGTERM component; synthetic local JWT, no Kubernetes authentication, provider or deployed evidence.'}
with tempfile.TemporaryDirectory() as raw:
    root = Path(raw); source = root / 'source'; destination = root / 'private'
    source.mkdir(mode=0o700); destination.mkdir(mode=0o700)
    def rotate(name, value):
        generation = source / name; generation.mkdir(mode=0o700)
        path = generation / 'token'; path.write_bytes(value); path.chmod(0o440)
        (source / '..next').symlink_to(name); os.replace(source / '..next', source / '..data')
    first = token('first'); second = token('second')
    rotate('..first', first); (source / 'token').symlink_to('..data/token')
    command = [str(binary), '-source-directory', str(source), '-source-name', 'token', '-destination-directory', str(destination), '-poll-interval', '250ms', '-minimum-remaining-lifetime', '5s']
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    def await_value(expected):
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise AssertionError('publisher exited before expected state')
            try:
                path = destination / 'credential'
                if path.read_bytes() == expected:
                    stat = path.lstat()
                    assert stat.st_uid == os.getuid() and stat.st_mode & 0o777 == 0o600 and stat.st_nlink == 1
                    return
            except FileNotFoundError:
                pass
            time.sleep(0.01)
        raise AssertionError('publisher state deadline exceeded')
    try:
        await_value(first); rotate('..second', second); await_value(second)
        process.send_signal(signal.SIGTERM)
        stdout, stderr = process.communicate(timeout=5)
        assert process.returncode == 0 and not stdout and not stderr
        assert not (destination / 'credential').exists() and not (destination / '.credential.next').exists()
        record.update(status='PASS', exit_code=process.returncode, rotation_observed=True, cancellation_joined=True, owned_output_withdrawn=True, stdout_bytes=len(stdout), stderr_bytes=len(stderr), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
    finally:
        if process.poll() is None:
            process.terminate()
            try: process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill(); process.communicate(timeout=2)
(out / 'actual-cli-component.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
