from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/workspace/zasp-node-coverage-retention');work=Path('/tmp/oct27-launch-final')
manifest=root/'.github/connector-native-compile-source-pins.json';old=manifest.read_bytes();data=json.loads(old);assert len(data['sources'])==926
source='services/platform/migrations/sql/retention_successor.sql'
runners=['scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs']
def sha(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
(work/'source-pins-before.json').write_bytes(old)
for p in runners:
 text=(root/p).read_text();(work/(Path(p).name+'.before')).write_text(text);m=re.search(r'const pins = (\{.*?\n\});',text,re.S);pins=json.loads(m[1]);assert source in pins;pins[source]=sha(source);(root/p).write_text(text[:m.start(1)]+json.dumps(pins,indent=2)+text[m.end(1):])
changed=[]
for item in data['sources']:
 p=item['path']
 if sha(p)!=item['sha256']:
  assert p in [source]+runners,p
  changed.append({'path':p,'beforeSHA256':item['sha256'],'afterSHA256':sha(p)});item['sha256']=sha(p);item['bytes']=(root/p).stat().st_size
assert len(changed)==3
data['retentionProceduralSuccessorSourceAssociationBase']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();data['retentionProceduralSuccessorPredecessorManifestSHA256']=hashlib.sha256(old).hexdigest();manifest.write_text(json.dumps(data,indent=2)+'\n')
prior=json.loads(old)
assert [x['path'] for x in prior['sources']]==[x['path'] for x in data['sources']]
for a,b in zip(prior['sources'],data['sources']):assert all(a[k]==b[k] for k in a if k not in ['sha256','bytes'])
for x in data['sources']:assert sha(x['path'])==x['sha256'] and (root/x['path']).stat().st_size==x['bytes']
# Exhaustive current script path/hash literals, including the third native runner.
assoc=[]
pattern=re.compile(r'''["']([^"'\n]+)["']\s*:\s*["']([0-9a-f]{64})["']''')
for p in (root/'scripts').rglob('*'):
 if p.suffix not in ['.mjs','.json'] or not p.is_file():continue
 for path,pin in pattern.findall(p.read_text()):
  target=root/path
  if target.is_file():
   assert sha(path)==pin,(str(p.relative_to(root)),path)
   assoc.append([str(p.relative_to(root)),path,pin])
assert len(assoc)==1824,len(assoc)
(work/'custody-verification.json').write_text(json.dumps({'bindings':926,'all_hashes_bytes_match':True,'paths_order_preimage_fields_preserved':True,'current_script_associations':len(assoc),'all_current_script_associations_match':True,'changed':changed,'predecessor_manifest_SHA256':hashlib.sha256(old).hexdigest()},indent=2)+'\n')
print('All926manifest bindings and1824current script associations match; original paths/order/preimages retained')
