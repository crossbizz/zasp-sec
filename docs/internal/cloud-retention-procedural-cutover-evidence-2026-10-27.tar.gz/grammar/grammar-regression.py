"""Offline application SQL generation witness; no PostgreSQL runtime/catalog proof."""
from pathlib import Path
import re,json,hashlib,sys
from pglast import parse_plpgsql
ROOT=Path('/workspace/zasp-node-coverage-retention');OUT=Path('/tmp/oct27-retention-cutover')
recipe=Path(sys.argv[1]).read_text();old=(OUT/'retention_successor.sql.before').read_text()
graph=(ROOT/'services/platform/migrations/sql/0080_authorization_worker_audit_readiness_graph.sql').read_text()
data=json.loads(re.search(r'\$higher_records\$(.*?)\$higher_records\$',graph,re.S)[1]);region=next(x for x in data['regions'] if x['signature']=='zasp_temporal68.predecessor_ready(text,text)')
body=region['prefix']+'('+region['query']+')'+region['suffix']
# These are exactly the pre-existing metadata substitutions in both recipes.
body=body.replace('pg_get_functiondef(p.oid)','zasp_retention_v1.projected_definition(p.oid)').replace('pg_get_functiondef(procedure.oid)','zasp_retention_v1.projected_definition(procedure.oid)')
body=re.sub(r'\bp\.prosrc\b','zasp_retention_v1.projected_source(p.oid)',body)
original=(ROOT/'services/platform/migrations/sql/0067_production_temporal_domain.up.sql').read_text()
header=re.search(r'(CREATE FUNCTION zasp_temporal67\.ready\(c text,f text\).*? AS \$ready\$)',original,re.S)[1]
header=header.replace('FUNCTION zasp_temporal67.ready(', 'FUNCTION zasp_temporal68.predecessor_ready(')
assert 'LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO pg_catalog,public' in header
frame=lambda b:header+b+'$ready$;'
# Extract actual RHS string literals; no guessed/handwritten successor SQL.
quoted=r"'((?:[^']|'')*)'"
unquote=lambda s:s.replace("''", "'")
entry=re.search(r"s:=zasp_retention_v1\.replace_exact\(s,chr\(10\)\|\|"+quoted+r",chr\(10\)\|\|"+quoted+r"\|\|chr\(10\)\|\|"+quoted+r",1\);",recipe)
if entry:
 needle='\n'+unquote(entry[1]);replacement='\n'+unquote(entry[2])+'\n'+unquote(entry[3])
 def generate(b):
  if b.count(needle)!=1:raise ValueError('exact predecessor entry anchor refused')
  return b.replace(needle,replacement)
else:
 scalar=re.findall(r"s:="+quoted+r"\|\|s\|\|"+quoted+r";",recipe)
 assert scalar
 prefix,suffix=(unquote(v) for v in scalar[0])
 def generate(b):return prefix+re.sub(r';\s*$','',b.strip())+suffix
results=[]
def case(name,fn):
 try:fn();results.append({'name':name,'result':'PASS'})
 except Exception as e:results.append({'name':name,'result':'FAIL','class':type(e).__name__,'message':str(e)[:220]})
def require(v,message):
 if not v:raise AssertionError(message)
case('original_captured_procedural_frame_parses',lambda:parse_plpgsql(frame(body)))
generated=generate(body)
case('generated_procedural_successor_parses',lambda:parse_plpgsql(frame(generated)))
case('full_procedural_body_preserved_with_only_entry_guard',lambda:require(entry is not None and generated.count(replacement)==1 and generated.replace(replacement,needle)==body,'original declarations/guards/loops/return changed or entry guard absent'))
case('captured_security_frame_preserved',lambda:require(frame(generated).startswith(header) and frame(generated).endswith('$ready$;'),'captured language/volatility/security/search_path frame changed'))
def refused(b):
 try:generate(b)
 except ValueError:return
 raise AssertionError('changed predecessor entry anchor accepted')
anchor='\n IF c IS DISTINCT FROM '
case('missing_entry_anchor_refused',lambda:refused(body.replace(anchor,'\n IF owned_missing_anchor IS DISTINCT FROM ')))
case('duplicate_entry_anchor_refused',lambda:refused(body+anchor))
# Actual SQL branch expressions remain byte-identical, so all 16 SQL targets
# retain their original transformation. No invented pg_proc capture is claimed.
def scalar_expressions(s):return re.findall(r"s:='SELECT[^\n]*",s)
case('all_original_scalar_SQL_assignment_bytes_unchanged',lambda:require(scalar_expressions(old)==scalar_expressions(recipe),'scalar SQL assignments changed'))
targets=re.findall(r"\('([^']+)','catalog'\)",recipe)
renames={'zasp_authorization80_worker.projected_domain()':'zasp_authorization80_temporal.projected_domain','zasp_temporal68.predecessor_ready(text,text)':'zasp_temporal67.ready','zasp_temporal77.base67_fingerprint()':'zasp_temporal67.fingerprint','zasp_temporal72.retained_precision_fingerprint()':'public.zasp_production_runtime_precision_live_fingerprint'}
inventory=[]
for target in targets:
 name=renames.get(target,target.split('(')[0]);definitions=[]
 for file in (ROOT/'services/platform/migrations/sql').glob('*.sql'):
  # 68 copies the saved original67 PL/pgSQL ready BEFORE replacing67ready
  # with its separate SQL forwarding wrapper. Select the captured declaration.
  if target=='zasp_temporal68.predecessor_ready(text,text)' and file.name!='0067_production_temporal_domain.up.sql':continue
  for match in re.finditer(r'^CREATE(?: OR REPLACE)? FUNCTION\s+'+re.escape(name)+r'\([^\n]*?\)[^\n]*?LANGUAGE\s+(\w+)',file.read_text(),re.I|re.M):definitions.append({'path':str(file.relative_to(ROOT)),'language':match[1].lower(),'header':match[0]})
 langs={v['language'] for v in definitions}
 inventory.append({'signature':target,'languages':sorted(langs),'source_definitions':definitions,'provenance':'Exact source declarations; renamed targets trace immutable rename chain. Dynamic final base67 readiness fusion not reconstructed/captured offline.'})
case('all_17_declared_languages_inventory',lambda:require(len(inventory)==17 and sum(v['languages']==['plpgsql'] for v in inventory)==1 and sum(v['languages']==['sql'] for v in inventory)==16,'catalog language inventory incomplete or unexpected'))
label='green' if entry else 'red';(OUT/(label+'-generated-definition.sql')).write_text(frame(generated));(OUT/'reconstructed-audit-procedural-body.sql').write_text(body)
report={'classification':'OFFLINE_APPLICATION_GENERATED_SQL_GRAMMAR_ONLY','recipe':sys.argv[1],'parser':'official pglast 8.7 parse_plpgsql','cases':results,'passed':sum(v['result']=='PASS' for v in results),'failed':sum(v['result']=='FAIL' for v in results),'source_inventory':inventory,'limits':'No native PostgreSQL installation, live catalog fingerprint, privilege, cutover or deployed acceptance. Procedural body reconstructed from repository Audit higher_records region template; unresolved compiled checksum literals are not authenticated native pg_proc capture. Other16 SQL transformation assignment bytes unchanged, not full native rendered definitions.'}
(OUT/(label+'-grammar-report.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'label':label,'passed':report['passed'],'failed':report['failed'],'cases':results},indent=2));sys.exit(bool(report['failed']))
