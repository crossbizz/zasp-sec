import json,hashlib,re,subprocess
from pathlib import Path
root=Path('/workspace/zasp-node-coverage-retention'); work=Path('/tmp/oct21-retention-final')
manifest=root/'.github/connector-native-compile-source-pins.json'; original=manifest.read_bytes(); data=json.loads(original)
assert len(data['sources'])==926
source='services/platform/apiserver/retention_native_postgres_test.go'
runners=['scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs']
def sha(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
(work/'source-pins-before.json').write_bytes(original)
for p in runners:
 text=(root/p).read_text();(work/(Path(p).name+'.before')).write_text(text)
 m=re.search(r'const pins = (\{.*?\n\});',text,re.S);pins=json.loads(m[1]);assert source in pins;pins[source]=sha(source)
 (root/p).write_text(text[:m.start(1)]+json.dumps(pins,indent=2)+text[m.end(1):])
changed=[]
for item in data['sources']:
 p=item['path']
 if sha(p)!=item['sha256']:
  assert p in [source]+runners,p
  changed.append({'path':p,'beforeSHA256':item['sha256'],'afterSHA256':sha(p)})
  item['sha256']=sha(p);item['bytes']=(root/p).stat().st_size
assert len(changed)==3
data['retentionNoInheritFixtureSourceAssociationBase']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
data['retentionNoInheritFixturePredecessorManifestSHA256']=hashlib.sha256(original).hexdigest()
manifest.write_text(json.dumps(data,indent=2)+'\n')
old=json.loads(original)
assert [v['path'] for v in old['sources']]==[v['path'] for v in data['sources']]
for a,b in zip(old['sources'],data['sources']):assert all(a[k]==b[k] for k in a if k not in ['sha256','bytes'])
for item in data['sources']:assert sha(item['path'])==item['sha256'] and (root/item['path']).stat().st_size==item['bytes']
report={'bindings':926,'all_hashes_bytes_match':True,'all_paths_order_preimage_fields_unchanged':True,'changed':changed,'predecessorSHA256':hashlib.sha256(original).hexdigest()}
(work/'custody-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
