import json,pathlib,subprocess
x=json.load(open('/tmp/current-superseded-queued-qualified-20261017.json'));base='repos/crossbizz/zasp-sec'
def get(path):return json.loads(subprocess.run(['gh','api',base+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25,check=True).stdout)
assert get('/pulls/60')['head']['sha']==x['keep']
receipts=[];p=pathlib.Path('/tmp/current-superseded-queued-cancel-receipts-20261017.json')
for candidate in x['results']:
 if not candidate['eligible']:continue
 runid=candidate['id'];row={'id':runid,'head_sha':candidate['head_sha'],'cancel_requested':False}
 try:
  info=get('/actions/runs/'+str(runid));data=get('/actions/runs/'+str(runid)+'/jobs?per_page=100');jobs=data['jobs']
  safe=info['head_sha']==candidate['head_sha'] and info['head_sha'] in x['explicit_superseded_own_heads'] and info['head_sha']!=x['keep'] and info['head_branch']=='codex/connector-native-api-worker-20261008' and info['status']=='queued' and info['conclusion'] is None and data['total_count']==len(jobs) and bool(jobs) and all(j['status']=='queued' and j['conclusion'] is None and not j.get('runner_id') and not j.get('runner_name') and not j.get('steps') for j in jobs)
  if safe:
   result=subprocess.run(['gh','api','--method','POST',base+'/actions/runs/'+str(runid)+'/cancel'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25)
   row.update(cancel_requested=result.returncode==0,exit_code=result.returncode)
  else:row['preserved']='Run or job state changed; no cancellation.'
 except Exception as exc:row['error_class']=type(exc).__name__
 receipts.append(row);p.write_text(json.dumps({'kept_head':x['keep'],'qualification':'Sequential cancellation only after immediate recheck of superseded own head and entirely queued/unassigned jobs; currenthead and every started work item preserved. Requests are not confirmed conclusions.','receipts':receipts},indent=2)+'\n')
 if len(receipts)%10==0:print(json.dumps({'processed':len(receipts),'accepted':sum(z['cancel_requested'] for z in receipts)}),flush=True)
print(json.dumps({'processed':len(receipts),'accepted':sum(z['cancel_requested'] for z in receipts)}))
