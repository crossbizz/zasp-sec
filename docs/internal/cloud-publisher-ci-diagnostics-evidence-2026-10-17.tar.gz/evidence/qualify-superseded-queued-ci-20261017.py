import concurrent.futures,json,pathlib,subprocess
keep='5f9a4edf26733268ecc9b6464481f21fb9b8efb5'
old={'dfec8c9d921d27ee28b3b0861027aa8ccbafd8e1','ec877795fdaf6cce989d60aacc78ea519f122d91','ccbaa28ede1e07fac9d5dc47858ed337b2766c94','e949a44c5a7cbd07b42e60b94ae49fbd5fcc06dc'}
base='repos/crossbizz/zasp-sec'
def get(path):return json.loads(subprocess.run(['gh','api',base+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25,check=True).stdout)
assert get('/pulls/60')['head']['sha']==keep
runs=json.load(open('/tmp/current-branch-ci-queue-20261017.json'))['runs']
def qualify(run):
 try:
  info=get('/actions/runs/'+str(run['id']))
  data=get('/actions/runs/'+str(run['id'])+'/jobs?per_page=100');jobs=data['jobs']
  safe=info['head_sha'] in old and info['status']=='queued' and info['conclusion'] is None and info['head_branch']=='codex/connector-native-api-worker-20261008' and data['total_count']==len(jobs) and bool(jobs) and all(j['status']=='queued' and j['conclusion'] is None and not j.get('runner_id') and not j.get('runner_name') and not j.get('steps') for j in jobs)
  return {'id':run['id'],'head_sha':info['head_sha'],'name':run['name'],'eligible':safe,'jobs':[{'id':j['id'],'status':j['status'],'conclusion':j['conclusion'],'runner_id':j.get('runner_id'),'runner_name':j.get('runner_name'),'steps_count':len(j.get('steps') or [])} for j in jobs]}
 except Exception as exc:return {'id':run['id'],'eligible':False,'error_class':type(exc).__name__}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(qualify,[r for r in runs if r['status']=='queued' and r['head_sha'] in old]))
p=pathlib.Path('/tmp/current-superseded-queued-qualified-20261017.json');p.write_text(json.dumps({'keep':keep,'explicit_superseded_own_heads':sorted(old),'results':results},indent=2)+'\n');print(json.dumps({'candidates':len(results),'eligible':sum(r['eligible'] for r in results),'errors':sum('error_class' in r for r in results)}))
