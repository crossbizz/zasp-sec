import base64, hashlib, json, os, subprocess, tempfile, time, uuid
from pathlib import Path
out=Path('/tmp/reviewer-publisher-image-evidence-20261017')
image=(out/'image-id').read_text().strip()
docker=['env','-u','DOCKER_HOST','-u','DOCKER_CONTEXT','-u','DOCKER_TLS','-u','DOCKER_TLS_VERIFY','-u','DOCKER_CERT_PATH','docker','--host=unix:///var/run/docker.sock']
def call(*args):
    return subprocess.run(docker+list(args),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=True)
def enc(value):return base64.urlsafe_b64encode(value).rstrip(b'=')
def token(label):return b'.'.join([enc(b'{"alg":"RS256","typ":"JWT"}'),enc(json.dumps({'exp':int(time.time())+3600,'fixture':label},separators=(',',':')).encode()),enc(b'local-container-fixture-signature')])
record={'qualification':'Actual local container/filesystem component with explicit current UID override; synthetic local JWT. Not default UID65532, Kubernetes, authentication, registry publication or deployed evidence.','image_id':image,'uid_override':os.getuid()}
cid=None
try:
    image_metadata=json.loads(call('image','inspect',image,'--format','{{json .Config}}').stdout)
    assert image_metadata['User']=='65532:65532' and image_metadata['Entrypoint']==['/gateway-reviewer-publisher']
    # Persist selected non-secret image fields only; never persist injected environment.
    record['configured_image_user']=image_metadata['User'];record['entrypoint']=image_metadata['Entrypoint']
    with tempfile.TemporaryDirectory() as raw:
        root=Path(raw);source=root/'source';private=root/'private';source.mkdir(mode=0o700);private.mkdir(mode=0o700)
        def rotate(name,value):
            generation=source/name;generation.mkdir(mode=0o700);path=generation/'token';path.write_bytes(value);path.chmod(0o440)
            (source/'..next').symlink_to(name);os.replace(source/'..next',source/'..data')
        first=token('first');second=token('second');rotate('..first',first);(source/'token').symlink_to('..data/token')
        args=['create','--name','zasp-reviewer-component-'+uuid.uuid4().hex[:12],'--user',f'{os.getuid()}:{os.getgid()}','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges=true','--network','none','--pids-limit','32','--memory','64m','--mount',f'type=bind,src={source},dst=/source,readonly','--mount',f'type=bind,src={private},dst=/private',image,'-source-directory','/source','-source-name','token','-destination-directory','/private','-poll-interval','250ms','-minimum-remaining-lifetime','5s']
        cid=call(*args).stdout.decode().strip();call('start',cid)
        def await_value(expected):
            deadline=time.monotonic()+8
            while time.monotonic()<deadline:
                try:
                    p=private/'credential'
                    if p.read_bytes()==expected:
                        s=p.lstat();assert s.st_uid==os.getuid() and s.st_mode&0o777==0o600 and s.st_nlink==1;return
                except FileNotFoundError:pass
                time.sleep(0.02)
            raise AssertionError('container publication state deadline exceeded')
        await_value(first);rotate('..second',second);await_value(second)
        call('stop','--signal','SIGTERM','--timeout','5',cid)
        exit_code=int(call('wait',cid).stdout.decode().strip());logs=call('logs',cid)
        assert exit_code==0 and not logs.stdout and not logs.stderr
        assert not (private/'credential').exists() and not (private/'.credential.next').exists()
        record.update(status='PASS',exit_code=exit_code,rotation_observed=True,owned_output_withdrawn=True,signal_shutdown_joined=True,network='none',read_only_rootfs=True,capabilities_dropped='ALL',no_new_privileges=True)
except Exception as exc:
    record.update(status='FAIL',error_class=type(exc).__name__)
    raise
finally:
    if cid is not None:
        cleanup=subprocess.run(docker+['rm','--force',cid],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        record['owned_container_removed']=cleanup.returncode==0
    (out/'actual-container-component.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
