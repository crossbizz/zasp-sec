import {releaseStageError} from "../../scripts/release-failure-stages.mjs";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import net from "node:net";
import path from "node:path";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";

import { inspectContainerBuilds, renderRelease } from "./release-contract.mjs";
import { productionReleaseFixture } from "./release-fixture.mjs";

const exec = promisify(execFile);
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../..");
const requiredHeaders = Object.freeze(["strict-transport-security", "content-security-policy", "x-frame-options", "x-content-type-options", "referrer-policy", "permissions-policy"]);
const productID = /^pid_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const traceparent = /^00-([0-9a-f]{32})-([0-9a-f]{16})-(?:00|01)$/;

export async function loadReleasePolicy() {
  return deepFreeze({
    performance: { webP95Milliseconds: 2000, apiReadP95Milliseconds: 500, apiMutationP95Milliseconds: 1000, errorRatePercent: 1 },
    resilience: ["replica_restart", "provider_timeout", "queue_redrive", "stale_read_revalidation"],
    supplyChain: ["npm_spdx_sbom", "go_spdx_sbom", "license_allowlist", "offline_dependency_audit", "digest_pinned_container_definition", "full_tracked_gitleaks", "required_ci_gate"],
    proof: { ownedPrefix: "zasp-production-e2e-", ambientMutation: false },
  });
}

export async function runReadOnlySynthetic({ origin, token, allowHTTPLoopback = false }) {
  const parsed = new URL(origin);
  const loopback = net.isIP(parsed.hostname) !== 0 && (parsed.hostname === "127.0.0.1" || parsed.hostname === "::1");
  if ((parsed.protocol !== "https:" && !(allowHTTPLoopback && parsed.protocol === "http:" && loopback)) || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash || token.length < 32 || token.length > 4096 || token.trim() !== token) throw new Error("synthetic rejected");

  const webStarted = performance.now();
  const web = await fetch(new URL("/sign-in", parsed), { redirect: "manual", signal: AbortSignal.timeout(5000) });
  await web.arrayBuffer();
  const webMilliseconds = Math.ceil(performance.now() - webStarted);
  if (web.status !== 200 || requiredHeaders.some((name) => !web.headers.has(name)) || webMilliseconds > 2000) throw new Error("synthetic rejected");

  const apiStarted = performance.now();
  const api = await fetch(new URL("/api/v1/home/summary", parsed), { headers: { Authorization: `Bearer ${token}` }, redirect: "manual", signal: AbortSignal.timeout(5000) });
  await api.arrayBuffer();
  const apiMilliseconds = Math.ceil(performance.now() - apiStarted);
  const correlationID = api.headers.get("x-correlation-id") ?? "";
  const trace = traceparent.exec(api.headers.get("traceparent") ?? "");
  if (api.status !== 200 || !productID.test(correlationID) || !trace || /^0+$/.test(trace[1]) || /^0+$/.test(trace[2]) || apiMilliseconds > 500) throw new Error("synthetic rejected");
  return deepFreeze({ apiMilliseconds, correlationID, traceID: trace[1], webMilliseconds });
}

export async function verifyReleaseSources() {
  let failureStage = "sources-render";
  try {
  // Evaluate the actual initializer/worker ordering in every supported phase.
  // A literal hook-weight string in the template doesn't prove rendered order.
  const renderedRollouts = [];
  for (const [schemaVersion, phase] of [
    [48, "compatibility"], [49, "compatibility"],
    [50, "backfill"], [50, "query"],
    [51, "precision-consumers"], [51, "precision-intake"],
    [52, "precision-consumers"], [52, "precision-intake"],
    [53, "precision-consumers"], [53, "precision-intake"],
    [54, "precision-consumers"], [54, "precision-intake"],
  ]) {
    const resources = await renderRelease(productionReleaseFixture, { schemaVersion, sessionSearchPhase: phase });
    const schemaJobs = resources.filter(resource => resource.kind === "Job" && resource.metadata.name.startsWith("agentsec-schema-v"));
    if (schemaJobs.length !== 1 || schemaJobs[0].metadata.name !== `agentsec-schema-v${schemaVersion}`) throw new Error("rendered rollout schema gate rejected");
    renderedRollouts.push({ schemaVersion, phase, schemaJob: schemaJobs[0].metadata.name });
  }
  failureStage = "sources-images";
  const builds = await inspectContainerBuilds();
  if (builds.length !== 9 || builds.some((build) => !build.readOnlyCompatible || build.containsSecret)) throw new Error("container gate rejected");

  failureStage = "sources-canary";
  const canary = await source("deploy/staging/product/templates/canary.yaml");
  const monitoring = await source("deploy/staging/product/templates/monitoring.yaml");
  if (!canary.includes("production-readonly-canary") || !canary.includes("/api/v1/home/summary") || !canary.includes("ZASP_CANARY_READ_TOKEN") || !monitoring.includes("ZaspAPIErrorBudgetBurn") || !monitoring.includes("> 0.01")) throw new Error("canary gate rejected");

  failureStage = "sources-documentation";
  const requiredDocs = ["production-deployment.md", "backup-restore-rollback.md", "recovery-runbook.md", "observability-and-canaries.md", "authentication-and-support.md", "supported-workflows.md"];
  const docs = await Promise.all(requiredDocs.map((name) => source(`docs/operations/${name}`)));
  for (const phrase of ["schema v27", "Do not run `agentsec-migrate down`", "correlation ID", "must not ask", "not supported production workflows", "recovery hold", "cleanup_failed"]) {
    if (!docs.some((document) => document.includes(phrase))) throw new Error("documentation gate rejected");
  }

  failureStage = "sources-npm-sbom";
  const { stdout } = await exec("npm", ["sbom", "--omit=dev", "--sbom-format", "spdx", "--json"], { cwd: root, encoding: "utf8", maxBuffer: 16 * 1024 * 1024 });
  const sbom = JSON.parse(stdout);
  if (sbom.spdxVersion !== "SPDX-2.3" || !Array.isArray(sbom.packages) || sbom.packages.length < 2) throw new Error("SBOM gate rejected");
  const allowed = new Set(["0BSD", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "ISC", "MIT", "MPL-2.0"]);
  failureStage = "sources-npm-license";
  for (const entry of sbom.packages) {
    const license = entry.licenseConcluded ?? entry.licenseDeclared;
    if (entry.name === "zasp-agent-security-console" && license === "NOASSERTION") continue;
    if (!allowed.has(license)) throw new Error(`license gate rejected: ${entry.name}`);
  }

  failureStage = "sources-go-sbom";
  const goSpdx = await goSourceSBOM();
  validateGoSpdxDocument(goSpdx);
  if (goSpdx.packages.length < 20) throw new Error("Go SBOM gate rejected");
  failureStage = "sources-go-license";
  for (const entry of goSpdx.packages) {
    if (entry.licenseConcluded !== "NOASSERTION" && !allowed.has(entry.licenseConcluded)) throw new Error(`Go license gate rejected: ${entry.name}`);
    if (entry.licenseConcluded === "NOASSERTION" && !entry.name.startsWith("github.com/zasp-ai/zasp-sec/")) throw new Error(`Go license gate rejected: ${entry.name}`);
  }

  failureStage = "sources-contracts";
  const sensitiveSources = await Promise.all([
    source(".dockerignore"), source("deploy/production/api.Dockerfile"), source("deploy/production/web.Dockerfile"), source("deploy/production/worker.Dockerfile"),
    source("deploy/production/event-ingest.Dockerfile"), source("deploy/production/gateway-control.Dockerfile"), source("deploy/production/runtime-gateway.Dockerfile"), source("deploy/production/sensor-agent.Dockerfile"),
    source("deploy/staging/product/values.yaml"), source("deploy/staging/product/templates/secrets.yaml"), source("deploy/staging/product/templates/workloads.yaml"), source("deploy/staging/product/templates/runtime.yaml"), source("deploy/staging/product/templates/edge.yaml"),
    source("deploy/staging/product/templates/nango.yaml"), source("deploy/staging/product/templates/otel-collector.yaml"), source("deploy/production/redteam-worker.Dockerfile"), source("deploy/staging/product/templates/red-team.yaml"),
    source("deploy/staging/product/templates/attack-lab.yaml"), source("deploy/production/attack-lab-runner.Dockerfile"),
  ]);
  const combined = sensitiveSources.join("\n");
  if (/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|AKIA[0-9A-Z]{16}|sk_live_[A-Za-z0-9]{16,}/.test(combined) || !sensitiveSources[0].includes(".env") || !sensitiveSources[9].includes("secretsmanager") || ![sensitiveSources[10], sensitiveSources[11], sensitiveSources[12]].join("\n").includes("/var/run/secrets/zasp")) throw new Error("secret gate rejected");
  const terraform = await source("deploy/staging/main.tf");
  for (const contract of ["system:serviceaccount:agentsec:agentsec-api", "system:serviceaccount:agentsec:zasp-discovery-worker", "system:serviceaccount:agentsec:zasp-discovery-scheduler", "system:serviceaccount:agentsec:zasp-security-agent", "system:serviceaccount:agentsec:zasp-security-agent-action", "system:serviceaccount:agentsec:zasp-policy-deployment", "system:serviceaccount:agentsec:zasp-outbox-publisher", "system:serviceaccount:agentsec:zasp-recovery-backup-outbox", "system:serviceaccount:agentsec:zasp-recovery-restore-outbox", "system:serviceaccount:agentsec:zasp-recovery-backup", "system:serviceaccount:agentsec:zasp-recovery-restore", "system:serviceaccount:agentsec:zasp-red-team-outbox", "system:serviceaccount:agentsec:zasp-red-team-worker", "system:serviceaccount:agentsec:zasp-red-team-adapter", "system:serviceaccount:agentsec:zasp-attack-lab-outbox", "system:serviceaccount:agentsec:zasp-attack-lab-controller", "system:serviceaccount:agentsec:zasp-attack-lab-proxy", "system:serviceaccount:agentsec:zasp-projection-risk", "system:serviceaccount:agentsec:zasp-projection-graph", "system:serviceaccount:agentsec:zasp-projection-search", "system:serviceaccount:agentsec:agentsec-projection-graph-init", "system:serviceaccount:agentsec:agentsec-projection-search-init", "system:serviceaccount:agentsec:agentsec-migration", "system:serviceaccount:agentsec:agentsec-canary-secret-sync", "system:serviceaccount:agentsec:zasp-runtime-ingest", "system:serviceaccount:agentsec:zasp-gateway-control", "system:serviceaccount:agentsec:zasp-runtime-outbox", "system:serviceaccount:agentsec:zasp-runtime-coordinator", "system:serviceaccount:agentsec:zasp-runtime-archive", "system:serviceaccount:agentsec:zasp-runtime-index", "system:serviceaccount:agentsec:zasp-runtime-correlation", "system:serviceaccount:agentsec:zasp-runtime-projection", "system:serviceaccount:agentsec:zasp-runtime-complete", "secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret", "sqs:SendMessage", "sqs:ReceiveMessage", "sqs:ChangeMessageVisibility", "s3:PutObject", "recovery-backup-jobs", "recovery-restore-jobs", "discovery-jobs", "red-team-tests", "attack-lab-jobs", "runtime-events", "red_team_evidence", "attack_lab_evidence", "zasp-inventory-v1/_mapping", "zasp-runtime-events-v1", "_zasp_schema_v1", "neo4j/auth/runtime", "neo4j/auth/schema", "canary-read-token", "token-reveal-key", "stytch-secret", "stytch-webhook-secret", "gateway-policy-signing-private-key", "attack-lab-egress-signing-key", "attack-lab-proxy-tls-certificate", "attack-lab-proxy-tls-private-key", "zasp-recovery/neon/project-api-key", "postgres-api-dsn", "postgres-security-agent-worker-dsn", "postgres-security-agent-action-worker-dsn", "postgres-policy-deployment-worker-dsn", "postgres-worker-dsn", "postgres-outbox-worker-dsn", "postgres-recovery-outbox-worker-dsn", "postgres-recovery-worker-dsn", "postgres-red-team-outbox-dsn", "postgres-red-team-worker-dsn", "postgres-red-team-adapter-dsn", "postgres-attack-lab-controller-dsn", "postgres-attack-lab-outbox-dsn", "postgres-attack-lab-proxy-dsn", "postgres-runtime-ingest-dsn", "postgres-runtime-coordinator-dsn", "postgres-runtime-archive-dsn", "postgres-runtime-index-dsn", "postgres-runtime-correlation-dsn", "postgres-runtime-projection-dsn", "postgres-gateway-control-dsn", "postgres-scheduler-dsn", "postgres-projection-risk-dsn", "postgres-projection-graph-dsn", "postgres-projection-search-dsn", "postgres-migration-dsn"]) {
    if (!terraform.includes(contract)) throw new Error("secret identity gate rejected");
  }
  const [workloads, services, redTeamWorkloads, attackLabWorkloads, runtimeWorkloads, projectionInit, resilience, nango, collector] = await Promise.all([
    source("deploy/staging/product/templates/workloads.yaml"), source("deploy/staging/product/templates/services.yaml"), source("deploy/staging/product/templates/red-team.yaml"), source("deploy/staging/product/templates/attack-lab.yaml"), source("deploy/staging/product/templates/runtime.yaml"), source("deploy/staging/product/templates/projection-init.yaml"), source("deploy/staging/product/templates/resilience.yaml"), source("deploy/staging/product/templates/nango.yaml"), source("deploy/staging/product/templates/otel-collector.yaml"),
  ]);
  for (const contract of ["ZASP_WORKER_MODE", "security-agent", "security-agent-action", "policy-deployment", "zasp_security_agent_worker", "zasp_security_agent_action_worker", "zasp_policy_deployment_worker", "ZASP_GATEWAY_SIGNING_KEY_ID", "ZASP_GATEWAY_SIGNING_PRIVATE_KEY_FILE", "projection-risk", "projection-graph", "projection-search", "recovery-outbox", "ZASP_RECOVERY_OPERATION_KIND", "ZASP_RECOVERY_SIGNING_KMS_KEY_ARN", "ZASP_RECOVERY_KUBERNETES_ENDPOINT", "ZASP_NEO4J_EXPECTED_PRINCIPAL", "ZASP_NEO4J_EXPECTED_ROLE"]) if (!workloads.includes(contract)) throw new Error("worker deployment gate rejected");
  for (const contract of ["agentsec-recovery-controller", "agentsec-recovery-namespace-operator", "ValidatingAdmissionPolicy", "agentsec-recovery-namespace-fence"]) if (!services.includes(contract)) throw new Error("recovery runner authority gate rejected");
  for (const contract of ["agentsec-red-team-outbox", "agentsec-red-team-worker", "agentsec-red-team-adapter", "red-team-outbox", "zasp_red_team_worker", "zasp_red_team_adapter", "ZASP_RED_TEAM_TARGET_ENDPOINT", "ZASP_RED_TEAM_TARGET_CA_FILE", "ZASP_RED_TEAM_ADAPTER_TLS_CERT_FILE", "HorizontalPodAutoscaler", "PodDisruptionBudget", "NetworkPolicy", "ServiceMonitor"]) if (!redTeamWorkloads.includes(contract)) throw new Error("Red Team deployment gate rejected");
  for (const contract of ["zasp-attack-lab", "agentsec-attack-lab-runner", "agentsec-attack-lab-outbox", "agentsec-attack-lab-controller", "agentsec-attack-lab-proxy", "attack-lab-outbox", "attack-lab-controller", "ZASP_ATTACK_LAB_NAMESPACE", "ZASP_ATTACK_LAB_RUNNER_SERVICE_ACCOUNT", "https://agentsec-attack-lab-proxy.agentsec.svc.cluster.local/v1/egress", "/app/agentsec-attack-lab-proxy", "SecurityGroupPolicy", "HorizontalPodAutoscaler", "PodDisruptionBudget", "NetworkPolicy", "ServiceMonitor"]) if (!attackLabWorkloads.includes(contract)) throw new Error("Attack Lab deployment gate rejected");
  for (const contract of ["projection-search-init", "projection-graph-init", "ZASP_PROJECTION_INIT_ROLE_ARN", "ZASP_PROJECTION_INIT_WEB_IDENTITY_TOKEN_FILE", "ZASP_PROJECTION_INIT_TIMEOUT", "ZASP_NEO4J_SCHEMA_CREDENTIAL_REFERENCE", "ZASP_OPENSEARCH_INDEX"]) if (!projectionInit.includes(contract)) throw new Error("projection init gate rejected");
  for (const contract of ["agentsec-discovery-worker", "agentsec-security-agent", "agentsec-security-agent-action", "agentsec-policy-deployment", "security-agent-database", "security-agent-action-database", "policy-deployment-database", "agentsec-projection-risk", "agentsec-projection-graph", "agentsec-projection-search", "HorizontalPodAutoscaler", "PodDisruptionBudget", "default-deny"]) if (!resilience.includes(contract)) throw new Error("worker resilience gate rejected");
  for (const contract of ["agentsec-event-ingest", "agentsec-gateway-control", "runtime-outbox", "runtime-coordinator", "runtime-archive", "runtime-index", "runtime-correlation", "runtime-projection", "runtime-complete", "ZASP_RUNTIME_RAW_BUCKET", "ZASP_RUNTIME_QUEUE_URL", "ZASP_OPENSEARCH_INDEX"]) if (!runtimeWorkloads.includes(contract)) throw new Error("runtime deployment gate rejected");
  for (const contract of ["packages/server/dist/migrate.js", "NANGO_DATABASE_URL", "NANGO_ENCRYPTION_KEY", "NANGO_MIGRATE_AT_START", "RECORDS_DATABASE_SSL", "NANGO_ENTERPRISE", "nango-private", "nango-migrate-private"]) if (!nango.includes(contract)) throw new Error("Nango deployment gate rejected");
  for (const contract of ["memory_limiter", "transform/redact_content", "set(log.body", "set(span.name", "redaction", "batch", "nop", "otlphttp/remote", "sending_queue", "queue_size: 256", "max_elapsed_time: 60s", "otel-collector-private", "ServiceMonitor", "PrometheusRule", "ZaspOTelCollectorQueueLoss", "port: 8888"]) if (!collector.includes(contract)) throw new Error("Collector deployment gate rejected");
  for (const contract of [
    "ZaspDiscoverySchedulerUnavailable", "ZaspDiscoveryWorkerUnavailable", "ZaspSecurityAgentUnavailable", "ZaspSecurityAgentActionUnavailable", "ZaspOutboxPublisherUnavailable",
    "ZaspProjectionRiskUnavailable", "ZaspProjectionGraphUnavailable", "ZaspProjectionSearchUnavailable",
    "ZaspTask4WorkerDependencyNotReady", "ZaspProjectionRiskDriverNotReady", "ZaspProjectionGraphDriverNotReady", "ZaspProjectionSearchDriverNotReady",
    "ZaspProjectionBacklogAge", "ZaspWorkerLeaseLoss", "ZaspWorkerExhaustion", "ZaspTask4WorkerCapacityExhausted", "ZaspRedTeamOutboxUnavailable", "ZaspRedTeamWorkerUnavailable", "ZaspRedTeamAdapterUnavailable", "ZaspRedTeamDependencyNotReady", "ZaspAttackLabOutboxUnavailable", "ZaspAttackLabControllerUnavailable", "ZaspAttackLabProxyUnavailable", "ZaspAttackLabDependencyNotReady",
    "ZaspRecoveryUnavailable", "ZaspRecoveryDriverNotReady", "ZaspRecoveryQueueAge", "ZaspRecoveryHoldTooOld", "ZaspRecoveryExhaustion", "ZaspRecoveryLeaseLoss", "ZaspRecoveryCleanupFailure",
    "agentsec_ready", "zasp_worker_driver_ready", "zasp_worker_projection_backlog_age_seconds", "zasp_worker_lease_loss_total", "zasp_worker_exhaustion_total", "zasp_recovery_driver_ready", "zasp_recovery_queue_age_seconds", "zasp_recovery_hold_age_seconds", "zasp_recovery_exhaustion_total", "zasp_recovery_lease_loss_total", "zasp_recovery_cleanup_failure_total",
  ]) if (!monitoring.includes(contract)) throw new Error("worker monitoring gate rejected");

  failureStage = "sources-gitleaks";
  await exec("gitleaks", ["git", "--no-banner", "--redact", "--log-opts=HEAD"], { cwd: root, encoding: "utf8", maxBuffer: 16 * 1024 * 1024 });
  failureStage = "sources-ci";
  const workflow = await source(".github/workflows/runnable-ui.yml");
  if (!workflow.includes("fetch-depth: 0") || !workflow.includes("github.com/zricethezav/gitleaks/v8@v8.30.1") || !workflow.includes("npm run production:release:gate")) throw new Error("required CI gate rejected");

  failureStage = "sources-image-definitions";
  const definitions = await Promise.all(["web", "api", "worker", "attack-lab-runner", "redteam-worker", "event-ingest", "gateway-control", "runtime-gateway", "sensor-agent"].map((name) => source(`deploy/production/${name}.Dockerfile`)));
  const imageReferences = new Set(definitions.flatMap((definition) => [...definition.matchAll(/^FROM\s+(\S+)/gm)].map((match) => match[1])));
  if (imageReferences.size !== 5 || [...imageReferences].some((reference) => !/@sha256:[0-9a-f]{64}$/.test(reference))) throw new Error("image definition gate rejected");

  return deepFreeze({ renderedRollouts, canary: true, documentation: true, imageDefinitions: builds.length, licensePolicy: true, trackedSecretScan: true, npmSpdxPackages: sbom.packages.length, goSpdxPackages: goSpdx.packages.length, goSpdx, requiredCI: true, task4Deployment: true, task6Deployment: true, recoveryDeployment: true, attackLabDeployment: true, privateDependencies: true });
  } catch (error) {
    throw releaseStageError(failureStage, error);
  }
}

async function goSourceSBOM() {
  const template = "{{with .Module}}{{.Path}}\t{{.Version}}\t{{.Dir}}{{end}}";
  const modulesToList = [
    { cwd: path.join(root, "services/platform"), packages: ["./agentsec-api", "./agentsec-migrate", "./agentsec-worker", "./red-team-adapter", "./cmd/zasp-healthcheck"] },
    { cwd: path.join(root, "services/event-ingest"), packages: ["."] },
    { cwd: path.join(root, "services/gateway-control"), packages: ["."] },
    { cwd: path.join(root, "services/runtime-gateway"), packages: ["."] },
    { cwd: path.join(root, "services/sensor-agent"), packages: ["."] },
  ];
  const modules = new Map();
  for (const entry of modulesToList) {
    const { stdout } = await exec("go", ["list", "-deps", "-f", template, ...entry.packages], { cwd: entry.cwd, encoding: "utf8", maxBuffer: 16 * 1024 * 1024 });
    for (const line of stdout.split("\n")) {
      if (!line) continue;
      const [name, version, directory] = line.split("\t");
      if (!name || !directory || modules.has(name)) continue;
      modules.set(name, { name, version: version || "0.0.0-local", directory });
    }
  }
  const packages = [];
  for (const dependency of [...modules.values()].sort((left, right) => left.name.localeCompare(right.name))) {
    const license = await moduleLicense(dependency);
    const packageID = createHash("sha256").update(`${dependency.name}\0${dependency.version}`).digest("hex").slice(0, 24);
    packages.push({ SPDXID: `SPDXRef-Package-${packageID}`, name: dependency.name, versionInfo: dependency.version, downloadLocation: "NOASSERTION", filesAnalyzed: false, licenseConcluded: license, licenseDeclared: license, copyrightText: "NOASSERTION" });
  }
  const created = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
  const documentNamespace = goDocumentNamespace(packages, created);
  return {
    spdxVersion: "SPDX-2.3",
    dataLicense: "CC0-1.0",
    SPDXID: "SPDXRef-DOCUMENT",
    name: "zasp-production-go-source",
    documentNamespace,
    creationInfo: { created, creators: ["Tool: zasp-production-release-gate"] },
    packages,
    relationships: packages.map((entry) => ({ spdxElementId: "SPDXRef-DOCUMENT", relationshipType: "DESCRIBES", relatedSpdxElement: entry.SPDXID })),
  };
}

export function validateGoSpdxDocument(document) {
  const created = document?.creationInfo?.created;
  if (!document || document.spdxVersion !== "SPDX-2.3" || document.dataLicense !== "CC0-1.0" || document.SPDXID !== "SPDXRef-DOCUMENT" || document.name !== "zasp-production-go-source" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$/.test(created) || Number.isNaN(Date.parse(created)) || new Date(created).toISOString().replace(/\.000Z$/, "Z") !== created || !document.creationInfo?.creators?.includes("Tool: zasp-production-release-gate") || !Array.isArray(document.packages) || !Array.isArray(document.relationships) || document.documentNamespace !== goDocumentNamespace(document.packages, created)) throw new Error("Go SBOM gate rejected");
  const packageIDs = new Set();
  for (const entry of document.packages) {
    if (!entry || !/^SPDXRef-Package-[A-Za-z0-9.-]+$/.test(entry.SPDXID) || packageIDs.has(entry.SPDXID) || typeof entry.name !== "string" || !entry.name || typeof entry.versionInfo !== "string" || !entry.versionInfo || entry.downloadLocation !== "NOASSERTION" || entry.filesAnalyzed !== false || typeof entry.licenseConcluded !== "string" || entry.licenseDeclared !== entry.licenseConcluded || entry.copyrightText !== "NOASSERTION") throw new Error("Go SBOM gate rejected");
    packageIDs.add(entry.SPDXID);
  }
  if (document.relationships.length !== packageIDs.size) throw new Error("Go SBOM gate rejected");
  const described = new Set();
  for (const relationship of document.relationships) {
    if (!relationship || relationship.spdxElementId !== "SPDXRef-DOCUMENT" || relationship.relationshipType !== "DESCRIBES" || !packageIDs.has(relationship.relatedSpdxElement) || described.has(relationship.relatedSpdxElement)) throw new Error("Go SBOM gate rejected");
    described.add(relationship.relatedSpdxElement);
  }
  return true;
}

function goDocumentNamespace(packages, created) {
  const namespaceID = createHash("sha256").update(JSON.stringify({ created, packages })).digest("hex");
  return `https://zasp.example/spdx/go-source/${namespaceID}`;
}

async function moduleLicense(dependency) {
  if (dependency.name.startsWith("github.com/zasp-ai/zasp-sec/")) return "NOASSERTION";
  const names = (await readdir(dependency.directory)).filter((name) => /^(?:licen[cs]e|copying)(?:[._-].*)?$/i.test(name)).sort();
  if (names.length === 0) return "NOASSERTION";
  const texts = await Promise.all(names.map((name) => readFile(path.join(dependency.directory, name), "utf8")));
  const text = texts.join("\n").toLowerCase();
  if (text.includes("apache license") && text.includes("version 2.0")) return "Apache-2.0";
  if (text.includes("permission is hereby granted, free of charge") || text.includes("the mit license")) return "MIT";
  if (text.includes("permission to use, copy, modify, and/or distribute")) return "ISC";
  if (text.includes("redistribution and use in source and binary forms")) return text.includes("neither the name") ? "BSD-3-Clause" : "BSD-2-Clause";
  if (text.includes("mozilla public license") && text.includes("version 2.0")) return "MPL-2.0";
  return "NOASSERTION";
}

async function source(relative) { return readFile(path.join(root, relative), "utf8"); }
function deepFreeze(value) { if (value && typeof value === "object") { for (const child of Object.values(value)) deepFreeze(child); Object.freeze(value); } return value; }
