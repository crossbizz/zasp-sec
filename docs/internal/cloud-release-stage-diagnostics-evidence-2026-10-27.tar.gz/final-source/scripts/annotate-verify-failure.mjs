import {releaseStageForCode} from './release-failure-stages.mjs';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
const PHASES=Object.freeze(["dependencies:check","health:contract:test","openapi:test","openapi:lint","openapi:check","ui-api:test","ui-api:check","raw-fetch:test","saas:tenancy:test","graph:neo4j:test","db:tenant-rls:test","test","typecheck","lint","production:imports:test","production:imports:source","staging:gate:test","production:release:test","build","production:imports:compiled","implementation:status:check"]);
const RELEASE_TEST_NAMES = ["API build dependency stage resolves its copied local health module","API export configuration uses only reader policy and mounted cursor secret","Attack Lab release requires a separate same-account test role","Attack Lab routes image pulls through its own bucket-restricted S3 endpoint","Attack Lab security group consumes the executable bounded egress contract","Attack Lab test IAM identity trusts only its run service account and denies cloud permissions","Go test launch accepts an explicit executable outside Homebrew and leaves default cache portable","Go test launch preserves setup-go PATH and configured cache without ambient credentials","Go test launch refuses an unpinned or malformed toolchain version","Grafana and New Relic Collector overlays bound remote failure with one exact secret","a clock rewind cannot replenish an observation deadline","absent configuration rejects renamed export consumers and direct Secret settings","actual chart defaults disable exports and both precision phases retain bounded history","actual export manifests are pinned to independent expectations and reject authority mutations","audit schema52 requires an explicit supported precision phase","bridge binds opaque API resourceVersion from the same validated backfill snapshot","bridge cannot substitute an API version from an invalid or missing deployment","bridge process returns the validated snapshot through its real stdin/stdout protocol","bridge refuses deadline expiry or clock rewind after full observer validation","bridge refuses malformed requests before any cluster read","budget release keeps default49 and rejects implicit or future phases","closed compliance input refuses authority confusion and snapshots before await","compatibility keeps only v1 and rejects mixed phase/schema selections","compatibility staging explicitly pins48 without activating routing","compliance API startup rejects shell authority and command changes with and without audit","compliance56 coexists with both optional predecessors in both phases","customer edge isolates lineage producer, consumer and layout initialization","customer edge rejects mutable sensors, broad networks, shared secrets, and ambient state","customer edge renders database-free gateway, multi-node sensor, and pinned Tetragon","customer edge selects precise source only explicitly","direct Helm refuses unsafe endpoint ranges and can disable metric scraping","direct Helm rejects malformed compliance authority without the JS normalizer","endpoint normalization rejects executable array entries without invoking them","export activation rejects malformed flags and deployment boundaries","export normalization copies closed configuration and every historical policy","export normalization refuses malformed authority before rendering","export workers have bounded scaling, spread and separate availability rules","export workers render isolated production modes with owned credentials","export workload activation refuses missing or incompatible authority","exports have mode-specific dependency access and privately scraped healthy workers","exports refuse missing, broad or noncanonical endpoint snapshots","failed canonical rollout tests stop standalone release before any audit invocation","full release reconciler opt-in pins workload authority and rejects tampering","full release renders export API workers and selected migration policy together","historical phases reject accidental precision producer and consumer selectors","invalid or expired inherited deadlines never invoke kubectl","migration integer limits are exact and malformed retained history is rejected","migration selects explicit policy and preserves canonical limits and predecessor","migration shell stops at credential read and each failed command","migration uses the published registration environment names","missing advisory evidence blocks release without an audit request or clearance claim","normalization retains explicit prior selection and safe boundary values","observer spends only the inherited deadline across sequential reads","observes all precision consumers with intake still v1","observes completed intended init containers and rejects failed or wrong-image initialization","observes the complete compatible consumer set and revalidates unchanged identities","precision consumers install51 with dual readers while intake remains v1","precision intake changes only admitted schema after consumer upgrade","precision intake observation requires completed v2 intake and unchanged consumers","precision intake revalidation rejects expiry and pod replacement","precision observation refuses a consistently pinned old coordinator or early intake","production CI runs sensor lineage and authenticated replay regressions","production container builds are exact, non-root, health-bound, and secret-free","production recovery renders isolated inert workers and least-privilege cloud authority","production release renders private Nango dependency plus a fail-closed local Collector","query observation requires all ready query consumers and refuses old API replicas","read-only bridge process refuses malformed or oversized input without exposing it","read-only synthetic proves web and authenticated API correlation without leaking token","real Go loaders consume enabled and disabled rendered compliance environments","reconciler composes with audit exports in both precision phases","reconciler configuration is explicit and snapshots all authority inputs","reconciler egress is closed to declared database and cloud ranges plus cluster DNS","reconciler is opt-in and refuses incompatible deployment authority","reconciler metrics remain private and retain unready targets for alerting","reconciler network validator rejects widened dependencies and additive policies","reconciler refuses indirect RBAC grants through authenticated service-account groups","reconciler rejects ambiguous and cross-account authority","reconciler rejects terminal newlines in authority strings","reconciler rejects unsafe endpoint snapshots and never invokes input accessors","reconciler renders isolated credentials, fixed runtime and bounded shutdown","release applies non-root rollout, zone and host spread, drain, PDB, and default-deny policies","release deploys the central policy writer with one exact signing identity","release gives finding tickets exact API-only webhook egress and secret-read authority","release gives only API an explicit connector identity, reference-only config, and bounded provider egress","release gives the runtime data plane bounded ingress and dependency egress","release isolates Attack Lab execution behind a proxy-only Fargate authority","release isolates the discovery outbox publisher behind exact DB, queue, and web-identity authority","release isolates the red team outbox runner and tenant target adapter","release monitors, scales, and independently alerts every runtime workload","release mounts distinct risk and graph projections behind exact DB, Neo4j, and schema authorities","release mounts one readiness-gated discovery worker with exact provider and artifact authority","release owns its export configuration while Helm runs","release policy binds performance, resilience, supply-chain, and owned proof gates","release refuses export activation outside its approved schema and phase","release rejects unpinned images and hostile public identifiers","release removes its owned export values after Helm success or refusal","release renders one TLS origin, split ports, private internals, and migration/schema gates","release renders read-only synthetic and exact SLO budgets without credential values","release runs temporary policy actions with a separate signing identity","release runs the security agent with one exact database authority","release ships the complete v15 runtime data plane behind exact workload authorities","release sources contain truthful runbooks, canary, SBOM/license/image/secret gates","rendered compliance rejects authority, sidecar, readiness and additive network mutations","rendered release rejects an unreviewed job identity","revalidation rejects expiry and replacement pods with unchanged images","routing release requires the dual-version correlation worker","runtime session search bootstrap and worker IAM have separate fixed paths","sandbox compatibility staging explicitly pins49 before future activation","schema55 predecessors still render and59 stays closed","schema60 requires a schema59 scheduler fence before the release60 scheduler starts","schema60 rollout rejects an absent fence, a fenced new scheduler, and unknown successors","schema60 transition applies maintenance, proves the scheduler is drained, then activates the reviewed image","schema60 transition refuses activation while any old or terminating scheduler pod remains","schema60 transition rejects mutable images and namespace replacement before invoking tools","session query API IAM grants only fixed read endpoints","shared chart policies cannot broaden the reconciler DNS-only allowance","standalone release gate runs canonical rollout tests before later release checks","terraform binds each shipped secret consumer to one exact least-privilege IRSA role","terraform isolates Attack Lab queue evidence proxy and runner pod networks","terraform isolates connector mutation and reference authorization behind one API-only web-identity role","terraform isolates red team queue evidence and target credentials behind three identities","terraform provisions the exact encrypted v15 runtime plane and isolated identities","the canonical release suite and runbook require the live schema60 transition guard","turning chart monitoring off removes scrape resources and closes ingress"];
const RELEASE_TEST_SET=new Set(RELEASE_TEST_NAMES);
const SUMMARY_KEYS=["tests","pass","fail","cancelled","skipped","todo"];
const MAX_BYTES=256*1024;
const GENERIC='::error title=npm verify failed::npm run verify failed; phase unavailable.';
const MAX_READ_BYTES=64*1024*1024;
const READ_CHUNK_BYTES=64*1024;
const MAX_LINE_BYTES=16*1024;
const MAX_LINES=1000000;
function annotationParser(){
 let phase=null,failed=[],summary=new Map(),invalidSummary=false,releaseStages=[],failureBlock=false,diagnosticBlock=false;
 return {
  line(line){
  if(line.length>4096){if(line.startsWith('> ')){phase=null;failed=[];summary=new Map();invalidSummary=false;releaseStages=[];failureBlock=false;diagnosticBlock=false;}return;}
  if(/^> [^ \t]+@[^ \t]+ [^\r\n]+$/.test(line)){
   const match=/^> zasp-agent-security-console@0\.1\.0 ([a-z:.-]+)$/.exec(line);
   phase=match&&PHASES.includes(match[1])?match[1]:null;failed=[];summary=new Map();invalidSummary=false;releaseStages=[];failureBlock=false;diagnosticBlock=false;
   return;
  }
  if(phase!=='production:release:test')return;
  const result=/^not ok (?:0|[1-9][0-9]{0,6}) - (.+)$/.exec(line)??/^✖ (.+) \((?:0|[1-9][0-9]{0,9})(?:\.[0-9]{1,9})?ms\)$/.exec(line);
  const name=result?.[result.length-1];
  if(result){failureBlock=RELEASE_TEST_SET.has(name);diagnosticBlock=false;}
  if(/^ {2,16}---$/.test(line)&&failureBlock)diagnosticBlock=true;
  if(/^ {2,16}\.\.\.$/.test(line)||/^ok [0-9]+ - |^# Subtest:|^1\.\./.test(line)){failureBlock=false;diagnosticBlock=false;}
  const stageCode=failureBlock&&diagnosticBlock?/^ {2,16}code: '(ZASP_RELEASE_STAGE_[A-Z_]+)'$/.exec(line):null;
  const stage=stageCode?releaseStageForCode(stageCode[1]):undefined;
  if(stage&&!releaseStages.includes(stage)&&releaseStages.length<4)releaseStages.push(stage);
  if(name&&RELEASE_TEST_SET.has(name)&&!failed.includes(name)&&failed.length<4)failed.push(RELEASE_TEST_NAMES.find(value=>value===name));
  const counter=/^(?:#|ℹ) (tests|pass|fail|cancelled|skipped|todo)(?: (.*))?$/.exec(line);
  if(counter){const key=counter[1],text=counter[2]??'';if(!/^(?:0|[1-9][0-9]{0,6})$/.test(text)||Number(text)>1000000||summary.has(key))invalidSummary=true;else summary.set(key,Number(text));}
  },
  oversizedLine(startsHeader){
   if(startsHeader){phase=null;failed=[];summary=new Map();invalidSummary=false;releaseStages=[];failureBlock=false;diagnosticBlock=false;}
  },
  finish(){
 if(phase==='production:release:test'){
  const valid=!invalidSummary&&SUMMARY_KEYS.every(key=>summary.has(key))&&SUMMARY_KEYS.every(key=>summary.get(key)<=summary.get('tests'))&&summary.get('pass')+summary.get('fail')+summary.get('cancelled')<=summary.get('tests');
  const counters=valid?SUMMARY_KEYS.map(key=>key+'='+summary.get(key)).join(', '):'unavailable';
  const annotation=`::error title=npm verify failed::npm run verify failed; latest observed phase: production:release:test. Observed failed tests: ${failed.length?failed.join('; '):'unavailable'}. Observed summary: ${counters}.${releaseStages.length?' Observed release stages: '+releaseStages.join(', ')+'.':''}`;
  return Buffer.byteLength(annotation)<=4096?annotation:'::error title=npm verify failed::npm run verify failed; latest observed phase: production:release:test. Observed failed tests: unavailable. Observed summary: unavailable.';
 }
 return phase===null?GENERIC:`::error title=npm verify failed::npm run verify failed; latest observed phase: ${phase}.`;
  }
 };
}
export function verifyFailureAnnotation(raw){
 if(!Buffer.isBuffer(raw)||raw.length>MAX_BYTES)return GENERIC;
 const parser=annotationParser();
 for(const line of raw.toString('utf8').split(/\r?\n/))parser.line(line);
 return parser.finish();
}
function fileAnnotation(file){
 const fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW|fs.constants.O_NONBLOCK);
 try{
  const before=fs.fstatSync(fd,{bigint:true});
  if(!before.isFile()||before.size<0n||before.size>BigInt(MAX_READ_BYTES))throw Error();
  const parser=annotationParser(),chunk=Buffer.alloc(READ_CHUNK_BYTES);
  let pending=Buffer.alloc(0),discarded=false,lines=0,position=0;
  const finishLine=(newline)=>{
   if(++lines>MAX_LINES)throw Error();
   if(!discarded){
    const value=newline&&pending.at(-1)===13?pending.subarray(0,-1):pending;
    parser.line(value.toString('utf8'));
   }
   pending=Buffer.alloc(0);discarded=false;
  };
  const feed=(part)=>{
   if(discarded)return;
   if(pending.length+part.length>MAX_LINE_BYTES){
    const prefix=pending.length>=2?pending.subarray(0,2):Buffer.concat([pending,part.subarray(0,2-pending.length)]);
    parser.oversizedLine(prefix[0]===62&&prefix[1]===32);
    pending=Buffer.alloc(0);discarded=true;
   }else pending=Buffer.concat([pending,part]);
  };
  const size=Number(before.size);
  while(position<size){
   const wanted=Math.min(chunk.length,size-position);
   if(fs.readSync(fd,chunk,0,wanted,position)!==wanted)throw Error();
   position+=wanted;
   let start=0;
   while(start<wanted){
    const newline=chunk.indexOf(10,start),end=newline>=0&&newline<wanted?newline:wanted;
    feed(chunk.subarray(start,end));
    if(end===wanted)break;
    finishLine(true);start=end+1;
   }
  }
  if(pending.length||discarded)finishLine(false);
  const after=fs.fstatSync(fd,{bigint:true});
  if(position!==size||!after.isFile()||before.dev!==after.dev||before.ino!==after.ino||before.size!==after.size||before.mtimeNs!==after.mtimeNs||before.ctimeNs!==after.ctimeNs)throw Error();
  return parser.finish();
 }finally{fs.closeSync(fd);}
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 let annotation=GENERIC;
 try{if(process.argv.length===3)annotation=fileAnnotation(process.argv[2]);}catch{/* Diagnostic failure never changes the verifier status or emits input details. */}
 process.stdout.write(annotation+'\n');
}
