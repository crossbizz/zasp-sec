from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/workspace/zasp-node-coverage-retention');work=Path('/tmp/oct27-release-final')
manifest=root/'.github/connector-native-compile-source-pins.json';old=manifest.read_bytes();data=json.loads(old);assert len(data['sources'])==926
source='deploy/production/release-contract.mjs';new='scripts/release-failure-stages.mjs';workflow='.github/workflows/connector-native-draft-compile.yml'
runners=['scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs']
def sha(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
assert new not in {x['path'] for x in data['sources']}
(work/'source-pins-before.json').write_bytes(old)
text=(root/workflow).read_text();(work/'compile-workflow.before.yml').write_text(text);assert text.count("assert len(source['sources']) == 926")==2;(root/workflow).write_text(text.replace("assert len(source['sources']) == 926","assert len(source['sources']) == 927"))
for p in runners:
 text=(root/p).read_text();(work/(Path(p).name+'.before')).write_text(text);m=re.search(r'const pins = (\{.*?\n\});',text,re.S);pins=json.loads(m[1]);assert source in pins and workflow in pins and new not in pins
 pins[source]=sha(source);pins[workflow]=sha(workflow);pins[new]=sha(new);(root/p).write_text(text[:m.start(1)]+json.dumps(pins,indent=2)+text[m.end(1):])
changed=[]
for item in data['sources']:
 p=item['path']
 if sha(p)!=item['sha256']:
  assert p in [source,workflow]+runners,p
  changed.append({'path':p,'beforeSHA256':item['sha256'],'afterSHA256':sha(p)});item['sha256']=sha(p);item['bytes']=(root/p).stat().st_size
assert len(changed)==4,len(changed)
data['sources'].append({'path':new,'sha256':sha(new),'bytes':(root/new).stat().st_size,'currentBasePreimageSHA256':None,'historicalPreimageSHA256':None})
data['releaseStageDiagnosticsSourceAssociationBase']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();data['releaseStageDiagnosticsPredecessorManifestSHA256']=hashlib.sha256(old).hexdigest();manifest.write_text(json.dumps(data,indent=2)+'\n')
prior=json.loads(old);assert [x['path'] for x in prior['sources']]==[x['path'] for x in data['sources'][:-1]]
for a,b in zip(prior['sources'],data['sources']):assert all(a[k]==b[k] for k in a if k not in ['sha256','bytes'])
for x in data['sources']:assert sha(x['path'])==x['sha256'] and (root/x['path']).stat().st_size==x['bytes']
pattern=re.compile(r'''["']([^"'\n]+)["']\s*:\s*["']([0-9a-f]{64})["']''');associations=[]
for p in (root/'scripts').rglob('*'):
 if p.suffix not in ['.mjs','.json'] or not p.is_file():continue
 for path,pin in pattern.findall(p.read_text()):
  if (root/path).is_file():assert sha(path)==pin,(str(p),path);associations.append([str(p.relative_to(root)),path,pin])
assert len(associations)==1826,len(associations)
(work/'custody-verification.json').write_text(json.dumps({'bindings':927,'old_bindings':926,'all_hashes_bytes_match':True,'all_original_paths_order_preimage_fields_preserved':True,'new_import_closure':new,'all_current_script_associations_match':True,'current_script_associations':len(associations),'changed':changed,'predecessor_manifest_SHA256':hashlib.sha256(old).hexdigest()},indent=2)+'\n')
print('927manifest entries/1826current associations match;2exact count assertions updated, originalsource/test guards retained')
