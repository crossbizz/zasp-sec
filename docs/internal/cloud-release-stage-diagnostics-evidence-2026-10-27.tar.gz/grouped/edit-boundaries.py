from pathlib import Path
p=Path('deploy/production/release-contract.mjs');s=p.read_text();s='import {releaseStageError, withReleaseStage} from "../../scripts/release-failure-stages.mjs";\n'+s
s=s.replace('  let exportValuesDirectory;\n  try {','  let exportValuesDirectory;\n  let failureStage = "normal-values";\n  try {',1)
s=s.replace('    await exec("helm", ["lint", chart, "--namespace", "agentsec", ...valueArgs]', '    failureStage = "normal-helm-lint";\n    await exec("helm", ["lint", chart, "--namespace", "agentsec", ...valueArgs]',1)
s=s.replace('    ({ stdout } = await exec("helm", ["template", "zasp", chart, "--namespace", "agentsec", ...valueArgs]', '    failureStage = "normal-helm-template";\n    ({ stdout } = await exec("helm", ["template", "zasp", chart, "--namespace", "agentsec", ...valueArgs]',1)
s=s.replace('''  } catch {
    throw new Error("release rejected");
  } finally {
    if (exportValuesDirectory) await rm(exportValuesDirectory, { recursive: true, force: true });''','''  } catch (error) {
    throw releaseStageError(failureStage, error);
  } finally {
    if (exportValuesDirectory) await withReleaseStage("normal-cleanup", () => rm(exportValuesDirectory, { recursive: true, force: true }));''',1)
s=s.replace('''  } catch {
    throw new Error("release rejected");
  }
  if (resources.length < 20''','''  } catch (error) {
    throw releaseStageError("normal-parse", error);
  }
  if (resources.length < 20''',1)
s=s.replace('if (resources.length < 20 || resources.some((resource) => !resource?.apiVersion || !resource?.kind || !resource?.metadata?.name)) throw new Error("release rejected");','if (resources.length < 20 || resources.some((resource) => !resource?.apiVersion || !resource?.kind || !resource?.metadata?.name)) throw releaseStageError("normal-resources");',1)
start=s.index('  validateRenderedRelease(resources, platformAccountID, schemaVersion, sessionSearchPhase, auditExports, testReconciler, complianceExports, attackLabReconciler, evidenceExportWorkflow, discoveryScheduleReplayPhase, authorizationTemporal, optionalEgress, value.securityAgentPlanner.egressCIDRs, retention, environmentClass, agentOwnerFilter, agentRead, agentExposureFilter, agentOwnershipWrite, sensorNodeCoverage, gatewayInstallation, gatewayBootstrap, agentDeviceAssociation);')
end=s.index('\n',start);call=s[start:end].strip();s=s[:start]+'  await withReleaseStage("normal-validation", () => '+call[:-1]+');'+s[end:]
s=s.replace('  const nodeSelector = structuredClone(value.sensorNodeSelector);\n  try {','  const nodeSelector = structuredClone(value.sensorNodeSelector);\n  let failureStage = "edge-dependency";\n  try {',1)
s=s.replace('    coverageDirectory = await mkdtemp', '    failureStage = "edge-values";\n    coverageDirectory = await mkdtemp',1)
for stage,command in [('edge-product-lint','["lint", chart,'),('edge-product-template','["template", "zasp", chart,'),('edge-tetragon-lint','["lint", tetragonChart,'),('edge-tetragon-template','["template", "zasp-tetragon", tetragonChart,')]:
 line=next(x for x in s.splitlines() if x.startswith('      exec("helm", '+command))
 replacement='      withReleaseStage("'+stage+'", () => '+line.strip()[:-1]+'),'
 assert s.count(line)==1;s=s.replace(line,replacement,1)
s=s.replace('''  } catch {
    throw new Error("edge release rejected");
  } finally {
    if (coverageDirectory) await rm(coverageDirectory,{recursive:true,force:true});''','''  } catch (error) {
    throw releaseStageError(failureStage, error);
  } finally {
    if (coverageDirectory) await withReleaseStage("edge-cleanup", () => rm(coverageDirectory,{recursive:true,force:true}));''',1)
s=s.replace('''  } catch {
    throw new Error("edge release rejected");
  }
  validateSensorNodeCoverageProducerResources(resources,nodeCoverage);
  validateGatewayInstallationProducerResources(resources,gatewayInstallation);''','''  } catch (error) {
    throw releaseStageError("edge-parse", error);
  }
  await withReleaseStage("edge-coverage", () => validateSensorNodeCoverageProducerResources(resources,nodeCoverage));
  await withReleaseStage("edge-installation", () => validateGatewayInstallationProducerResources(resources,gatewayInstallation));''',1)
for fragment,stage in [('if (resources.length < 20 || resources.some((resource) => !resource?.apiVersion || !resource?.kind || !resource?.metadata?.name) || deployments.length','edge-resources'),('if(normalize(sensorDS?.spec?.template?.spec?.nodeSelector)','edge-placement'),('if(!dsRule||JSON.stringify(dsRule.verbs)','edge-rbac')]:
 line=next(x for x in s.splitlines() if fragment in x);assert 'throw new Error("edge release rejected")' in line;s=s.replace(line,line.replace('throw new Error("edge release rejected")','throw releaseStageError("'+stage+'")'),1)
p.write_text(s)
p=Path('deploy/production/release-gates.mjs');s=p.read_text();s='import {releaseStageError} from "../../scripts/release-failure-stages.mjs";\n'+s
s=s.replace('export async function verifyReleaseSources() {','export async function verifyReleaseSources() {\n  let failureStage = "sources-render";\n  try {',1)
for stage,needle in [('sources-images','  const builds = await inspectContainerBuilds();'),('sources-canary','  const canary = await source('),('sources-documentation','  const requiredDocs = ['),('sources-npm-sbom','  const { stdout } = await exec("npm",'),('sources-npm-license','  for (const entry of sbom.packages)'),('sources-go-sbom','  const goSpdx = await goSourceSBOM();'),('sources-go-license','  for (const entry of goSpdx.packages)'),('sources-contracts','  const sensitiveSources = await Promise.all(['),('sources-gitleaks','  await exec("gitleaks",'),('sources-ci','  const workflow = await source('),('sources-image-definitions','  const definitions = await Promise.all([')]:
 idx=s.index(needle);s=s[:idx]+'  failureStage = "'+stage+'";\n'+s[idx:]
end=s.index('\n}\n\nasync function goSourceSBOM');s=s[:end]+'\n  } catch (error) {\n    throw releaseStageError(failureStage, error);\n  }'+s[end:]
p.write_text(s)
p=Path('scripts/annotate-verify-failure.test.mjs');s=p.read_text().replace('/CANARY|token|stdout|stderr|cause/','/CANARY_SECRET|token|stdout|stderr|cause/');p.write_text(s)
