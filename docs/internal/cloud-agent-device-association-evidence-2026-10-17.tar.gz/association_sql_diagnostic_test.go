package migrations

import("os";"path/filepath";"testing")
// Executor-only temporary overlay, excluded from final source and acceptance roster.
func TestAgentDeviceAssociationCompiledSQLDiagnostic(t *testing.T){
 dir:=os.Getenv("ZASP_ASSOCIATION_SQL_DIAGNOSTIC_DIR");if dir==""||!filepath.IsAbs(dir){t.Fatal("explicit absolute diagnostic directory required")}
 for _,audit:=range []bool{false,true}{name:="normal";if audit{name="audit"};source,pin:=compiledAgentDeviceAssociationSource(audit);if e:=os.WriteFile(filepath.Join(dir,name+".sql"),[]byte(source),0600);e!=nil{t.Fatal(e)};if e:=os.WriteFile(filepath.Join(dir,name+".profile-pin"),[]byte(pin+"\n"),0600);e!=nil{t.Fatal(e)}}
}
