package apiserver

import (
	"errors"
	"net/http"
	"reflect"
)

var ErrInvalidComposition = errors.New("invalid API composition")

type Dependencies struct {
	Authorizer RequestAuthorizer
	Session    http.Handler
	Identity   http.Handler
	Inventory  http.Handler
	Risk       http.Handler
	Workflow   http.Handler
	Connector  http.Handler
}

type OperationDefinition struct {
	Method      string
	Pattern     string
	OperationID string
	Permission  string
	Security    []string
}

type dependencyKind uint8

const (
	sessionDependency dependencyKind = iota + 1
	identityDependency
	inventoryDependency
	riskDependency
	workflowDependency
	connectorDependency
)

type coreOperation struct {
	OperationDefinition
	dependency dependencyKind
}

var coreOperations = withBrowserExpectedScope([]coreOperation{
	{OperationDefinition{"GET", "/api/v1/session/start", "startSession", "", []string{}}, sessionDependency},
	{OperationDefinition{"GET", "/api/v1/session/bootstrap", "bootstrapSession", "", []string{"BrowserSession"}}, sessionDependency},
	{OperationDefinition{"POST", "/api/v1/session/callback", "completeSessionCallback", "", []string{}}, sessionDependency},
	{OperationDefinition{"POST", "/api/v1/session/sign-out", "signOutSession", "", []string{"BrowserSession"}}, sessionDependency},
	{OperationDefinition{"GET", "/api/v1/session/scopes", "listSessionScopes", "", []string{"BrowserSession"}}, sessionDependency},
	{OperationDefinition{"PUT", "/api/v1/session/scope", "switchSessionScope", "", []string{"BrowserSession"}}, sessionDependency},
	{OperationDefinition{"GET", "/api/v1/me", "getCurrentPrincipal", "", []string{"BrowserSession", "ProductAPIToken"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/organization", "getOrganization", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/workspaces", "listWorkspaces", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/workspaces", "createWorkspace", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/workspaces/{id}", "getWorkspace", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"PATCH", "/api/v1/workspaces/{id}", "updateWorkspace", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/environments", "listEnvironments", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/environments", "createEnvironment", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/environments/{id}", "getEnvironment", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"PATCH", "/api/v1/environments/{id}", "updateEnvironment", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/admin/members", "listMembers", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/admin/roles", "listBuiltInRoles", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"PATCH", "/api/v1/admin/members/{id}", "updateMemberRole", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/admin/group-mappings", "listGroupMappings", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"PATCH", "/api/v1/admin/group-mappings", "updateGroupMappings", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/admin/sso-connections", "listSSOConnections", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/admin/sso-connections", "createSSOConnection", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"DELETE", "/api/v1/admin/sso-connections/{id}", "deleteSSOConnection", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/admin/sso-connections/{id}/test", "testSSOConnection", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/admin/scim-connections", "listSCIMConnections", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/admin/scim-connections", "createSCIMConnection", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"DELETE", "/api/v1/admin/scim-connections/{id}", "deleteSCIMConnection", "manage_identity", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/admin/api-tokens", "listAPITokens", "manage_api_tokens", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/admin/api-tokens", "createAPIToken", "manage_api_tokens", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/admin/api-tokens/{id}/rotate", "rotateAPIToken", "manage_api_tokens", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"DELETE", "/api/v1/admin/api-tokens/{id}", "revokeAPIToken", "manage_api_tokens", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/admin/api-token-reveal-grants", "listAPITokenRevealGrants", "manage_api_tokens", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/admin/api-token-reveal-grants/{id}/reveal", "revealAPIToken", "manage_api_tokens", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"DELETE", "/api/v1/admin/api-token-reveal-grants/{id}", "acknowledgeAPITokenRevealGrant", "manage_api_tokens", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/audit-events", "listAuditEvents", "view_audit", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/sessions", "listSessions", "investigate_sessions", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/sessions/{id}", "getSession", "investigate_sessions", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/sessions/{id}/events", "listSessionEvents", "investigate_sessions", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/sessions/{id}/events/{eventId}", "getSessionEvent", "investigate_sessions", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"DELETE", "/api/v1/sessions/{id}", "revokeSession", "revoke_sessions", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/compliance/controls", "listComplianceControls", "view_compliance", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/compliance/evidence", "listComplianceEvidence", "view_compliance", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/settings/data-controls", "getDataControls", "view_compliance", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"PATCH", "/api/v1/settings/data-controls", "updateDataControls", "manage_data_controls", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/settings/external-data-flows", "getExternalDataFlows", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"PATCH", "/api/v1/settings/external-data-flows", "updateExternalDataFlows", "manage_data_controls", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/ai/explanations", "createAIExplanation", "view", []string{"BrowserSession"}}, riskDependency},
	{OperationDefinition{"GET", "/api/v1/system/status", "getSystemStatus", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/system/components", "listSystemComponents", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"GET", "/api/v1/system/version", "getSystemVersion", "view", []string{"BrowserSession"}}, identityDependency},
	{OperationDefinition{"POST", "/api/v1/recovery/backups", "startRecoveryBackup", "manage_identity", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/recovery/backups/{id}", "getRecoveryBackup", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/recovery/restores", "startRecoveryRestore", "manage_identity", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/recovery/restores/{id}", "getRecoveryRestore", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/home/summary", "getHomeSummary", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/findings", "listFindings", "view", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"GET", "/api/v1/findings/{id}", "getFinding", "view", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"PATCH", "/api/v1/findings/{id}", "updateFinding", "manage_findings", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"POST", "/api/v1/findings/{id}/accept-risk", "acceptFindingRisk", "manage_findings", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"POST", "/api/v1/findings/{id}/ticket", "createFindingTicket", "manage_findings", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"GET", "/api/v1/attack-paths", "listAttackPaths", "view", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"GET", "/api/v1/attack-paths/{id}", "getAttackPath", "view", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"GET", "/api/v1/attack-paths/{id}/break-options", "getAttackPathBreakOptions", "view", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"GET", "/api/v1/search", "globalSearch", "view", []string{"BrowserSession", "ProductAPIToken"}}, riskDependency},
	{OperationDefinition{"GET", "/api/v1/agents", "listAgents", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/agents/{id}", "getAgent", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"POST", "/api/v1/agents/{id}/device-association-intents", "createAgentDeviceIntent", "manage_identity", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/agents/{id}/device-associations/{associationId}/activate", "activateAgentDeviceAssociation", "manage_identity", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/agents/{id}/device-associations/{associationId}/revoke", "revokeAgentDeviceAssociation", "manage_identity", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/agents/{id}/device-associations", "listAgentDeviceAssociations", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"PATCH", "/api/v1/agents/{id}", "updateAgent", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/agents/{id}/capabilities", "getAgentCapabilities", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/agents/{id}/relationships", "getAgentRelationships", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/agents/{id}/sessions", "listAgentSessions", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/tools", "listTools", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/tools/{id}", "getTool", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/identities", "listIdentities", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/identities/{id}", "getIdentity", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/runtimes", "listRuntimes", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/runtimes/{id}", "getRuntime", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/assets/{id}", "getAsset", "view", []string{"BrowserSession", "ProductAPIToken"}}, inventoryDependency},
	{OperationDefinition{"GET", "/api/v1/sensors", "listSensors", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/gateways", "createGatewayDevice", "manage_identity", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/gateways/{id}", "getGatewayDevice", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/gateways/{id}/enrollments", "issueGatewayEnrollment", "manage_identity", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/gateways/{id}/enrollments/{enrollmentId}/revoke", "revokeGatewayEnrollment", "manage_identity", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/sensors", "createSensorEnrollment", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/sensors/{id}", "getSensor", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"PATCH", "/api/v1/sensors/{id}", "updateSensor", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"DELETE", "/api/v1/sensors/{id}", "deleteSensor", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/sensors/{id}/rotate-token", "rotateSensorToken", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/sensors/{id}/coverage", "getSensorCoverage", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/workflow-mutation-receipts", "listWorkflowMutationReceipts", "view", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/workflow-mutation-receipts/{id}/acknowledge", "acknowledgeWorkflowMutationReceipt", "view", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/policies", "listPolicies", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/policies", "createPolicy", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/policies/{id}", "getPolicy", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"PATCH", "/api/v1/policies/{id}", "updatePolicy", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"DELETE", "/api/v1/policies/{id}", "deletePolicy", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/policies/{id}/simulate", "simulatePolicy", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/policies/{id}/rollout", "rolloutPolicy", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/policies/{id}/disable", "disablePolicy", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/policies/{id}/decisions", "listPolicyDecisions", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integration-catalog", "listIntegrationCatalog", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations", "listIntegrations", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/integrations", "createIntegration", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/{id}", "getIntegration", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"PATCH", "/api/v1/integrations/{id}", "updateIntegration", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"DELETE", "/api/v1/integrations/{id}", "deleteIntegration", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/integrations/{id}/sync", "syncIntegration", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/{id}/syncs", "listIntegrationSyncs", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/{id}/syncs/{syncId}", "getIntegrationSync", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/{id}/schedule", "getIntegrationSchedule", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"PUT", "/api/v1/integrations/{id}/schedule", "putIntegrationSchedule", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"DELETE", "/api/v1/integrations/{id}/schedule", "deleteIntegrationSchedule", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/{id}/freshness", "getIntegrationFreshness", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/{id}/setup-status", "getIntegrationSetupStatus", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/integrations/{id}/test-delivery", "testIntegrationWebhook", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/{id}/delivery-status", "getIntegrationWebhookStatus", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/integrations/{id}/authorize", "authorizeIntegration", "manage_workflows", []string{"BrowserSession"}}, connectorDependency},
	{OperationDefinition{"POST", "/api/v1/integrations/{id}/reference-authorization", "authorizeIntegrationReference", "manage_workflows", []string{"BrowserSession"}}, connectorDependency},
	{OperationDefinition{"POST", "/api/v1/integrations/{id}/authorization-remediation", "remediateIntegrationAuthorization", "manage_workflows", []string{"BrowserSession"}}, connectorDependency},
	{OperationDefinition{"GET", "/api/v1/integrations/oauth/callback", "completeIntegrationOAuthCallback", "manage_workflows", []string{"BrowserSession"}}, connectorDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-templates", "listSecurityAgentTemplates", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-actions", "listSecurityActions", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-execution-controls", "getSecurityAgentExecutionControls", "manage_identity", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"PUT", "/api/v1/security-agent-execution-controls", "setSecurityAgentExecutionControl", "manage_identity", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agents", "listSecurityAgents", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/security-agents", "createSecurityAgent", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agents/{id}", "getSecurityAgent", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"PATCH", "/api/v1/security-agents/{id}", "updateSecurityAgent", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"DELETE", "/api/v1/security-agents/{id}", "deleteSecurityAgent", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/security-agents/{id}/activation", "activateSecurityAgent", "manage_workflows", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agents/{id}/activation", "getSecurityAgentActivation", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/security-agents/{id}/simulate", "simulateSecurityAgent", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/security-agents/{id}/runs", "runSecurityAgent", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-runs", "listSecurityAgentRuns", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-runs/{id}", "getSecurityAgentRun", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-audit-events/{id}", "getSecurityAgentAuditEvent", "view_audit", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-activity/{kind}/{id}/runs", "listSecurityAgentActivityRuns", "view", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-runs/{id}/activity/{kind}", "listSecurityAgentRunActivity", "view", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/security-agent-runs/{id}/cancel", "cancelSecurityAgentRun", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/security-agent-runs/{id}/cleanup-recovery", "requestSingleTestCleanupRecovery", "manage_workflows", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-runs/{id}/cleanup-recovery", "getSingleTestCleanupRecovery", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-approvals", "listSecurityAgentApprovals", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/security-agent-approvals/{id}", "getSecurityAgentApproval", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/security-agent-approvals/{id}/decision", "decideSecurityAgentApproval", "manage_workflows", []string{"BrowserSession"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/tests", "listTests", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/tests", "createTest", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/tests/{id}", "getTest", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"PATCH", "/api/v1/tests/{id}", "updateTest", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/tests/{id}/runs", "runTest", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/test-runs", "listTestRuns", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/test-runs/{id}", "getTestRun", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/test-runs/{id}/cancel", "cancelTestRun", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/attack-lab/preflight", "preflightAttackLabRun", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/attack-lab/runs", "listAttackLabRuns", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/attack-lab/runs", "createAttackLabRun", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"GET", "/api/v1/attack-lab/runs/{id}", "getAttackLabRun", "view", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/attack-lab/runs/{id}/cancel", "cancelAttackLabRun", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
	{OperationDefinition{"POST", "/api/v1/attack-lab/runs/{id}/rerun", "rerunAttackLabRun", "run_tests", []string{"BrowserSession", "ProductAPIToken"}}, workflowDependency},
})

func withBrowserExpectedScope(operations []coreOperation) []coreOperation {
	for index := range operations {
		definition := &operations[index].OperationDefinition
		switch definition.OperationID {
		case "", "startSession", "bootstrapSession", "completeSessionCallback", "completeIntegrationOAuthCallback", "signOutSession":
			continue
		}
		for schemeIndex, scheme := range definition.Security {
			if scheme != "BrowserSession" {
				continue
			}
			definition.Security = append(definition.Security, "")
			copy(definition.Security[schemeIndex+1:], definition.Security[schemeIndex:])
			definition.Security[schemeIndex] = "BrowserExpectedScope"
			break
		}
	}
	return operations
}

func CoreOperations() []OperationDefinition {
	result := make([]OperationDefinition, len(coreOperations))
	for index, operation := range coreOperations {
		result[index] = operation.OperationDefinition
	}
	return result
}

func NewComposition(dependencies Dependencies) (http.Handler, error) {
	return newComposition(dependencies, nil)
}

func newComposition(dependencies Dependencies, exports http.Handler, compliance ...http.Handler) (http.Handler, error) {
	var complianceHandler http.Handler
	var agentExportHandler http.Handler
	if len(compliance) > 2 {
		return nil, ErrInvalidComposition
	}
	if len(compliance) >= 1 {
		complianceHandler = compliance[0]
	}
	if len(compliance) == 2 {
		agentExportHandler = compliance[1]
	}
	handlers := []http.Handler{dependencies.Session, dependencies.Identity, dependencies.Inventory, dependencies.Risk, dependencies.Workflow, dependencies.Connector}
	if complianceHandler != nil {
		handlers = append(handlers, complianceHandler)
	}
	if exports != nil {
		handlers = append(handlers, exports)
	}
	if agentExportHandler != nil {
		handlers = append(handlers, agentExportHandler)
	}
	seenHandlers := make(map[uintptr]struct{}, len(handlers))
	for _, handler := range handlers {
		identity, valid := handlerIdentity(handler)
		if !valid {
			return nil, ErrInvalidComposition
		}
		if _, duplicate := seenHandlers[identity]; duplicate {
			return nil, ErrInvalidComposition
		}
		seenHandlers[identity] = struct{}{}
	}
	// Seal discoverability to this router's actual production export surface.
	// A copy keeps disabled/enabled routers and the original dependencies independent.
	if session, ok := dependencies.Session.(*sessionHTTPHandler); ok {
		local := *session
		surface, installed := exports.(*auditExportProductionSurface)
		local.auditExportsInstalled = installed && surface != nil && surface.repository != nil && !nilInterface(surface.Handler)
		dependencies.Session = &local
	}

	operations := make([]Operation, 0, len(coreOperations))
	for _, definition := range coreOperations {
		handler := dependencyHandler(dependencies, definition.dependency)
		if complianceHandler != nil && stringIn(definition.OperationID, "listComplianceControls", "listComplianceEvidence") {
			handler = complianceHandler
		}
		security := make([]CredentialKind, 0, len(definition.Security))
		for _, scheme := range definition.Security {
			switch scheme {
			case "BrowserSession":
				security = append(security, CredentialBrowserSession)
			case "BrowserExpectedScope":
				// The exact header is a request precondition, not a credential.
			case "ProductAPIToken":
				security = append(security, CredentialBearerToken)
			}
		}
		requireCSRF := definition.OperationID == "signOutSession" || definition.OperationID == "switchSessionScope" || isMutation(definition.Method) && len(security) > 0
		operations = append(operations, Operation{Method: definition.Method, Pattern: definition.Pattern, OperationID: definition.OperationID, Permission: definition.Permission, Security: security, RequireCSRF: requireCSRF, RequireFreshAuth: requiresFreshAuthentication(definition.OperationID), Handler: handler})
	}
	if exports != nil {
		operations = append(operations,
			Operation{Method: http.MethodPost, Pattern: "/api/v1/audit-exports", OperationID: "createAuditExport", Permission: "view_audit", Security: []CredentialKind{CredentialBrowserSession}, RequireCSRF: true, RequireFreshAuth: true, Handler: exports},
			Operation{Method: http.MethodGet, Pattern: "/api/v1/audit-exports/{id}", OperationID: "getAuditExport", Permission: "view_audit", Security: []CredentialKind{CredentialBrowserSession}, Handler: exports},
		)
	}
	seenOperations := make(map[string]bool, len(operations))
	if complianceHandler != nil {
		for _, definition := range complianceOperations {
			operations = append(operations, Operation{Method: definition.Method, Pattern: definition.Pattern, OperationID: definition.OperationID, Permission: "view_compliance", Security: []CredentialKind{CredentialBrowserSession}, RequireCSRF: definition.Method == http.MethodPost, RequireFreshAuth: definition.OperationID == "createComplianceExport", Handler: complianceHandler})
		}
	}
	if agentExportHandler != nil {
		for _, definition := range securityAgentExportOperations {
			operations = append(operations, Operation{Method: definition.Method, Pattern: definition.Pattern, OperationID: definition.OperationID, Permission: "view", Security: []CredentialKind{CredentialBrowserSession}, RequireCSRF: definition.Method == http.MethodPost, Handler: agentExportHandler})
		}
	}
	for _, operation := range operations {
		if seenOperations[operation.OperationID] {
			return nil, ErrInvalidComposition
		}
		seenOperations[operation.OperationID] = true
	}
	router, err := NewRouter(operations)
	if err != nil {
		return nil, errors.Join(ErrInvalidComposition, err)
	}
	router.(*operationRouter).authorizer = dependencies.Authorizer
	return router, nil
}

func requiresFreshAuthentication(operationID string) bool {
	switch operationID {
	case "createAgentDeviceIntent", "activateAgentDeviceAssociation", "revokeAgentDeviceAssociation", "createWorkspace", "updateWorkspace", "createEnvironment", "updateEnvironment",
		"updateMemberRole", "updateGroupMappings", "createAPIToken", "rotateAPIToken", "revokeAPIToken", "revealAPIToken", "acknowledgeAPITokenRevealGrant",
		"createSSOConnection", "deleteSSOConnection", "testSSOConnection", "createSCIMConnection", "deleteSCIMConnection",
		"createGatewayDevice", "issueGatewayEnrollment", "revokeGatewayEnrollment", "revokeSession", "updateDataControls", "updateExternalDataFlows", "authorizeIntegration", "authorizeIntegrationReference", "remediateIntegrationAuthorization", "createSensorEnrollment", "rotateSensorToken":
		return true
	case "activateSecurityAgent", "decideSecurityAgentApproval", "setSecurityAgentExecutionControl", "startRecoveryBackup", "startRecoveryRestore":
		return true
	default:
		return false
	}
}

func handlerIdentity(handler http.Handler) (uintptr, bool) {
	if handler == nil {
		return 0, false
	}
	value := reflect.ValueOf(handler)
	switch value.Kind() {
	case reflect.Chan, reflect.Func, reflect.Map, reflect.Pointer, reflect.Slice:
		if value.IsNil() {
			return 0, false
		}
		identity := value.Pointer()
		return identity, identity != 0
	default:
		return 0, false
	}
}

func dependencyHandler(dependencies Dependencies, kind dependencyKind) http.Handler {
	switch kind {
	case sessionDependency:
		return dependencies.Session
	case identityDependency:
		return dependencies.Identity
	case inventoryDependency:
		return dependencies.Inventory
	case riskDependency:
		return dependencies.Risk
	case workflowDependency:
		return dependencies.Workflow
	case connectorDependency:
		return dependencies.Connector
	default:
		return nil
	}
}
