package apiserver

import (
	"context"
	"encoding/json"
	"net/http"
	"time"
)

// Tests-only signatures. Functional implementation awaits root RED release.
type AgentDeviceAssociationMutation struct {
	AgentID, DeviceID, AssociationID, ChallengeID, IdempotencyKey string
	ExpectedVersion                                               int64
	TTLSeconds                                                    int32
	RequestDigest, ChallengeSHA256, Nonce                         []byte
}
type AgentDeviceAssociationAuthority interface {
	MutateAssociation(context.Context, RequestIdentity, string, AgentDeviceAssociationMutation) (json.RawMessage, error)
	ListAssociations(context.Context, RequestIdentity, string, string, int) (json.RawMessage, error)
}
type AgentDeviceAssociationHandlerConfig struct {
	NewProductID func() (string, error)
	NewNonce     func() ([]byte, error)
	Clock        func() time.Time
	SigningKey   []byte
}

func NewAgentDeviceAssociationHTTPHandler(AgentDeviceAssociationAuthority, AgentDeviceAssociationHandlerConfig) (http.Handler, error) {
	return nil, ErrRepositoryUnavailable
}
