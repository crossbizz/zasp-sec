// Package gatewayassociationwire defines administrative Device acceptance only.
package gatewayassociationwire

import (
	"errors"
	"net/http"
	"time"
)

const MaximumBytes = 16384
const ChallengeSchema = "agent-device-intent-v1"
const EnvelopeSchema = "agent-device-challenge-envelope-v1"
const AcceptSchema = "agent-device-accept-v1"
const AcceptPath = "/internal/v1/runtime-gateway/agent-device-associations/accept"

var ErrInvalid = errors.New("device association rejected")

type DeviceBinding struct {
	OrganizationID, WorkspaceID, EnvironmentID, DeviceID, CredentialID string
	CredentialGeneration                                               uint64
	PublicKey                                                          string
	ExpiresAt                                                          time.Time
}
type Challenge struct {
	Schema                     string    `json:"schema"`
	ChallengeID                string    `json:"challenge_id"`
	AssociationID              string    `json:"association_id"`
	OrganizationID             string    `json:"organization_id"`
	WorkspaceID                string    `json:"workspace_id"`
	EnvironmentID              string    `json:"environment_id"`
	AgentID                    string    `json:"agent_id"`
	AgentSourceDigest          string    `json:"agent_source_digest"`
	DeviceID                   string    `json:"device_id"`
	ExpectedAssociationVersion uint64    `json:"expected_association_version"`
	Nonce                      string    `json:"nonce"`
	ExpiresAt                  time.Time `json:"expires_at"`
}
type ChallengeEnvelope struct {
	Schema          string `json:"schema"`
	ChallengeWire   string `json:"challenge_wire"`
	ChallengeSHA256 string `json:"challenge_sha256"`
}
type DeviceCredential struct {
	CredentialID         string    `json:"credential_id"`
	CredentialGeneration uint64    `json:"credential_generation"`
	ExpiresAt            time.Time `json:"expires_at"`
}
type Acceptance struct {
	RequestSHA256 string           `json:"request_sha256"`
	Credential    DeviceCredential `json:"credential"`
	AcceptedAt    time.Time        `json:"accepted_at"`
	ExpiresAt     time.Time        `json:"expires_at"`
}
type AcceptResponse struct {
	ChallengeID     string     `json:"challenge_id"`
	ChallengeSHA256 string     `json:"challenge_sha256"`
	AssociationID   string     `json:"association_id"`
	Acceptance      Acceptance `json:"acceptance"`
	Replayed        bool       `json:"replayed"`
}

func ParseChallengeEnvelope([]byte) (ChallengeEnvelope, error) {
	return ChallengeEnvelope{}, ErrInvalid
}
func MarshalChallengeEnvelope(ChallengeEnvelope) ([]byte, error)                  { return nil, ErrInvalid }
func ParseChallenge([]byte) (Challenge, error)                                    { return Challenge{}, ErrInvalid }
func ChallengeFromEnvelope(ChallengeEnvelope) (Challenge, error)                  { return Challenge{}, ErrInvalid }
func BuildAcceptRequest(ChallengeEnvelope) ([]byte, error)                        { return nil, ErrInvalid }
func ParseAcceptResponse([]byte) (AcceptResponse, error)                          { return AcceptResponse{}, ErrInvalid }
func MarshalAcceptResponse(AcceptResponse) ([]byte, error)                        { return nil, ErrInvalid }
func AcceptResponseMatches(AcceptResponse, []byte, DeviceBinding, time.Time) bool { return false }
func SignAcceptRequest(*http.Request, []byte, DeviceBinding, func([]byte) ([]byte, error), time.Time) error {
	return ErrInvalid
}
