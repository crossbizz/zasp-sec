package gatewayenrollmentcustody

import (
	associationwire "github.com/zasp-ai/zasp-sec/services/platform/gatewayassociationwire"
	"time"
)

type AssociationSnapshot struct {
	Challenge  associationwire.Challenge
	Envelope   associationwire.ChallengeEnvelope
	RequestRaw []byte
	Binding    associationwire.DeviceBinding
	Receipt    *associationwire.AcceptResponse
}
type Association struct{}

func (*Store) BeginAssociation(associationwire.ChallengeEnvelope, time.Time) (*Association, error) {
	return nil, ErrUnavailable
}
func (*Association) Source() (string, AssociationSnapshot, error) {
	return "", AssociationSnapshot{}, ErrUnavailable
}
func (*Association) Sign([]byte) ([]byte, error)                             { return nil, ErrUnavailable }
func (*Association) Confirm(associationwire.AcceptResponse, time.Time) error { return ErrUnavailable }
func (*Association) Close() error                                            { return nil }
