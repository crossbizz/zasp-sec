package gatewaycontrol

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"
	wire "github.com/zasp-ai/zasp-sec/services/platform/gatewayassociationwire"
)

func associationFixture(t *testing.T) (Authority, []byte, wire.AcceptResponse, wire.DeviceBinding, time.Time) {
	t.Helper()
	pub, _ := fixtureGatewayKey(t)
	a := fixtureAuthority(pub)
	now := time.Date(2026, 8, 20, 12, 0, 0, 0, time.UTC)
	q := wire.Challenge{Schema: wire.ChallengeSchema, ChallengeID: fixtureID(7), AssociationID: fixtureID(8), OrganizationID: a.OrganizationID, WorkspaceID: a.WorkspaceID, EnvironmentID: a.EnvironmentID, AgentID: fixtureID(9), AgentSourceDigest: strings.Repeat("a", 64), DeviceID: a.DeviceID, ExpectedAssociationVersion: 0, Nonce: base64.RawURLEncoding.EncodeToString(bytes.Repeat([]byte{1}, 32)), ExpiresAt: now.Add(3 * time.Minute)}
	rawChallenge, _ := json.Marshal(q)
	sum := sha256.Sum256(rawChallenge)
	challengeDigest := hex.EncodeToString(sum[:])
	raw, _ := json.Marshal(struct {
		Schema          string `json:"schema"`
		ChallengeWire   string `json:"challenge_wire"`
		ChallengeSHA256 string `json:"challenge_sha256"`
	}{wire.AcceptSchema, base64.RawURLEncoding.EncodeToString(rawChallenge), challengeDigest})
	sum = sha256.Sum256(raw)
	response := wire.AcceptResponse{ChallengeID: q.ChallengeID, ChallengeSHA256: challengeDigest, AssociationID: q.AssociationID, Acceptance: wire.Acceptance{RequestSHA256: hex.EncodeToString(sum[:]), Credential: wire.DeviceCredential{CredentialID: a.CredentialID, CredentialGeneration: a.CredentialGeneration, ExpiresAt: a.ExpiresAt}, AcceptedAt: now, ExpiresAt: q.ExpiresAt}, Replayed: false}
	binding := wire.DeviceBinding{OrganizationID: a.OrganizationID, WorkspaceID: a.WorkspaceID, EnvironmentID: a.EnvironmentID, DeviceID: a.DeviceID, CredentialID: a.CredentialID, CredentialGeneration: a.CredentialGeneration, PublicKey: base64.RawURLEncoding.EncodeToString(a.PublicKey), ExpiresAt: a.ExpiresAt}
	return a, raw, response, binding, now
}

type associationRepositoryStub struct {
	response wire.AcceptResponse
	readyErr error
	calls    int
	raw      []byte
	binding  wire.DeviceBinding
}

func (s *associationRepositoryStub) AssociationReady(context.Context) error { return s.readyErr }
func (s *associationRepositoryStub) AcceptAgentDevice(_ context.Context, raw []byte, b wire.DeviceBinding) (wire.AcceptResponse, error) {
	s.calls++
	s.raw = append([]byte(nil), raw...)
	s.binding = b
	return s.response, nil
}
func TestAgentDeviceAssociationSignedAcceptRequiresCurrentDevice(t *testing.T) {
	for _, name := range []string{"accepted", "off", "catalog_failure", "bad_signature", "scope_header", "malformed", "oversize", "wrong_receipt_generation", "wrong_media", "query"} {
		t.Run(name, func(t *testing.T) {
			authority, raw, response, binding, now := associationFixture(t)
			repo := &controlRepositoryStub{authority: authority}
			own := &associationRepositoryStub{response: response}
			var optional AssociationRepository = own
			want := 200
			switch name {
			case "off":
				optional = nil
				want = 404
			case "catalog_failure":
				own.readyErr = errors.New("not installed")
				want = 503
			case "bad_signature", "scope_header":
				want = 401
			case "malformed":
				raw = []byte(`{}`)
				want = 400
			case "oversize":
				raw = bytes.Repeat([]byte(" "), 16385)
				want = 400
			case "wrong_receipt_generation":
				own.response.Acceptance.Credential.CredentialGeneration++
				want = 503
			case "wrong_media", "query":
				want = 404
			}
			handler, e := NewHTTPHandler(HTTPHandlerConfig{Repository: repo, AssociationRepository: optional, Clock: func() time.Time { return now }, OperationTimeout: time.Second, MaximumBodyBytes: 1024})
			if e != nil {
				t.Fatal(e)
			}
			request := httptest.NewRequest(http.MethodPost, "https://gateway-control.zasp.example"+AssociationAcceptPath, bytes.NewReader(raw))
			request.Header.Set("Content-Type", JSONMediaType)
			if name == "query" {
				request.URL.RawQuery = "unexpected=1"
			}
			_, key := fixtureGatewayKey(t)
			if SignRequest(request, raw, authority.CredentialID, key, now) != nil {
				t.Fatal("fixture signing")
			}
			switch name {
			case "bad_signature":
				request.Header.Set(SignatureHeader, strings.Repeat("A", 86))
			case "scope_header":
				request.Header.Set("X-Tenant-ID", fixtureID(6))
			case "wrong_media":
				request.Header.Set("Content-Type", "text/plain")
			}
			out := httptest.NewRecorder()
			handler.ServeHTTP(out, request)
			if out.Code != want {
				t.Fatalf("status=%d want=%d body=%s", out.Code, want, out.Body)
			}
			if name == "accepted" {
				if own.calls != 1 || own.binding != binding || !bytes.Equal(own.raw, raw) || repo.authorityCalls != 1 || out.Header().Get("Cache-Control") != "no-store" || out.Header().Get("Pragma") != "no-cache" {
					t.Fatal("signed route lost exact authority/body/response")
				}
				var got map[string]any
				if json.Unmarshal(out.Body.Bytes(), &got) != nil || len(got) != 5 || got["new_mutation"] != nil {
					t.Fatal("private marker leaked")
				}
			} else if name != "wrong_receipt_generation" && own.calls != 0 {
				t.Fatal("rejected request mutated")
			}
			if name == "catalog_failure" {
				probe := httptest.NewRequest(http.MethodGet, "https://gateway-control.zasp.example"+AuthorityPath, nil)
				_ = SignRequest(probe, nil, authority.CredentialID, key, now)
				prior := httptest.NewRecorder()
				handler.ServeHTTP(prior, probe)
				if prior.Code != 200 {
					t.Fatal("own catalog poisoned original authority")
				}
			}
		})
	}
}

type associationTx struct {
	pgx.Tx
	response           []byte
	confirmed          bool
	commitErr          error
	queries            []string
	args               [][]any
	commits, rollbacks int
}

func (t *associationTx) QueryRow(_ context.Context, q string, args ...any) pgx.Row {
	t.queries = append(t.queries, q)
	t.args = append(t.args, args)
	if len(t.queries) == 1 {
		return associationRow{raw: t.response}
	}
	return associationRow{confirmed: t.confirmed}
}
func (t *associationTx) Commit(context.Context) error   { t.commits++; return t.commitErr }
func (t *associationTx) Rollback(context.Context) error { t.rollbacks++; return nil }

type associationRow struct {
	raw       []byte
	confirmed bool
}

func (r associationRow) Scan(dest ...any) error {
	switch p := dest[0].(type) {
	case *[]byte:
		*p = append([]byte(nil), r.raw...)
	case *bool:
		*p = r.confirmed
	default:
		return errors.New("badscan")
	}
	return nil
}

type associationPool struct {
	tx      *associationTx
	options pgx.TxOptions
}

func (p *associationPool) BeginTx(_ context.Context, o pgx.TxOptions) (pgx.Tx, error) {
	p.options = o
	return p.tx, nil
}
func TestAgentDeviceAssociationSamePoolConfirmBeforeCommit(t *testing.T) {
	for _, name := range []string{"accepted", "replay", "final_fence_false", "unknown_commit", "wrong_generation", "missing_private_marker", "historical_marker_mismatch"} {
		t.Run(name, func(t *testing.T) {
			_, raw, response, binding, now := associationFixture(t)
			if name == "replay" {
				response.Replayed = true
			}
			if name == "wrong_generation" {
				response.Acceptance.Credential.CredentialGeneration++
			}
			newMutation := name != "replay" && name != "historical_marker_mismatch"
			internal, _ := json.Marshal(map[string]any{"receipt": response, "new_mutation": newMutation})
			if name == "missing_private_marker" {
				internal, _ = json.Marshal(map[string]any{"receipt": response})
			}
			tx := &associationTx{response: internal, confirmed: name != "final_fence_false"}
			if name == "unknown_commit" {
				tx.commitErr = errors.New("connection lost")
			}
			pool := &associationPool{tx: tx}
			pin := strings.Repeat("a", 64)
			got, e := CommitProductionAgentDeviceAcceptance(context.Background(), pool, raw, binding, pin, now)
			success := name == "accepted" || name == "replay"
			if (e == nil) != success {
				t.Fatalf("receipt=%#v err=%v queries=%v", got, e, tx.queries)
			}
			if tx.rollbacks != 1 {
				t.Fatal("rollback cleanup missing")
			}
			if success {
				if pool.options.IsoLevel != pgx.ReadCommitted || tx.commits != 1 || len(tx.queries) != 2 || tx.queries[0] != `SELECT zasp_agent_device_association_v1.accept_intent($1,$2,$3)` || tx.queries[1] != `SELECT zasp_agent_device_association_v1.confirm_device($1,$2,$3::jsonb,$4)` {
					t.Fatal("not original samepool closed transaction")
				}
				if tx.args[0][0] != binding.CredentialID || !bytes.Equal(tx.args[0][1].([]byte), raw) || tx.args[0][2] != pin || tx.args[1][3] != pin || !bytes.Equal(tx.args[1][2].(json.RawMessage), internal) {
					t.Fatal("confirm changed exact private wrapper/request/pin")
				}
			} else if name != "unknown_commit" && tx.commits != 0 {
				t.Fatal("unconfirmed acceptance committed")
			}
		})
	}
}
