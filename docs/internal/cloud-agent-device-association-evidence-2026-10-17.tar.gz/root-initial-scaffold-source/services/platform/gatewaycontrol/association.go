package gatewaycontrol

import (
	"context"
	wire "github.com/zasp-ai/zasp-sec/services/platform/gatewayassociationwire"
	"time"
)

const AssociationAcceptPath = "/internal/v1/runtime-gateway/agent-device-associations/accept"

type AssociationRepository interface {
	AssociationReady(context.Context) error
	AcceptAgentDevice(context.Context, []byte, wire.DeviceBinding) (wire.AcceptResponse, error)
}

func CommitProductionAgentDeviceAcceptance(context.Context, InstallationTransactionPool, []byte, wire.DeviceBinding, string, time.Time) (wire.AcceptResponse, error) {
	return wire.AcceptResponse{}, errPostgresRepository
}
