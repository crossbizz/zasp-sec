package migrations

// Tests-only fail-closed signature scaffolding. No installer capability,
// compiled SQL, live authority, readiness or selected feature is provided yet.
func AgentDeviceAssociationProfileChecksum() string       { return "" }
func AgentDeviceAssociationAuditProfileChecksum() string  { return "" }
func IsAgentDeviceAssociationProfileChecksum(string) bool { return false }
