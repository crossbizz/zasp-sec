package main

import "testing"

func TestAgentDeviceAssociationProductionClosedSelection(t *testing.T) {
	for _, name := range []string{"legacy", "disabled_empty", "disabled_pin", "invalid_flag", "missing_pin", "unknown_pin"} {
		t.Run(name, func(t *testing.T) {
			v := map[string]string{"ZASP_DATABASE_URL": "postgresql://gateway_control@database.internal:5432/zasp?sslmode=verify-full", "ZASP_GATEWAY_CONTROL_MAX_BODY_BYTES": "16384", "ZASP_GATEWAY_CONTROL_OPERATION_TIMEOUT": "3s", "ZASP_GATEWAY_CONTROL_READINESS_TTL": "30s", "ZASP_GATEWAY_CONTROL_SHUTDOWN_TIMEOUT": "10s"}
			switch name {
			case "disabled_empty":
				v["ZASP_AGENT_DEVICE_ASSOCIATION_ENABLED"] = "false"
			case "disabled_pin":
				v["ZASP_AGENT_DEVICE_ASSOCIATION_PROFILE_CHECKSUM"] = "unselected"
			case "invalid_flag":
				v["ZASP_AGENT_DEVICE_ASSOCIATION_ENABLED"] = "TRUE"
			case "missing_pin":
				v["ZASP_AGENT_DEVICE_ASSOCIATION_ENABLED"] = "true"
			case "unknown_pin":
				v["ZASP_AGENT_DEVICE_ASSOCIATION_ENABLED"] = "true"
				v["ZASP_AGENT_DEVICE_ASSOCIATION_PROFILE_CHECKSUM"] = "unknown"
			}
			_, e := loadProductionControlConfig(func(k string) string { return v[k] })
			if (e == nil) != (name == "legacy" || name == "disabled_empty") {
				t.Fatalf("err=%v", e)
			}
		})
	}
}
