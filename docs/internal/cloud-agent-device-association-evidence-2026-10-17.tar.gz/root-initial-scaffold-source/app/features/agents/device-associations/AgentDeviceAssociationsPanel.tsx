import type {AgentDeviceAssociationsAPI} from './api';
export type AssociationAuthority=Readonly<{key:string,principalID:string,fresh:boolean,sessionValid:boolean,isCurrent():boolean}>;
export function AgentDeviceAssociationsPanel(_props:{agentID:string,api:AgentDeviceAssociationsAPI,authority:AssociationAuthority,onReauthenticate():void}){return <section aria-label="Administrative device associations"><p>Associations unavailable</p></section>;}
