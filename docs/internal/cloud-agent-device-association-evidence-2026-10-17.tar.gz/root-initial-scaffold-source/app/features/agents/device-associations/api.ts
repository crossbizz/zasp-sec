import type {APIClient} from '../../../../apps/web/api/client';
export type AssociationScope=Readonly<{organization_id:string,workspace_id:string,environment_id:string}>;
export type AssociationAttempt=Readonly<{idempotencyKey:string}>;
export function createAssociationAttempt():AssociationAttempt{return {idempotencyKey:`association_${globalThis.crypto.randomUUID()}`};}
export function createAgentDeviceAssociationsAPI(_client:APIClient,_scope:AssociationScope){return {
 async listAgentDeviceAssociations(_agentID:string,_options?:{cursor?:string,limit?:number},_signal?:AbortSignal):Promise<unknown>{throw new Error('Association unavailable');},
 async createAgentDeviceIntent(_agentID:string,_body:{device_id:string,expected_association_version:number,ttl_seconds:number},_attempt?:AssociationAttempt):Promise<unknown>{throw new Error('Association unavailable');},
 async activateAgentDeviceAssociation(_agentID:string,_associationID:string,_body:{challenge_id:string,challenge_sha256:string,expected_association_version:number},_attempt?:AssociationAttempt):Promise<unknown>{throw new Error('Association unavailable');},
 async revokeAgentDeviceAssociation(_agentID:string,_associationID:string,_body:{expected_association_version:number},_attempt?:AssociationAttempt):Promise<unknown>{throw new Error('Association unavailable');}
 };}
export type AgentDeviceAssociationsAPI=ReturnType<typeof createAgentDeviceAssociationsAPI>;
