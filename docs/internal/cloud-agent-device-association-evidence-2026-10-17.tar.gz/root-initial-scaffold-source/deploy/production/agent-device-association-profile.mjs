export function normalizeAgentDeviceAssociation(value){if(value===undefined)return undefined;throw new Error('Agent device association deployment rejected');}
export function validateAgentDeviceAssociationResources(){throw new Error('Agent device association deployment rejected');}
