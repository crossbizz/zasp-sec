import {normalizeGatewayBootstrap,validateGatewayBootstrapResources} from "./gateway-bootstrap-profile.mjs";
import { normalizeGatewayInstallation, normalizeGatewayInstallationProducer, validateGatewayInstallationResources, validateGatewayInstallationProducerResources } from "./gateway-installation-profile.mjs";
import { normalizeSensorNodeCoverage, validateSensorNodeCoverageResources, normalizeSensorNodeCoverageProducer, validateSensorNodeCoverageProducerResources } from "./sensor-node-coverage-profile.mjs";
import { normalizeAgentOwnershipWrite, validateAgentOwnershipWriteResources } from "./agent-ownership-write-profile.mjs";
import { normalizeAgentExposureFilter, validateAgentExposureFilterResources } from "./agent-exposure-filter-profile.mjs";
import { normalizeAgentRead, validateAgentReadResources } from "./agent-read-profile.mjs";
import { normalizeAgentOwnerFilter, validateAgentOwnerFilterResources } from "./agent-owner-filter-profile.mjs";
import { normalizeEnvironmentClass, validateEnvironmentClassResources } from "./environment-class-profile.mjs";
import { execFile } from "node:child_process";
import { createHash, X509Certificate } from "node:crypto";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { isIP } from "node:net";
import { tmpdir } from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import { loadAll, JSON_SCHEMA } from "js-yaml";
import { validDiscoveryScheduleReplayPhase, validSessionSearchPhase, validateDiscoveryScheduleReplayResources, validateSessionSearchResources } from "./session-search-rollout.mjs";
import { auditExportMigrationCommand, normalizeAuditExports, validateAuditExportResources } from "./audit-export-rollout.mjs";
import { normalizeAttackLabReconciler, validateAttackLabReconcilerResources, validateAttackLabReconcilerCollisions, attackLabReconcilerMigrationCommand } from "./attack-lab-reconciler-rollout.mjs";
import { validateAttackLabWorkflowReadiness } from "./attack-lab-workflow-readiness.mjs";
import { normalizeEvidenceExportWorkflow, validateExportWorkflowReadiness } from "./export-workflow-readiness.mjs";
import { normalizeTestReconciler, validateTestReconcilerResources } from "./test-reconciler-rollout.mjs";
import { normalizeComplianceExports, validateComplianceExportResources, validateComplianceExportCollisions, complianceExportMigrationCommand } from "./compliance-export-rollout.mjs";
import { normalizeAuthorizationTemporalProfile, authorizationTemporalMigrationCommands } from "./authorization-temporal-profile.mjs";
import { validateAuthorizationTemporalResources } from "./authorization-temporal-resources.mjs";
import { normalizeOptionalEgress, validateOptionalEgressResources } from "./optional-egress-profile.mjs";
import { normalizeRetention, validateRetentionResources } from "./retention-profile.mjs";

const exec = promisify(execFile);
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../..");
const digestPattern = /^[a-z0-9][a-z0-9./_-]*(?::[A-Za-z0-9._-]+)?@sha256:[0-9a-f]{64}$/;
const hostPattern = /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;
const namePattern = /^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$/;
const productIDPattern = /^pid_[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const imageNames = Object.freeze(["web", "agentsecApi", "agentsecWorker", "attackLabRunner", "redTeamWorker", "eventIngest", "gatewayControl", "runtimeGateway", "sensorAgent"]);
const tetragonChartDigest = "4935787067939cacfe779366e9959962458d0cb6accdb368ec2554c1b733b3b2";
const discoveryKeys = Object.freeze([
  "parserVersion", "toolVersion", "awsCollectorVersion", "kubernetesCollectorVersion", "githubCollectorVersion", "oktaCollectorVersion",
  "awsRegion", "queueURL", "roleArn", "webIdentityTokenFile", "secretPrefix", "evidenceBucket", "evidenceBucketOwner", "evidenceKMSKeyArn",
  "githubAppID", "githubPrivateKeyReference", "oktaClientID", "oktaClientSecretReference", "providerTimeout", "readinessTimeout",
]);
const projectionSearchKeys = Object.freeze(["awsRegion", "endpoint", "index", "roleArn", "webIdentityTokenFile", "initRoleArn"]);
const projectionRiskKeys = Object.freeze(["roleArn"]);
const projectionGraphKeys = Object.freeze(["awsRegion", "endpoint", "endpointCIDR", "credentialReference", "schemaCredentialReference", "secretPrefix", "roleArn", "webIdentityTokenFile", "initRoleArn", "expectedPrincipal", "expectedRole"]);
const outboxKeys = Object.freeze(["awsRegion", "queueURL", "roleArn", "webIdentityTokenFile", "egressCIDRs"]);
const recoveryKeys = Object.freeze(["canaryEnabled", "awsRegion", "backupQueueURL", "restoreQueueURL", "evidenceBucket", "evidenceBucketOwner", "evidenceKMSKeyArn", "signingKMSKeyArn", "backupOutboxRoleArn", "restoreOutboxRoleArn", "backupRoleArn", "restoreRoleArn", "webIdentityTokenFile", "neonProjectID", "neonBranchID", "neonSecretReference", "kubernetesEndpoint", "runnerImage", "runnerServiceAccount", "egressCIDRs", "neonEgressCIDRs", "kubernetesAPICIDRs"]);
const redTeamKeys = Object.freeze(["awsRegion", "queueURL", "evidenceBucket", "evidenceBucketOwner", "evidenceKMSKeyArn", "outboxRoleArn", "workerRoleArn", "adapterRoleArn", "webIdentityTokenFile", "runnerTimeout", "targetEndpoint", "targetAllowedCIDRs", "readinessCredentialReference", "egressCIDRs"]);
const attackLabKeys = Object.freeze(["runnerTestRoleArn", "awsRegion", "queueURL", "evidenceBucket", "evidenceBucketOwner", "evidenceKMSKeyArn", "controllerRoleArn", "outboxRoleArn", "proxyRoleArn", "webIdentityTokenFile", "securityGroupID", "proxySecurityGroupID", "targetAllowedCIDRs", "egressCIDRs", "kubernetesAPICIDRs", "readinessCredentialReference", "operationTimeout", "proxyRequestTimeout", "proxyShutdownTimeout", "proxyCABundleBase64"]);
const runtimeKeys = Object.freeze([
  "awsRegion", "queueURL", "rawBucket", "rawBucketOwner", "rawKMSKeyArn", "openSearchEndpoint", "openSearchIndex", "webIdentityTokenFile",
  "eventIngestRoleArn", "gatewayControlRoleArn", "outboxRoleArn", "coordinatorRoleArn", "archiveRoleArn", "indexRoleArn", "correlationRoleArn", "projectionRoleArn", "completeRoleArn", "egressCIDRs",
]);
const connectorKeys = Object.freeze(["awsRegion", "roleArn", "awsCustomerRolePrefixes", "awsCustomerRoleARNs", "webIdentityTokenFile", "kmsKeyArn", "secretPrefix", "githubClientID", "githubClientSecretReference", "githubAppID", "githubPrivateKeyReference", "oktaClientID", "oktaClientSecretReference"]);
const connectorEgressKeys = Object.freeze(["aws", "github", "okta", "kubernetes"]);
const nangoKeys = Object.freeze(["storageSecretName", "databaseEgressCIDRs", "providerEgressCIDRs"]);
const telemetryKeys = Object.freeze(["backend", "endpoint", "authSecretName", "egressCIDRs"]);
const securityAgentPlannerKeys = Object.freeze(["endpoint", "model", "egressCIDRs"]);

export async function inspectContainerBuilds() {
  const definitions = [
    { name: "web", file: "web.Dockerfile", port: 3000 },
    { name: "agentsec-api", file: "api.Dockerfile", port: 8080 },
    { name: "agentsec-worker", file: "worker.Dockerfile", port: 8081 },
    { name: "attack-lab-runner", file: "attack-lab-runner.Dockerfile", port: null },
    { name: "red-team-worker", file: "redteam-worker.Dockerfile", port: 8081, user: "1000:1000" },
    { name: "event-ingest", file: "event-ingest.Dockerfile", port: 8081 },
    { name: "gateway-control", file: "gateway-control.Dockerfile", port: 8081 },
    { name: "runtime-gateway", file: "runtime-gateway.Dockerfile", port: 8081 },
    { name: "sensor-agent", file: "sensor-agent.Dockerfile", port: 8081 },
  ];
  return Promise.all(definitions.map(async ({ name, file, port, user: expectedUser = "65532:65532" }) => {
    const source = await readFile(path.join(here, file), "utf8");
    const runtime = source.slice(source.lastIndexOf("\nFROM "));
    const fromLines = [...source.matchAll(/^FROM\s+(\S+)/gm)].map((match) => match[1]);
    const user = runtime.match(/^USER ([^\n]+)$/m)?.[1] ?? "";
    const healthcheck = runtime.match(/^HEALTHCHECK ([^\n]+)$/m)?.[1] ?? "";
    const exposed = runtime.match(/^EXPOSE ([^\n]+)$/m)?.[1]?.split(/\s+/).map(Number) ?? [];
    return Object.freeze({
      name, user, port, healthcheck,
      readOnlyCompatible: user === expectedUser && (port === null ? exposed.length === 0 && healthcheck === "" : exposed.includes(port)) && !/\b(?:VOLUME|sudo|chmod 777)\b/i.test(runtime),
      digestPinned: fromLines.length >= 2 && fromLines.every((image) => /@sha256:[0-9a-f]{64}$/.test(image)),
      containsSecret: /(?:ARG|ENV)\s+[^\n]*(?:SECRET|TOKEN|PASSWORD|DSN)/i.test(source),
    });
  }));
}

export async function renderRelease(value, options = { schemaVersion: 49 }) {
  if (!validRelease(value) || !options || Object.keys(options).some(key => !["schemaVersion", "sessionSearchPhase", "auditExports", "testReconciler", "complianceExports", "attackLabReconciler", "evidenceExportWorkflow", "discoveryScheduleReplayPhase", "runtimeServices", "authorizationTemporal", "optionalEgress", "retentionReferenceExpiry", "environmentClass", "agentOwnerFilter", "agentRead", "agentOwnershipWrite", "agentExposureFilter", "sensorNodeCoverage", "gatewayInstallation", "gatewayBootstrap"].includes(key))) throw new Error("release rejected");
  const platformAccountID = value.discovery.roleArn.match(/^arn:aws:iam::([0-9]{12}):role\//)[1];
  const authorizationTemporal = normalizeAuthorizationTemporalProfile(options.authorizationTemporal, options, platformAccountID);
  const runtimeServices = options.runtimeServices ? structuredClone(options.runtimeServices) : undefined;
  const optionalEgress = normalizeOptionalEgress(options.optionalEgress, authorizationTemporal, runtimeServices);
  const environmentClass = normalizeEnvironmentClass(options.environmentClass, authorizationTemporal, runtimeServices);
  const agentOwnerFilter = normalizeAgentOwnerFilter(options.agentOwnerFilter, authorizationTemporal, runtimeServices);
  const agentRead = normalizeAgentRead(options.agentRead, authorizationTemporal, runtimeServices);
  const sensorNodeCoverage = normalizeSensorNodeCoverage(options.sensorNodeCoverage, authorizationTemporal, runtimeServices);
  const gatewayInstallation = normalizeGatewayInstallation(options.gatewayInstallation, authorizationTemporal, runtimeServices);
  const gatewayBootstrap = normalizeGatewayBootstrap(options.gatewayBootstrap, authorizationTemporal, runtimeServices);
  const agentOwnershipWrite = normalizeAgentOwnershipWrite(options.agentOwnershipWrite, authorizationTemporal, runtimeServices);
  const agentExposureFilter = normalizeAgentExposureFilter(options.agentExposureFilter, authorizationTemporal, runtimeServices);
  const retention = normalizeRetention(options.retentionReferenceExpiry, authorizationTemporal, runtimeServices);
  if (authorizationTemporal) {
    const roles = Object.values(value).flatMap(section => section && typeof section === "object" ? Object.entries(section).filter(([key]) => /rolearn$/i.test(key)).map(([, role]) => role) : []);
    if (roles.includes(authorizationTemporal.workerRoleArn) || roles.includes(authorizationTemporal.projectorRoleArn) || authorizationTemporal.adapterRoleArn !== value.redTeam.adapterRoleArn) throw new Error("release rejected");
  }
  if (authorizationTemporal ? options.sessionSearchPhase !== undefined || options.discoveryScheduleReplayPhase !== undefined || ["auditExports", "testReconciler", "complianceExports", "attackLabReconciler", "evidenceExportWorkflow"].some(k => options[k] !== undefined) : !validSessionSearchPhase(options.schemaVersion, options.sessionSearchPhase ?? "compatibility") || !validDiscoveryScheduleReplayPhase(options.schemaVersion, options.discoveryScheduleReplayPhase)) throw new Error("release rejected");
  const schemaVersion = options.schemaVersion;
  const sessionSearchPhase = authorizationTemporal ? "precision-intake" : options.sessionSearchPhase ?? "compatibility";
  const discoveryScheduleReplayPhase = authorizationTemporal ? "active" : options.discoveryScheduleReplayPhase;
  const auditExports = normalizeAuditExports(options.auditExports, platformAccountID, schemaVersion, sessionSearchPhase);
  const testReconciler = normalizeTestReconciler(options.testReconciler, platformAccountID, schemaVersion, sessionSearchPhase);
  const complianceExports = normalizeComplianceExports(options.complianceExports, platformAccountID, schemaVersion, sessionSearchPhase);
  const evidenceExportWorkflow = normalizeEvidenceExportWorkflow(options.evidenceExportWorkflow, schemaVersion, complianceExports);
  validateComplianceExportCollisions(value, complianceExports, auditExports, testReconciler);
  const attackLabReconciler = normalizeAttackLabReconciler(options.attackLabReconciler, platformAccountID, schemaVersion, sessionSearchPhase);
  validateAttackLabReconcilerCollisions(value, attackLabReconciler, auditExports, testReconciler, complianceExports);
  const set = [
    ["schema.expectedVersion", String(schemaVersion)],
    ["runtime.sessionSearchPhase", sessionSearchPhase],
    ["rollout.discoveryScheduleReplayPhase", discoveryScheduleReplayPhase ?? "steady"],
    ["global.publicOrigin", `https://${value.host}`],
    ["global.trustedProxyCIDRs[0]", "10.20.0.0/16"],
    ...value.awsS3CIDRs.map((cidr, index) => [`network.s3CIDRs[${index}]`, cidr]),
    ["serviceAccounts.api.roleArn", `arn:aws:iam::${platformAccountID}:role/zasp-production-api`],
    ["serviceAccounts.migration.roleArn", `arn:aws:iam::${platformAccountID}:role/zasp-production-migration`],
    ["serviceAccounts.worker.roleArn", value.discovery.roleArn],
    ["serviceAccounts.scheduler.roleArn", `arn:aws:iam::${platformAccountID}:role/zasp-production-discovery-scheduler`],
    ["serviceAccounts.securityAgent.roleArn", `arn:aws:iam::${platformAccountID}:role/zasp-production-security-agent-worker`],
    ["serviceAccounts.securityAgentAction.roleArn", `arn:aws:iam::${platformAccountID}:role/zasp-production-security-agent-action-worker`],
    ["serviceAccounts.policyDeployment.roleArn", `arn:aws:iam::${platformAccountID}:role/zasp-production-policy-deployment-worker`],
    ["serviceAccounts.projectionRisk.roleArn", value.projectionRisk.roleArn],
    ["serviceAccounts.projectionGraph.roleArn", value.projectionGraph.roleArn],
    ["serviceAccounts.projectionGraphInit.roleArn", value.projectionGraph.initRoleArn],
    ["serviceAccounts.projectionSearch.roleArn", value.projectionSearch.roleArn],
    ["serviceAccounts.projectionSearchInit.roleArn", value.projectionSearch.initRoleArn],
    ["serviceAccounts.outbox.roleArn", value.outbox.roleArn],
    ["serviceAccounts.recoveryBackupOutbox.roleArn", value.recovery.backupOutboxRoleArn],
    ["serviceAccounts.recoveryRestoreOutbox.roleArn", value.recovery.restoreOutboxRoleArn],
    ["serviceAccounts.recoveryBackup.roleArn", value.recovery.backupRoleArn],
    ["serviceAccounts.recoveryRestore.roleArn", value.recovery.restoreRoleArn],
    ["serviceAccounts.redTeamOutbox.roleArn", value.redTeam.outboxRoleArn],
    ["serviceAccounts.redTeamWorker.roleArn", value.redTeam.workerRoleArn],
    ["serviceAccounts.redTeamAdapter.roleArn", value.redTeam.adapterRoleArn],
    ["serviceAccounts.attackLabController.roleArn", value.attackLab.controllerRoleArn],
    ["serviceAccounts.attackLabOutbox.roleArn", value.attackLab.outboxRoleArn],
    ["serviceAccounts.attackLabProxy.roleArn", value.attackLab.proxyRoleArn],
    ["serviceAccounts.runtimeIngest.roleArn", value.runtime.eventIngestRoleArn],
    ["serviceAccounts.gatewayControl.roleArn", value.runtime.gatewayControlRoleArn],
    ["serviceAccounts.runtimeOutbox.roleArn", value.runtime.outboxRoleArn],
    ["serviceAccounts.runtimeCoordinator.roleArn", value.runtime.coordinatorRoleArn],
    ["serviceAccounts.runtimeArchive.roleArn", value.runtime.archiveRoleArn],
    ["serviceAccounts.runtimeIndex.roleArn", value.runtime.indexRoleArn],
    ["serviceAccounts.runtimeCorrelation.roleArn", value.runtime.correlationRoleArn],
    ["serviceAccounts.runtimeProjection.roleArn", value.runtime.projectionRoleArn],
    ["serviceAccounts.runtimeComplete.roleArn", value.runtime.completeRoleArn],
    ["serviceAccounts.canarySecretSync.roleArn", `arn:aws:iam::${platformAccountID}:role/zasp-production-canary-secret-sync`],
    ["ingress.host", value.host], ["ingress.tlsSecretName", value.tlsSecretName],
    ["secrets.providerClassName", value.secretProviderClass],
    ["secrets.apiPostgresDSNObjectName", "zasp/production/postgres-api-dsn"],
    ["secrets.securityAgentAPIPostgresDSNObjectName", "zasp/production/postgres-security-agent-api-dsn"],
    ["secrets.securityAgentWorkerPostgresDSNObjectName", "zasp/production/postgres-security-agent-worker-dsn"],
    ["secrets.securityAgentPlannerTokenObjectName", "zasp/production/openrouter-security-agent-api-key"],
    ["secrets.securityAgentActionPostgresDSNObjectName", "zasp/production/postgres-security-agent-action-worker-dsn"],
    ["secrets.policyDeploymentPostgresDSNObjectName", "zasp/production/postgres-policy-deployment-worker-dsn"],
    ["secrets.gatewaySigningPrivateKeyObjectName", "zasp/production/gateway-policy-signing-private-key"],
    ["secrets.workerPostgresDSNObjectName", "zasp/production/postgres-worker-dsn"],
    ["secrets.schedulerPostgresDSNObjectName", "zasp/production/postgres-scheduler-dsn"],
    ["secrets.projectionRiskPostgresDSNObjectName", "zasp/production/postgres-projection-risk-dsn"],
    ["secrets.projectionGraphPostgresDSNObjectName", "zasp/production/postgres-projection-graph-dsn"],
    ["secrets.projectionSearchPostgresDSNObjectName", "zasp/production/postgres-projection-search-dsn"],
    ["secrets.outboxPostgresDSNObjectName", "zasp/production/postgres-outbox-worker-dsn"],
    ["secrets.recoveryBackupOutboxPostgresDSNObjectName", "zasp/production/postgres-recovery-outbox-worker-dsn"],
    ["secrets.recoveryRestoreOutboxPostgresDSNObjectName", "zasp/production/postgres-recovery-outbox-worker-dsn"],
    ["secrets.recoveryBackupPostgresDSNObjectName", "zasp/production/postgres-recovery-worker-dsn"],
    ["secrets.recoveryRestorePostgresDSNObjectName", "zasp/production/postgres-recovery-worker-dsn"],
    ["secrets.redTeamOutboxPostgresDSNObjectName", "zasp/production/postgres-red-team-outbox-dsn"],
    ["secrets.redTeamWorkerPostgresDSNObjectName", "zasp/production/postgres-red-team-worker-dsn"],
    ["secrets.redTeamAdapterPostgresDSNObjectName", "zasp/production/postgres-red-team-adapter-dsn"],
    ["secrets.redTeamAdapterTokenObjectName", "zasp/production/red-team/adapter-token"],
    ["secrets.redTeamAdapterTLSCertificateObjectName", "zasp/production/red-team/adapter-tls-certificate"],
    ["secrets.redTeamAdapterTLSPrivateKeyObjectName", "zasp/production/red-team/adapter-tls-private-key"],
    ["secrets.attackLabControllerPostgresDSNObjectName", "zasp/production/postgres-attack-lab-controller-dsn"],
    ["secrets.attackLabOutboxPostgresDSNObjectName", "zasp/production/postgres-attack-lab-outbox-dsn"],
    ["secrets.attackLabProxyPostgresDSNObjectName", "zasp/production/postgres-attack-lab-proxy-dsn"],
    ["secrets.attackLabSigningKeyObjectName", "zasp/production/attack-lab/egress-signing-key"],
    ["secrets.attackLabProxyTLSCertificateObjectName", "zasp/production/attack-lab/proxy-tls-certificate"],
    ["secrets.attackLabProxyTLSPrivateKeyObjectName", "zasp/production/attack-lab/proxy-tls-private-key"],
    ["secrets.runtimeIngestPostgresDSNObjectName", "zasp/production/postgres-runtime-ingest-dsn"],
    ["secrets.runtimeCoordinatorPostgresDSNObjectName", "zasp/production/postgres-runtime-coordinator-dsn"],
    ["secrets.runtimeArchivePostgresDSNObjectName", "zasp/production/postgres-runtime-archive-dsn"],
    ["secrets.runtimeIndexPostgresDSNObjectName", "zasp/production/postgres-runtime-index-dsn"],
    ["secrets.runtimeCorrelationPostgresDSNObjectName", "zasp/production/postgres-runtime-correlation-dsn"],
    ["secrets.runtimeProjectionPostgresDSNObjectName", "zasp/production/postgres-runtime-projection-dsn"],
    ["secrets.gatewayControlPostgresDSNObjectName", "zasp/production/postgres-gateway-control-dsn"],
    ["secrets.migrationPostgresDSNObjectName", "zasp/production/postgres-migration-dsn"],
    ["secrets.stytchProjectIDObjectName", "zasp/production/stytch-project-id"],
    ["secrets.stytchSecretObjectName", "zasp/production/stytch-secret"],
    ["secrets.stytchWebhookSecretObjectName", "zasp/production/stytch-webhook-secret"],
    ["secrets.stytchPublicTokenObjectName", "zasp/production/stytch-public-token"],
    ["secrets.stytchOrganizationIDObjectName", "zasp/production/stytch-organization-id"],
    ["secrets.workflowSigningKeyObjectName", "zasp/production/workflow-signing-key"],
    ["secrets.tokenRevealKeyObjectName", "zasp/production/token-reveal-key"],
    ["secrets.canaryReadTokenObjectName", "zasp/production/canary-read-token"],
    ["databasePrincipals.migration", "zasp_migration"],
    ["databasePrincipals.api", "zasp_api_runtime"],
    ["databasePrincipals.securityAgentAPI", "zasp_security_agent_api_runtime"],
    ["databasePrincipals.securityAgentWorker", "zasp_security_agent_worker_runtime"],
    ["databasePrincipals.securityAgentActionWorker", "zasp_security_agent_action_worker_runtime"],
    ["databasePrincipals.policyDeploymentWorker", "zasp_policy_deployment_worker_runtime"],
    ["databasePrincipals.discoveryWorker", "zasp_discovery_runtime"],
    ["databasePrincipals.runtimeIngest", "zasp_ingest_runtime"],
    ["databasePrincipals.runtimeWorker", "zasp_runtime_worker_runtime"],
    ["databasePrincipals.outboxWorker", "zasp_outbox_runtime"],
    ["databasePrincipals.recoveryOutboxWorker", "zasp_recovery_outbox_runtime"],
    ["databasePrincipals.recoveryWorker", "zasp_recovery_runtime"],
    ["databasePrincipals.redTeamOutboxWorker", "zasp_red_team_outbox_runtime"],
    ["databasePrincipals.redTeamWorker", "zasp_red_team_worker_runtime"],
    ["databasePrincipals.redTeamAdapter", "zasp_red_team_adapter_runtime"],
    ["databasePrincipals.attackLabController", "zasp_attack_lab_controller_runtime"],
    ["databasePrincipals.attackLabOutbox", "zasp_attack_lab_outbox_runtime"],
    ["databasePrincipals.attackLabProxy", "zasp_attack_lab_proxy_runtime"],
    ["databasePrincipals.runtimeGateway", "zasp_gateway_runtime"],
    ["databasePrincipals.discoveryScheduler", "zasp_scheduler_runtime"],
    ["databasePrincipals.projectionRisk", "zasp_projection_risk_runtime"],
    ["databasePrincipals.projectionGraph", "zasp_projection_graph_runtime"],
    ["databasePrincipals.projectionSearch", "zasp_projection_search_runtime"],
    ["databasePrincipals.runtimeCoordinator", "zasp_runtime_coordinator_runtime"],
    ["databasePrincipals.runtimeArchive", "zasp_runtime_archive_runtime"],
    ["databasePrincipals.runtimeIndex", "zasp_runtime_index_runtime"],
    ["databasePrincipals.runtimeCorrelation", "zasp_runtime_correlation_runtime"],
    ["databasePrincipals.runtimeProjection", "zasp_runtime_projection_runtime"],
    ["databasePrincipals.gatewayControl", "zasp_gateway_control_runtime"],
    ["gatewayPolicy.signingKeyID", "gateway-key-01"],
    ["discovery.parserVersion", value.discovery.parserVersion],
    ["discovery.toolVersion", value.discovery.toolVersion],
    ["discovery.awsCollectorVersion", value.discovery.awsCollectorVersion],
    ["discovery.kubernetesCollectorVersion", value.discovery.kubernetesCollectorVersion],
    ["discovery.githubCollectorVersion", value.discovery.githubCollectorVersion],
    ["discovery.oktaCollectorVersion", value.discovery.oktaCollectorVersion],
    ["discovery.awsRegion", value.discovery.awsRegion],
    ["discovery.queueURL", value.discovery.queueURL],
    ["discovery.roleArn", value.discovery.roleArn],
    ["discovery.webIdentityTokenFile", value.discovery.webIdentityTokenFile],
    ["discovery.secretPrefix", value.discovery.secretPrefix],
    ["discovery.evidenceBucket", value.discovery.evidenceBucket],
    ["discovery.evidenceBucketOwner", value.discovery.evidenceBucketOwner],
    ["discovery.evidenceKMSKeyArn", value.discovery.evidenceKMSKeyArn],
    ["discovery.githubAppID", value.discovery.githubAppID],
    ["discovery.githubPrivateKeyReference", value.discovery.githubPrivateKeyReference],
    ["discovery.oktaClientID", value.discovery.oktaClientID],
    ["discovery.oktaClientSecretReference", value.discovery.oktaClientSecretReference],
    ["discovery.providerTimeout", value.discovery.providerTimeout],
    ["discovery.readinessTimeout", value.discovery.readinessTimeout],
    ["projectionRisk.roleArn", value.projectionRisk.roleArn],
    ["projectionGraph.awsRegion", value.projectionGraph.awsRegion],
    ["projectionGraph.endpoint", value.projectionGraph.endpoint],
    ["projectionGraph.credentialReference", value.projectionGraph.credentialReference],
    ["projectionGraph.schemaCredentialReference", value.projectionGraph.schemaCredentialReference],
    ["projectionGraph.secretPrefix", value.projectionGraph.secretPrefix],
    ["projectionGraph.roleArn", value.projectionGraph.roleArn],
    ["projectionGraph.webIdentityTokenFile", value.projectionGraph.webIdentityTokenFile],
    ["projectionGraph.initRoleArn", value.projectionGraph.initRoleArn],
    ["projectionGraph.expectedPrincipal", value.projectionGraph.expectedPrincipal],
    ["projectionGraph.expectedRole", value.projectionGraph.expectedRole],
    ["projectionSearch.awsRegion", value.projectionSearch.awsRegion],
    ["projectionSearch.endpoint", value.projectionSearch.endpoint],
    ["projectionSearch.index", value.projectionSearch.index],
    ["projectionSearch.roleArn", value.projectionSearch.roleArn],
    ["projectionSearch.webIdentityTokenFile", value.projectionSearch.webIdentityTokenFile],
    ["projectionSearch.initRoleArn", value.projectionSearch.initRoleArn],
    ["outbox.awsRegion", value.outbox.awsRegion],
    ["outbox.queueURL", value.outbox.queueURL],
    ["outbox.roleArn", value.outbox.roleArn],
    ["outbox.webIdentityTokenFile", value.outbox.webIdentityTokenFile],
    ...value.outbox.egressCIDRs.map((cidr, index) => [`network.outboxEgressCIDRs[${index}]`, cidr]),
    ["recovery.canaryEnabled", String(value.recovery.canaryEnabled)],
    ["recovery.awsRegion", value.recovery.awsRegion],
    ["recovery.backupQueueURL", value.recovery.backupQueueURL],
    ["recovery.restoreQueueURL", value.recovery.restoreQueueURL],
    ["recovery.evidenceBucket", value.recovery.evidenceBucket],
    ["recovery.evidenceBucketOwner", value.recovery.evidenceBucketOwner],
    ["recovery.evidenceKMSKeyArn", value.recovery.evidenceKMSKeyArn],
    ["recovery.signingKMSKeyArn", value.recovery.signingKMSKeyArn],
    ["recovery.backupOutboxRoleArn", value.recovery.backupOutboxRoleArn],
    ["recovery.restoreOutboxRoleArn", value.recovery.restoreOutboxRoleArn],
    ["recovery.backupRoleArn", value.recovery.backupRoleArn],
    ["recovery.restoreRoleArn", value.recovery.restoreRoleArn],
    ["recovery.webIdentityTokenFile", value.recovery.webIdentityTokenFile],
    ["recovery.neonProjectID", value.recovery.neonProjectID],
    ["recovery.neonBranchID", value.recovery.neonBranchID],
    ["recovery.neonSecretReference", value.recovery.neonSecretReference],
    ["recovery.kubernetesEndpoint", value.recovery.kubernetesEndpoint],
    ["recovery.runnerImage", value.recovery.runnerImage],
    ["recovery.runnerServiceAccount", value.recovery.runnerServiceAccount],
    ...value.recovery.egressCIDRs.map((cidr, index) => [`network.recoveryEgressCIDRs[${index}]`, cidr]),
    ...value.recovery.neonEgressCIDRs.map((cidr, index) => [`recovery.neonEgressCIDRs[${index}]`, cidr]),
    ...value.recovery.kubernetesAPICIDRs.map((cidr, index) => [`network.recoveryKubernetesAPICIDRs[${index}]`, cidr]),
    ["redTeam.awsRegion", value.redTeam.awsRegion],
    ["redTeam.queueURL", value.redTeam.queueURL],
    ["redTeam.evidenceBucket", value.redTeam.evidenceBucket],
    ["redTeam.evidenceBucketOwner", value.redTeam.evidenceBucketOwner],
    ["redTeam.evidenceKMSKeyArn", value.redTeam.evidenceKMSKeyArn],
    ["redTeam.outboxRoleArn", value.redTeam.outboxRoleArn],
    ["redTeam.workerRoleArn", value.redTeam.workerRoleArn],
    ["redTeam.adapterRoleArn", value.redTeam.adapterRoleArn],
    ["redTeam.webIdentityTokenFile", value.redTeam.webIdentityTokenFile],
    ["redTeam.runnerTimeout", value.redTeam.runnerTimeout],
    ["redTeam.targetEndpoint", value.redTeam.targetEndpoint],
    ["redTeam.readinessCredentialReference", value.redTeam.readinessCredentialReference],
    ...value.redTeam.targetAllowedCIDRs.map((cidr, index) => [`redTeam.targetAllowedCIDRs[${index}]`, cidr]),
    ...value.redTeam.egressCIDRs.map((cidr, index) => [`network.redTeamEgressCIDRs[${index}]`, cidr]),
    ["attackLab.awsRegion", value.attackLab.awsRegion],
    ["attackLab.queueURL", value.attackLab.queueURL],
    ["attackLab.evidenceBucket", value.attackLab.evidenceBucket],
    ["attackLab.evidenceBucketOwner", value.attackLab.evidenceBucketOwner],
    ["attackLab.evidenceKMSKeyArn", value.attackLab.evidenceKMSKeyArn],
    ["attackLab.controllerRoleArn", value.attackLab.controllerRoleArn],
    ["attackLab.runnerTestRoleArn", value.attackLab.runnerTestRoleArn],
    ["attackLab.outboxRoleArn", value.attackLab.outboxRoleArn],
    ["attackLab.proxyRoleArn", value.attackLab.proxyRoleArn],
    ["attackLab.webIdentityTokenFile", value.attackLab.webIdentityTokenFile],
    ["attackLab.securityGroupID", value.attackLab.securityGroupID],
    ["attackLab.proxySecurityGroupID", value.attackLab.proxySecurityGroupID],
    ["attackLab.readinessCredentialReference", value.attackLab.readinessCredentialReference],
    ["attackLab.operationTimeout", value.attackLab.operationTimeout],
    ["attackLab.proxyRequestTimeout", value.attackLab.proxyRequestTimeout],
    ["attackLab.proxyShutdownTimeout", value.attackLab.proxyShutdownTimeout],
    ["attackLab.proxyCABundleBase64", value.attackLab.proxyCABundleBase64],
    ...value.attackLab.targetAllowedCIDRs.map((cidr, index) => [`attackLab.targetAllowedCIDRs[${index}]`, cidr]),
    ...value.attackLab.egressCIDRs.map((cidr, index) => [`network.attackLabEgressCIDRs[${index}]`, cidr]),
    ...value.attackLab.kubernetesAPICIDRs.map((cidr, index) => [`network.attackLabKubernetesAPICIDRs[${index}]`, cidr]),
    ["runtime.awsRegion", value.runtime.awsRegion],
    ["runtime.queueURL", value.runtime.queueURL],
    ["runtime.rawBucket", value.runtime.rawBucket],
    ["runtime.rawBucketOwner", value.runtime.rawBucketOwner],
    ["runtime.rawKMSKeyArn", value.runtime.rawKMSKeyArn],
    ["runtime.openSearchEndpoint", value.runtime.openSearchEndpoint],
    ["runtime.openSearchIndex", value.runtime.openSearchIndex],
    ["runtime.webIdentityTokenFile", value.runtime.webIdentityTokenFile],
    ["runtime.eventIngestRoleArn", value.runtime.eventIngestRoleArn],
    ["runtime.gatewayControlRoleArn", value.runtime.gatewayControlRoleArn],
    ["runtime.outboxRoleArn", value.runtime.outboxRoleArn],
    ["runtime.coordinatorRoleArn", value.runtime.coordinatorRoleArn],
    ["runtime.archiveRoleArn", value.runtime.archiveRoleArn],
    ["runtime.indexRoleArn", value.runtime.indexRoleArn],
    ["runtime.correlationRoleArn", value.runtime.correlationRoleArn],
    ["runtime.projectionRoleArn", value.runtime.projectionRoleArn],
    ["runtime.completeRoleArn", value.runtime.completeRoleArn],
    ...value.runtime.egressCIDRs.map((cidr, index) => [`network.runtimeEgressCIDRs[${index}]`, cidr]),
    ["network.postgresCIDR", "10.30.0.0/24"], ["network.stytchCIDR", "10.40.0.0/24"], ["network.opensearchCIDR", "10.50.0.0/24"],
    ["network.neo4jCIDR", value.projectionGraph.endpointCIDR],
    ["network.canaryCIDR", "10.60.0.0/24"],
    ["connectors.awsRegion", value.connectors.awsRegion],
    ["connectors.roleArn", value.connectors.roleArn],
    ["connectors.webIdentityTokenFile", value.connectors.webIdentityTokenFile],
    ["connectors.kmsKeyArn", value.connectors.kmsKeyArn],
    ["connectors.secretPrefix", value.connectors.secretPrefix],
    ["connectors.githubClientID", value.connectors.githubClientID],
    ["connectors.githubClientSecretReference", value.connectors.githubClientSecretReference],
    ["connectors.githubAppID", value.connectors.githubAppID],
    ["connectors.githubPrivateKeyReference", value.connectors.githubPrivateKeyReference],
    ["connectors.oktaClientID", value.connectors.oktaClientID],
    ["connectors.oktaClientSecretReference", value.connectors.oktaClientSecretReference],
    ...value.connectors.awsCustomerRolePrefixes.map((prefix, index) => [`connectors.awsCustomerRolePrefixes[${index}]`, prefix]),
    ...value.connectors.awsCustomerRoleARNs.map((roleARN, index) => [`connectors.awsCustomerRoleARNs[${index}]`, roleARN]),
    ...connectorEgressKeys.flatMap((provider) => value.connectorEgressCIDRs[provider].map((cidr, index) => [`network.connectorEgressCIDRs.${provider}[${index}]`, cidr])),
    ...value.findingTicketEgressCIDRs.map((cidr, index) => [`network.findingTicketEgressCIDRs[${index}]`, cidr]),
    ...value.securityAgentPlanner.egressCIDRs.map((cidr, index) => [`network.securityAgentPlannerEgressCIDRs[${index}]`, cidr]),
    ["nango.storageSecretName", value.nango.storageSecretName],
    ...value.nango.databaseEgressCIDRs.map((cidr, index) => [`nango.databaseEgressCIDRs[${index}]`, cidr]),
    ...value.nango.providerEgressCIDRs.map((cidr, index) => [`nango.providerEgressCIDRs[${index}]`, cidr]),
    ["telemetry.backend", value.telemetry.backend],
    ["telemetry.endpoint", value.telemetry.endpoint],
    ["telemetry.authSecretName", value.telemetry.authSecretName],
    ...value.telemetry.egressCIDRs.map((cidr, index) => [`telemetry.egressCIDRs[${index}]`, cidr]),
    ...imageNames.map((name) => [`global.productImages.${name}`, value.images[name]]),
  ];
  if (authorizationTemporal) set.push(
    ["serviceAccounts.securityAgent.roleArn", authorizationTemporal.workerRoleArn],
    ["serviceAccounts.redTeamAdapter.roleArn", authorizationTemporal.adapterRoleArn],
    ["redTeam.adapterRoleArn", authorizationTemporal.adapterRoleArn],
    ["databasePrincipals.redTeamAdapter", authorizationTemporal.adapterPrincipal],
    ["databasePrincipals.outboxWorker", authorizationTemporal.projectorPrincipal],
  );
  // The named profile consumes the exact Secrets Manager objects provisioned
  // by the production Terraform cluster, including its flat secret names.
  if (authorizationTemporal) for (const entry of set) {
    if (entry[0].startsWith("secrets.") && entry[0].endsWith("ObjectName") && entry[1].startsWith("zasp/production/")) entry[1] = "zasp-production/" + entry[1].slice("zasp/production/".length).replaceAll("/", "-");
  }
  const chart = path.join(root, "deploy/staging/product");
  const valueArgs = [];
  for (const [key, entry] of set) valueArgs.push("--set-string", `${key}=${entry.replaceAll("\\", "\\\\").replaceAll(",", "\\,")}`);
  let stdout;
  let exportValuesDirectory;
  try {
    if (auditExports || testReconciler || complianceExports || attackLabReconciler || options.runtimeServices || optionalEgress || retention || environmentClass || agentOwnerFilter || agentRead || agentOwnershipWrite || agentExposureFilter || sensorNodeCoverage || gatewayInstallation || gatewayBootstrap) {
      // A complete policy history can exceed the per-argument limit on Linux.
      exportValuesDirectory = await mkdtemp(path.join(tmpdir(), "zasp-audit-export-values-"));
      const exportValuesPath = path.join(exportValuesDirectory, "values.json");
      await writeFile(exportValuesPath, JSON.stringify({ auditExports, testReconciler, complianceExports, attackLabReconciler, ...(authorizationTemporal ? { authorizationTemporal } : {}), ...(optionalEgress ? { optionalEgress } : {}), ...(retention ? { retentionReferenceExpiry: retention } : {}), ...(environmentClass ? { environmentClass } : {}), ...(agentOwnerFilter ? { agentOwnerFilter } : {}), ...(agentRead ? { agentRead } : {}), ...(sensorNodeCoverage ? { sensorNodeCoverage } : {}), ...(gatewayInstallation ? { gatewayInstallation } : {}), ...(gatewayBootstrap ? { gatewayBootstrap } : {}), ...(agentOwnershipWrite ? { agentOwnershipWrite } : {}), ...(agentExposureFilter ? { agentExposureFilter } : {}), ...(runtimeServices ? { runtimeServices } : {}), ...(evidenceExportWorkflow ? { evidenceExportWorkflow: { enabled: true } } : {}) }), { mode: 0o600 });
      valueArgs.push("--values", exportValuesPath);
    }
    await exec("helm", ["lint", chart, "--namespace", "agentsec", ...valueArgs], { cwd: root, encoding: "utf8", maxBuffer: 4 * 1024 * 1024 });
    ({ stdout } = await exec("helm", ["template", "zasp", chart, "--namespace", "agentsec", ...valueArgs], { cwd: root, encoding: "utf8", maxBuffer: 4 * 1024 * 1024 }));
  } catch {
    throw new Error("release rejected");
  } finally {
    if (exportValuesDirectory) await rm(exportValuesDirectory, { recursive: true, force: true });
  }
  const resources = [];
  try {
    loadAll(stdout, (document) => { if (document) resources.push(document); }, { schema: JSON_SCHEMA });
  } catch {
    throw new Error("release rejected");
  }
  if (resources.length < 20 || resources.some((resource) => !resource?.apiVersion || !resource?.kind || !resource?.metadata?.name)) throw new Error("release rejected");
  validateRenderedRelease(resources, platformAccountID, schemaVersion, sessionSearchPhase, auditExports, testReconciler, complianceExports, attackLabReconciler, evidenceExportWorkflow, discoveryScheduleReplayPhase, authorizationTemporal, optionalEgress, value.securityAgentPlanner.egressCIDRs, retention, environmentClass, agentOwnerFilter, agentRead, agentExposureFilter, agentOwnershipWrite, sensorNodeCoverage, gatewayInstallation, gatewayBootstrap);
  return Object.freeze(resources);
}

export async function renderCustomerEdgeRelease(value, options = {}) {
  if (!validCustomerEdgeRelease(value) || !options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some(key => key !== "sourceProfile") || options.sourceProfile !== undefined && !["tetragon-local-stream-v2", "tetragon-local-stream-v3"].includes(options.sourceProfile)) throw new Error("edge release rejected");
  const sourceProfile = options.sourceProfile ?? "tetragon-local-stream-v2";
  const nodeCoverage = normalizeSensorNodeCoverageProducer(value.sensorNodeCoverage);
  const gatewayInstallation = normalizeGatewayInstallationProducer(value.gatewayInstallation);
  const set = [
    ["sensorAgent.sourceProfile", sourceProfile],
    ["global.productImages.runtimeGateway", value.image],
    ["global.productImages.sensorAgent", value.sensorImage],
    ["runtimeGateway.controlPlaneURL", value.controlPlaneURL],
    ["runtimeGateway.organizationID", value.organizationID],
    ["runtimeGateway.workspaceID", value.workspaceID],
    ["runtimeGateway.environmentID", value.environmentID],
    ["runtimeGateway.deviceID", value.deviceID],
    ["runtimeGateway.credentialID", value.credentialID],
    ["runtimeGateway.credentialSecretName", value.credentialSecretName],
    ["runtimeGateway.policyKeysSecretName", value.policyKeysSecretName],
    ["runtimeGateway.proxyClientTokenSecretName", value.proxyClientTokenSecretName],
    ["runtimeGateway.proxyUpstreamURL", value.proxyUpstreamURL],
    ["runtimeGateway.policyCache.storageClassName", value.storageClassName],
    ["sensorAgent.tokenSecretName", value.sensorTokenSecretName],
    ["sensorAgent.enrollmentBinding", value.sensorEnrollmentBinding],
    ["sensorAgent.stateHostPath", value.stateHostPath],
    ...value.controlPlaneCIDRs.map((cidr, index) => [`network.controlPlaneCIDRs[${index}]`, cidr]),
    ...value.proxyAllowedCIDRs.map((cidr, index) => [`runtimeGateway.proxyAllowedCIDRs[${index}]`, cidr]),
    ...value.kubernetesAPICIDRs.map((cidr, index) => [`network.kubernetesAPICIDRs[${index}]`, cidr]),
    ...value.nodeCIDRs.map((cidr, index) => [`network.nodeCIDRs[${index}]`, cidr]),
  ];
  const chart = path.join(root, "deploy/staging/product");
  const edgeValues = path.join(chart, "values-customer-edge.yaml");
  const valueArgs = [];
  for (const [key, entry] of set) valueArgs.push("--set-string", `${key}=${entry.replaceAll("\\", "\\\\").replaceAll(",", "\\,")}`);
  let productOutput, tetragonOutput, coverageDirectory;
  const nodeSelector = structuredClone(value.sensorNodeSelector);
  try {
    const tetragonChart = path.join(root, "deploy/staging/tetragon");
    const dependency = await readFile(path.join(tetragonChart, "charts/tetragon-1.7.0.tgz"));
    if (createHash("sha256").update(dependency).digest("hex") !== tetragonChartDigest) throw new Error("tetragon dependency rejected");
    coverageDirectory = await mkdtemp(path.join(tmpdir(), "zasp-sensor-coverage-values-"));
    const productCoveragePath = path.join(coverageDirectory,"product.json"), tetragonCoveragePath = path.join(coverageDirectory,"tetragon.json");
    await writeFile(productCoveragePath,JSON.stringify({runtimeGateway:{installationACKEnabled:gatewayInstallation?.enabled===true},sensorAgent:{nodeCoverageRetentionEnabled:nodeCoverage?.enabled===true,sensorID:nodeCoverage?.sensorID??"",coverage:{clusterUID:value.sensorClusterUID,matchLabels:nodeSelector,tetragonNamespace:"agentsec",tetragonName:"zasp-tetragon",tetragonRelease:"zasp-tetragon",tetragonServiceAccount:"zasp-tetragon"}}}),{mode:0o600});
    await writeFile(tetragonCoveragePath,JSON.stringify({tetragon:{nodeSelector},coverageObserver:{enabled:true,namespace:"agentsec",serviceAccount:"sensor-agent"}}),{mode:0o600});
    valueArgs.push("--values",productCoveragePath);
    const tetragonArgs=["--values",tetragonCoveragePath];
    const results = await Promise.all([
      exec("helm", ["lint", chart, "--namespace", "agentsec", "--values", edgeValues, ...valueArgs], { cwd: root, encoding: "utf8", maxBuffer: 8 * 1024 * 1024 }),
      exec("helm", ["template", "zasp", chart, "--namespace", "agentsec", "--values", edgeValues, ...valueArgs], { cwd: root, encoding: "utf8", maxBuffer: 8 * 1024 * 1024 }),
      exec("helm", ["lint", tetragonChart, "--namespace", "agentsec", ...tetragonArgs], { cwd: root, encoding: "utf8", maxBuffer: 8 * 1024 * 1024 }),
      exec("helm", ["template", "zasp-tetragon", tetragonChart, "--namespace", "agentsec", ...tetragonArgs], { cwd: root, encoding: "utf8", maxBuffer: 8 * 1024 * 1024 }),
    ]);
    productOutput = results[1].stdout;
    tetragonOutput = results[3].stdout;
  } catch {
    throw new Error("edge release rejected");
  } finally {
    if (coverageDirectory) await rm(coverageDirectory,{recursive:true,force:true});
  }
  const resources = [];
  try {
    loadAll(productOutput, (document) => { if (document) resources.push(document); }, { schema: JSON_SCHEMA });
    loadAll(tetragonOutput, (document) => { if (document) resources.push(document); }, { schema: JSON_SCHEMA });
  } catch {
    throw new Error("edge release rejected");
  }
  validateSensorNodeCoverageProducerResources(resources,nodeCoverage);
  validateGatewayInstallationProducerResources(resources,gatewayInstallation);
  const deployments = resources.filter(({ kind }) => kind === "Deployment");
  const daemonSets = resources.filter(({ kind }) => kind === "DaemonSet");
  const accounts = resources.filter(({ kind }) => kind === "ServiceAccount");
  if (resources.length < 20 || resources.some((resource) => !resource?.apiVersion || !resource?.kind || !resource?.metadata?.name) || deployments.length !== 1 || deployments[0].metadata.name !== "runtime-gateway" || daemonSets.length !== 2 || !daemonSets.some(({ metadata }) => metadata.name === "sensor-agent") || !daemonSets.some(({ metadata }) => metadata.name === "zasp-tetragon") || accounts.length !== 3 || !["runtime-gateway", "sensor-agent", "zasp-tetragon"].every((name) => accounts.some(({ metadata }) => metadata.name === name)) || accounts.some(({ metadata }) => metadata.annotations?.["eks.amazonaws.com/role-arn"] !== undefined)) throw new Error("edge release rejected");
  const sensorDS=resources.find(r=>r.kind==="DaemonSet"&&r.metadata.name==="sensor-agent"), tetragonDS=resources.find(r=>r.kind==="DaemonSet"&&r.metadata.name==="zasp-tetragon");
  const normalize=v=>JSON.stringify(Object.fromEntries(Object.entries(v??{}).sort(([a],[b])=>a.localeCompare(b))));
  if(normalize(sensorDS?.spec?.template?.spec?.nodeSelector)!==normalize(nodeSelector)||normalize(tetragonDS?.spec?.template?.spec?.nodeSelector)!==normalize(nodeSelector)) throw new Error("edge release rejected");
  const role=resources.find(r=>r.kind==="Role"&&r.metadata.name==="sensor-agent");
  const dsRule=role?.rules?.find(r=>r.apiGroups?.includes("apps")&&r.resources?.includes("daemonsets"));
  if(!dsRule||JSON.stringify(dsRule.verbs)!==JSON.stringify(["get"])||normalize(dsRule.resourceNames)!==normalize(["sensor-agent","zasp-tetragon"])) throw new Error("edge release rejected");
  return Object.freeze(resources);
}

function validCustomerEdgeRelease(value) {
  const keys = ["controlPlaneURL", "image", "sensorImage", "organizationID", "workspaceID", "environmentID", "deviceID", "credentialID", "credentialSecretName", "policyKeysSecretName", "proxyClientTokenSecretName", "proxyUpstreamURL", "sensorTokenSecretName", "sensorEnrollmentBinding", "sensorClusterUID", "sensorNodeSelector", "storageClassName", "controlPlaneCIDRs", "proxyAllowedCIDRs", "kubernetesAPICIDRs", "nodeCIDRs", "stateHostPath"];
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).filter(key=>!["sensorNodeCoverage","gatewayInstallation"].includes(key)).sort().join("\0") !== keys.sort().join("\0") || !digestPattern.test(value.image) || !digestPattern.test(value.sensorImage) || value.image === value.sensorImage) return false;
  try { normalizeSensorNodeCoverageProducer(value.sensorNodeCoverage); normalizeGatewayInstallationProducer(value.gatewayInstallation); } catch { return false; }
  if (typeof value.sensorClusterUID !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value.sensorClusterUID) || value.sensorClusterUID === "00000000-0000-0000-0000-000000000000" || !value.sensorNodeSelector || Array.isArray(value.sensorNodeSelector) || Object.keys(value.sensorNodeSelector).length < 1 || Object.keys(value.sensorNodeSelector).length > 8 || !Object.entries(value.sensorNodeSelector).every(([k,v]) => /^[A-Za-z0-9./_-]{1,253}$/.test(k) && typeof v === "string" && /^[A-Za-z0-9][A-Za-z0-9_.-]{0,62}$/.test(v))) return false;
  if (typeof value.sensorEnrollmentBinding !== "string" || !/^[0-9a-f]{64}$/.test(value.sensorEnrollmentBinding)) return false;
  if (!/^https:\/\/(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(value.controlPlaneURL)) return false;
  if (![value.organizationID, value.workspaceID, value.environmentID, value.deviceID, value.credentialID].every((identifier) => productIDPattern.test(identifier)) || new Set([value.organizationID, value.workspaceID, value.environmentID, value.deviceID, value.credentialID]).size !== 5) return false;
  let proxy;
  try { proxy = new URL(value.proxyUpstreamURL); } catch { return false; }
  if (proxy.href !== value.proxyUpstreamURL || proxy.protocol !== "https:" || !hostPattern.test(proxy.hostname) || proxy.username !== "" || proxy.password !== "" || proxy.port !== "" || proxy.pathname === "/" || proxy.search !== "" || proxy.hash !== "") return false;
  const secretNames = [value.credentialSecretName, value.policyKeysSecretName, value.proxyClientTokenSecretName, value.sensorTokenSecretName];
  return secretNames.every((name) => namePattern.test(name)) && new Set(secretNames).size === secretNames.length && namePattern.test(value.storageClassName) && value.stateHostPath === "/var/lib/zasp-sensor-lineage" && validCIDRList(value.controlPlaneCIDRs) && validGatewayProxyCIDRList(value.proxyAllowedCIDRs) && validCIDRList(value.kubernetesAPICIDRs) && validCIDRList(value.nodeCIDRs);
}

function validRelease(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).sort().join("\0") !== ["attackLab", "awsS3CIDRs", "connectorEgressCIDRs", "connectors", "discovery", "findingTicketEgressCIDRs", "securityAgentPlanner", "projectionGraph", "projectionRisk", "projectionSearch", "outbox", "recovery", "redTeam", "runtime", "nango", "telemetry", "host", "images", "secretProviderClass", "tlsSecretName"].sort().join("\0")) return false;
  if (!hostPattern.test(value.host) || !namePattern.test(value.tlsSecretName) || !namePattern.test(value.secretProviderClass)) return false;
  if (!validS3CIDRList(value.awsS3CIDRs)) return false;
  if (!value.images || typeof value.images !== "object" || Array.isArray(value.images) || Object.keys(value.images).sort().join("\0") !== [...imageNames].sort().join("\0")) return false;
  if (!imageNames.every((name) => digestPattern.test(value.images[name]))) return false;
  if (!value.discovery || typeof value.discovery !== "object" || Array.isArray(value.discovery) || Object.keys(value.discovery).sort().join("\0") !== [...discoveryKeys].sort().join("\0")) return false;
  for (const name of ["parserVersion", "toolVersion", "awsCollectorVersion", "kubernetesCollectorVersion", "githubCollectorVersion", "oktaCollectorVersion"]) {
    if (!/^[a-z][a-z0-9_.-]{1,63}$/.test(value.discovery[name]) || value.discovery[name] === "parser-v1" || value.discovery[name] === "tool-v1") return false;
  }
  const discoveryRole = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-discovery-worker$/.exec(value.discovery.roleArn);
  const discoveryQueue = /^https:\/\/sqs\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/([0-9]{12})\/agentsec-discovery-jobs$/.exec(value.discovery.queueURL);
  const discoveryKMS = /^arn:aws:kms:([a-z]{2}(?:-gov)?-[a-z]+-[0-9]):([0-9]{12}):key\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.exec(value.discovery.evidenceKMSKeyArn);
  if (!discoveryRole || !discoveryQueue || !discoveryKMS || value.discovery.awsRegion !== discoveryQueue[1] || value.discovery.awsRegion !== discoveryKMS[1] || discoveryRole[1] !== discoveryQueue[2] || discoveryRole[1] !== discoveryKMS[2] || discoveryRole[1] !== value.discovery.evidenceBucketOwner) return false;
  if (!namePattern.test(value.discovery.evidenceBucket) || value.discovery.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token" || value.discovery.secretPrefix !== "zasp-production/connectors" || value.discovery.providerTimeout !== "5s" || value.discovery.readinessTimeout !== "5s") return false;
  if (!value.projectionSearch || typeof value.projectionSearch !== "object" || Array.isArray(value.projectionSearch) || Object.keys(value.projectionSearch).sort().join("\0") !== [...projectionSearchKeys].sort().join("\0")) return false;
  const searchRole = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-projection-search$/.exec(value.projectionSearch.roleArn);
  const searchInitRole = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-projection-search-init$/.exec(value.projectionSearch.initRoleArn);
  const searchEndpoint = /^https:\/\/(?:search|vpc)-[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.es\.amazonaws\.com$/.exec(value.projectionSearch.endpoint);
  if (!searchRole || !searchInitRole || searchRole[1] !== searchInitRole[1] || searchRole[1] !== discoveryRole[1] || !searchEndpoint || value.projectionSearch.awsRegion !== searchEndpoint[1] || value.projectionSearch.index !== "zasp-inventory-v1" || value.projectionSearch.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token") return false;
  if (!value.projectionRisk || typeof value.projectionRisk !== "object" || Array.isArray(value.projectionRisk) || Object.keys(value.projectionRisk).sort().join("\0") !== [...projectionRiskKeys].sort().join("\0")) return false;
  const riskRole = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-projection-risk$/.exec(value.projectionRisk.roleArn);
  if (!riskRole || riskRole[1] !== searchRole[1]) return false;
  if (!value.projectionGraph || typeof value.projectionGraph !== "object" || Array.isArray(value.projectionGraph) || Object.keys(value.projectionGraph).sort().join("\0") !== [...projectionGraphKeys].sort().join("\0")) return false;
  const graphRole = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-projection-graph$/.exec(value.projectionGraph.roleArn);
  const graphInitRole = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-projection-graph-init$/.exec(value.projectionGraph.initRoleArn);
  const graphEndpoint = /^neo4j\+s:\/\/[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9]):7687$/.exec(value.projectionGraph.endpoint);
  if (!graphRole || !graphInitRole || !graphEndpoint || graphRole[1] !== graphInitRole[1] || graphRole[1] !== searchRole[1]) return false;
  if (value.projectionGraph.awsRegion !== value.projectionSearch.awsRegion || value.projectionGraph.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token" || value.projectionGraph.secretPrefix !== "zasp-production/projection" || value.projectionGraph.credentialReference !== "ref:neo4j/auth/runtime" || value.projectionGraph.schemaCredentialReference !== "ref:neo4j/auth/schema" || value.projectionGraph.expectedPrincipal !== "zasp_projection_runtime" || value.projectionGraph.expectedRole !== "publisher" || !validCIDRList([value.projectionGraph.endpointCIDR])) return false;
  if (!value.outbox || typeof value.outbox !== "object" || Array.isArray(value.outbox) || Object.keys(value.outbox).sort().join("\0") !== [...outboxKeys].sort().join("\0")) return false;
  const outboxRole = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-outbox$/.exec(value.outbox.roleArn);
  const outboxQueue = /^https:\/\/sqs\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/([0-9]{12})\/agentsec-discovery-jobs$/.exec(value.outbox.queueURL);
  if (!outboxRole || !outboxQueue || value.outbox.awsRegion !== outboxQueue[1] || outboxRole[1] !== outboxQueue[2] || outboxRole[1] !== discoveryRole[1] || value.outbox.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token" || !validCIDRList(value.outbox.egressCIDRs)) return false;
  if (!value.recovery || typeof value.recovery !== "object" || Array.isArray(value.recovery) || Object.keys(value.recovery).sort().join("\0") !== [...recoveryKeys].sort().join("\0") || value.recovery.canaryEnabled !== true) return false;
  const recoveryBackupQueue = /^https:\/\/sqs\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/([0-9]{12})\/agentsec-recovery-backup-jobs$/.exec(value.recovery.backupQueueURL);
  const recoveryRestoreQueue = /^https:\/\/sqs\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/([0-9]{12})\/agentsec-recovery-restore-jobs$/.exec(value.recovery.restoreQueueURL);
  const recoveryEncryption = /^arn:aws:kms:([a-z]{2}(?:-gov)?-[a-z]+-[0-9]):([0-9]{12}):key\/[0-9a-f-]{36}$/.exec(value.recovery.evidenceKMSKeyArn);
  const recoverySigning = /^arn:aws:kms:([a-z]{2}(?:-gov)?-[a-z]+-[0-9]):([0-9]{12}):key\/[0-9a-f-]{36}$/.exec(value.recovery.signingKMSKeyArn);
  const recoveryRoles = ["backupOutbox", "restoreOutbox", "backup", "restore"].map((name) => new RegExp(`^arn:aws:iam::([0-9]{12}):role/zasp-production-recovery-${name.replace(/[A-Z]/g, (character) => `-${character.toLowerCase()}`)}$`).exec(value.recovery[`${name}RoleArn`]));
  const recoveryRunner = /^([0-9]{12})\.dkr\.ecr\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/zasp\/agentsec-worker@sha256:[0-9a-f]{64}$/.exec(value.recovery.runnerImage);
  if (!recoveryBackupQueue || !recoveryRestoreQueue || !recoveryEncryption || !recoverySigning || !recoveryRunner || recoveryRoles.some((role) => !role) || recoveryRoles.some((role) => role[1] !== discoveryRole[1])) return false;
  if (value.recovery.awsRegion !== recoveryBackupQueue[1] || value.recovery.awsRegion !== recoveryRestoreQueue[1] || value.recovery.awsRegion !== recoveryEncryption[1] || value.recovery.awsRegion !== recoverySigning[1] || value.recovery.awsRegion !== recoveryRunner[2] || recoveryBackupQueue[2] !== discoveryRole[1] || recoveryRestoreQueue[2] !== discoveryRole[1] || recoveryEncryption[2] !== discoveryRole[1] || recoverySigning[2] !== discoveryRole[1] || recoveryRunner[1] !== discoveryRole[1] || value.recovery.evidenceBucketOwner !== discoveryRole[1]) return false;
  if (value.recovery.evidenceBucket !== value.discovery.evidenceBucket || value.recovery.evidenceKMSKeyArn !== value.discovery.evidenceKMSKeyArn || value.recovery.signingKMSKeyArn === value.recovery.evidenceKMSKeyArn || value.recovery.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token" || value.recovery.neonSecretReference !== "ref:neon/project-api-key" || value.recovery.kubernetesEndpoint !== "https://kubernetes.default.svc" || value.recovery.runnerServiceAccount !== "agentsec-recovery-runner") return false;
  if (!/^[a-z][a-z0-9-]{2,62}$/.test(value.recovery.neonProjectID) || !/^br-[a-z0-9][a-z0-9-]{1,62}$/.test(value.recovery.neonBranchID) || !validPrivateCIDRList(value.recovery.egressCIDRs) || !validProviderCIDRList(value.recovery.neonEgressCIDRs) || !validPrivateCIDRList(value.recovery.kubernetesAPICIDRs) || hasCIDROverlap([...value.recovery.egressCIDRs, ...value.recovery.neonEgressCIDRs, ...value.recovery.kubernetesAPICIDRs])) return false;
  if (!value.redTeam || typeof value.redTeam !== "object" || Array.isArray(value.redTeam) || Object.keys(value.redTeam).sort().join("\0") !== [...redTeamKeys].sort().join("\0")) return false;
  const redTeamQueue = /^https:\/\/sqs\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/([0-9]{12})\/agentsec-red-team-tests$/.exec(value.redTeam.queueURL);
  const redTeamKMS = /^arn:aws:kms:([a-z]{2}(?:-gov)?-[a-z]+-[0-9]):([0-9]{12}):key\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.exec(value.redTeam.evidenceKMSKeyArn);
  const redTeamRoles = ["outbox", "worker", "adapter"].map((name) => new RegExp(`^arn:aws:iam::([0-9]{12}):role/zasp-production-red-team-${name}$`).exec(value.redTeam[`${name}RoleArn`]));
  if (!redTeamQueue || !redTeamKMS || redTeamRoles.some((role) => !role) || redTeamRoles.some((role) => role[1] !== discoveryRole[1]) || redTeamQueue[2] !== discoveryRole[1] || redTeamKMS[2] !== discoveryRole[1]) return false;
  if (value.redTeam.awsRegion !== redTeamQueue[1] || value.redTeam.awsRegion !== redTeamKMS[1] || value.redTeam.evidenceBucketOwner !== discoveryRole[1] || !namePattern.test(value.redTeam.evidenceBucket) || value.redTeam.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token" || value.redTeam.runnerTimeout !== "10m") return false;
  if (value.redTeam.targetEndpoint !== "https://agentsec-red-team-adapter.agentsec.svc.cluster.local/v1/evaluate" || value.redTeam.readinessCredentialReference !== "ref:red-team/readiness-0001" || !validProviderCIDRList(value.redTeam.targetAllowedCIDRs) || !validPrivateCIDRList(value.redTeam.egressCIDRs)) return false;
  if (!value.attackLab || typeof value.attackLab !== "object" || Array.isArray(value.attackLab) || Object.keys(value.attackLab).sort().join("\0") !== [...attackLabKeys].sort().join("\0")) return false;
  const attackLabQueue = /^https:\/\/sqs\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/([0-9]{12})\/agentsec-attack-lab-jobs$/.exec(value.attackLab.queueURL);
  const attackLabKMS = /^arn:aws:kms:([a-z]{2}(?:-gov)?-[a-z]+-[0-9]):([0-9]{12}):key\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.exec(value.attackLab.evidenceKMSKeyArn);
  const attackLabRoles = ["controller", "outbox", "proxy", "runner-test"].map((name) => new RegExp(`^arn:aws:iam::([0-9]{12}):role/zasp-production-attack-lab-${name}$`).exec(value.attackLab[name === "runner-test" ? "runnerTestRoleArn" : `${name}RoleArn`]));
  const attackLabRunnerImage = /^([0-9]{12})\.dkr\.ecr\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/zasp\/attack-lab-runner@sha256:[0-9a-f]{64}$/.exec(value.images.attackLabRunner);
  if (!attackLabQueue || !attackLabKMS || !attackLabRunnerImage || attackLabRoles.some((role) => !role) || attackLabRoles.some((role) => role[1] !== discoveryRole[1]) || attackLabQueue[2] !== discoveryRole[1] || attackLabKMS[2] !== discoveryRole[1] || attackLabRunnerImage[1] !== discoveryRole[1]) return false;
  if (value.attackLab.awsRegion !== attackLabQueue[1] || value.attackLab.awsRegion !== attackLabKMS[1] || value.attackLab.awsRegion !== attackLabRunnerImage[2] || value.attackLab.evidenceBucketOwner !== discoveryRole[1] || !namePattern.test(value.attackLab.evidenceBucket) || value.attackLab.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token") return false;
  if (!/^sg-[a-f0-9]{8}(?:[a-f0-9]{9})?$/.test(value.attackLab.securityGroupID) || !/^sg-[a-f0-9]{8}(?:[a-f0-9]{9})?$/.test(value.attackLab.proxySecurityGroupID) || value.attackLab.securityGroupID === value.attackLab.proxySecurityGroupID) return false;
  if (!validProviderCIDRList(value.attackLab.targetAllowedCIDRs) || !validPrivateCIDRList(value.attackLab.egressCIDRs) || !validPrivateCIDRList(value.attackLab.kubernetesAPICIDRs) || hasCIDROverlap([...value.attackLab.egressCIDRs, ...value.attackLab.kubernetesAPICIDRs]) || value.attackLab.readinessCredentialReference !== "ref:red-team/readiness-0001" || value.attackLab.operationTimeout !== "10s" || value.attackLab.proxyRequestTimeout !== "10s" || value.attackLab.proxyShutdownTimeout !== "15s" || !validCABundle(value.attackLab.proxyCABundleBase64)) return false;
  if (!value.runtime || typeof value.runtime !== "object" || Array.isArray(value.runtime) || Object.keys(value.runtime).sort().join("\0") !== [...runtimeKeys].sort().join("\0")) return false;
  const runtimeQueue = /^https:\/\/sqs\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.amazonaws\.com\/([0-9]{12})\/agentsec-runtime-events$/.exec(value.runtime.queueURL);
  const runtimeKMS = /^arn:aws:kms:([a-z]{2}(?:-gov)?-[a-z]+-[0-9]):([0-9]{12}):key\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.exec(value.runtime.rawKMSKeyArn);
  const runtimeEndpoint = /^https:\/\/(?:search|vpc)-[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.([a-z]{2}(?:-gov)?-[a-z]+-[0-9])\.es\.amazonaws\.com$/.exec(value.runtime.openSearchEndpoint);
  const runtimeRoleNames = Object.freeze({ eventIngest: "runtime-ingest", gatewayControl: "gateway-control", outbox: "runtime-outbox", coordinator: "runtime-coordinator", archive: "runtime-archive", index: "runtime-index", correlation: "runtime-correlation", projection: "runtime-projection", complete: "runtime-complete" });
  const runtimeRoleARNs = Object.keys(runtimeRoleNames).map((key) => value.runtime[`${key}RoleArn`]);
  const runtimeRoles = Object.entries(runtimeRoleNames).map(([key, roleName]) => new RegExp(`^arn:aws:iam::([0-9]{12}):role/zasp-production-${roleName}$`).exec(value.runtime[`${key}RoleArn`]));
  if (!runtimeQueue || !runtimeKMS || !runtimeEndpoint || runtimeRoles.some((role) => !role) || new Set(runtimeRoleARNs).size !== runtimeRoles.length || runtimeRoles.some((role) => role[1] !== discoveryRole[1])) return false;
  if (value.runtime.awsRegion !== runtimeQueue[1] || value.runtime.awsRegion !== runtimeKMS[1] || value.runtime.awsRegion !== runtimeEndpoint[1] || runtimeQueue[2] !== discoveryRole[1] || runtimeKMS[2] !== discoveryRole[1] || value.runtime.rawBucketOwner !== discoveryRole[1]) return false;
  if (!namePattern.test(value.runtime.rawBucket) || value.runtime.openSearchIndex !== "zasp-runtime-events-v1" || value.runtime.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token" || !validCIDRList(value.runtime.egressCIDRs)) return false;
  if (!value.connectors || typeof value.connectors !== "object" || Array.isArray(value.connectors) || Object.keys(value.connectors).sort().join("\0") !== [...connectorKeys].sort().join("\0")) return false;
  const role = /^arn:aws:iam::([0-9]{12}):role\/zasp-production-api-connectors$/.exec(value.connectors.roleArn);
  const kms = /^arn:aws:kms:([a-z]{2}(?:-gov)?-[a-z]+-[0-9]):([0-9]{12}):key\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.exec(value.connectors.kmsKeyArn);
  if (!/^[a-z]{2}(?:-gov)?-[a-z]+-[0-9]$/.test(value.connectors.awsRegion) || !role || !kms || kms[1] !== value.connectors.awsRegion || kms[2] !== role[1] || role[1] !== discoveryRole[1]) return false;
  if (!Array.isArray(value.connectors.awsCustomerRolePrefixes) || value.connectors.awsCustomerRolePrefixes.length < 1 || value.connectors.awsCustomerRolePrefixes.length > 64 || new Set(value.connectors.awsCustomerRolePrefixes).size !== value.connectors.awsCustomerRolePrefixes.length || !value.connectors.awsCustomerRolePrefixes.every((prefix) => /^arn:aws:iam::[0-9]{12}:role\/[A-Za-z0-9+=,.@_/-]{1,120}\/$/.test(prefix))) return false;
  if (!Array.isArray(value.connectors.awsCustomerRoleARNs) || value.connectors.awsCustomerRoleARNs.length < 1 || value.connectors.awsCustomerRoleARNs.length > 64 || new Set(value.connectors.awsCustomerRoleARNs).size !== value.connectors.awsCustomerRoleARNs.length || !value.connectors.awsCustomerRoleARNs.every((roleARN) => /^arn:aws:iam::[0-9]{12}:role\/[A-Za-z0-9+=,.@_/-]{1,128}$/.test(roleARN) && value.connectors.awsCustomerRolePrefixes.some((prefix) => roleARN.startsWith(prefix) && roleARN !== prefix))) return false;
  if (value.connectors.webIdentityTokenFile !== "/var/run/secrets/eks.amazonaws.com/serviceaccount/token" || value.connectors.secretPrefix !== "zasp-production/connectors/oauth") return false;
  if (!/^Iv1\.[A-Za-z0-9]{16}$/.test(value.connectors.githubClientID) || value.connectors.githubClientSecretReference !== "ref:github/client-secret" || !/^[1-9][0-9]{0,15}$/.test(value.connectors.githubAppID) || value.connectors.githubPrivateKeyReference !== "ref:github/app-private-key") return false;
  if (!/^0oa[A-Za-z0-9]{16}$/.test(value.connectors.oktaClientID) || value.connectors.oktaClientSecretReference !== "ref:okta/client-secret") return false;
  if (value.discovery.githubAppID !== value.connectors.githubAppID || value.discovery.githubPrivateKeyReference !== value.connectors.githubPrivateKeyReference || value.discovery.oktaClientID !== value.connectors.oktaClientID || value.discovery.oktaClientSecretReference !== value.connectors.oktaClientSecretReference) return false;
  if (!value.connectorEgressCIDRs || typeof value.connectorEgressCIDRs !== "object" || Array.isArray(value.connectorEgressCIDRs) || Object.keys(value.connectorEgressCIDRs).sort().join("\0") !== [...connectorEgressKeys].sort().join("\0")) return false;
  if (!connectorEgressKeys.every((provider) => validCIDRList(value.connectorEgressCIDRs[provider]))) return false;
  if (!validProviderCIDRList(value.findingTicketEgressCIDRs)) return false;
  if (!value.securityAgentPlanner || typeof value.securityAgentPlanner !== "object" || Array.isArray(value.securityAgentPlanner) || Object.keys(value.securityAgentPlanner).sort().join("\0") !== [...securityAgentPlannerKeys].sort().join("\0") || value.securityAgentPlanner.endpoint !== "https://openrouter.ai/api/v1/chat/completions" || value.securityAgentPlanner.model !== "openai/gpt-5-mini" || !validProviderCIDRList(value.securityAgentPlanner.egressCIDRs)) return false;
  if (!value.nango || typeof value.nango !== "object" || Array.isArray(value.nango) || Object.keys(value.nango).sort().join("\0") !== [...nangoKeys].sort().join("\0") || !namePattern.test(value.nango.storageSecretName) || !validPrivateCIDRList(value.nango.databaseEgressCIDRs) || !validProviderCIDRList(value.nango.providerEgressCIDRs)) return false;
  if (hasCIDROverlap([...value.nango.databaseEgressCIDRs, ...value.nango.providerEgressCIDRs])) return false;
  if (!value.telemetry || typeof value.telemetry !== "object" || Array.isArray(value.telemetry) || Object.keys(value.telemetry).sort().join("\0") !== [...telemetryKeys].sort().join("\0")) return false;
  if (value.telemetry.backend === "none") return value.telemetry.endpoint === "" && value.telemetry.authSecretName === "" && Array.isArray(value.telemetry.egressCIDRs) && value.telemetry.egressCIDRs.length === 0;
  if (!namePattern.test(value.telemetry.authSecretName) || value.telemetry.authSecretName === value.nango.storageSecretName || !validProviderCIDRList(value.telemetry.egressCIDRs)) return false;
  if (value.telemetry.backend === "grafana") return /^https:\/\/otlp-gateway-[a-z0-9](?:[a-z0-9-]{0,78}[a-z0-9])?\.grafana\.net\/otlp$/.test(value.telemetry.endpoint);
  return value.telemetry.backend === "newrelic" && value.telemetry.endpoint === "https://otlp.nr-data.net";
}

export function validateRenderedRelease(resources, platformAccountID, schemaVersion = 49, sessionSearchPhase = "compatibility", expectedAuditExports, expectedTestReconciler, expectedComplianceExports, expectedAttackLabReconciler, expectedEvidenceExportWorkflow, discoveryScheduleReplayPhase, authorizationTemporal, expectedOptionalEgress, expectedOptionalPlannerCIDRs, expectedRetention, expectedEnvironmentClass, expectedAgentOwnerFilter, expectedAgentRead, expectedAgentExposureFilter, expectedAgentOwnershipWrite, expectedSensorNodeCoverage, expectedGatewayInstallation, expectedGatewayBootstrap) {
  // Standalone callers must provide reviewed provider ranges too; equality
  // against a simultaneously widened expected/rendered policy is insufficient.
  if (expectedOptionalEgress?.enabled === true && !validProviderCIDRList(expectedOptionalPlannerCIDRs)) throw new Error("optional egress provider CIDRs rejected");
  const accountPattern = /^[0-9]{12}$/;
  if (!Array.isArray(resources) || !accountPattern.test(platformAccountID) || platformAccountID === "000000000000" || (authorizationTemporal ? schemaVersion !== 61 || sessionSearchPhase !== "precision-intake" || discoveryScheduleReplayPhase !== "active" : !validSessionSearchPhase(schemaVersion, sessionSearchPhase) || !validDiscoveryScheduleReplayPhase(schemaVersion, discoveryScheduleReplayPhase))) throw new Error("release rejected");
  const auditExports = normalizeAuditExports(expectedAuditExports, platformAccountID, schemaVersion, sessionSearchPhase);
  const complianceExports = normalizeComplianceExports(expectedComplianceExports, platformAccountID, schemaVersion, sessionSearchPhase);
  const evidenceExportWorkflow = normalizeEvidenceExportWorkflow(expectedEvidenceExportWorkflow, schemaVersion, complianceExports);
  const attackLabReconciler = normalizeAttackLabReconciler(expectedAttackLabReconciler, platformAccountID, schemaVersion, sessionSearchPhase);
  validateAttackLabWorkflowReadiness(resources, Boolean(attackLabReconciler));
  validateExportWorkflowReadiness(resources, Boolean(evidenceExportWorkflow));
  validateAttackLabReconcilerResources(resources, attackLabReconciler, schemaVersion);
  validateComplianceExportResources(resources, complianceExports, schemaVersion, attackLabReconciler, Boolean(evidenceExportWorkflow));
  validateAuditExportResources(resources, auditExports, schemaVersion, complianceExports, attackLabReconciler);
  const testReconciler = normalizeTestReconciler(expectedTestReconciler, platformAccountID, schemaVersion, sessionSearchPhase);
  validateTestReconcilerResources(resources, testReconciler, schemaVersion);
  const retention = normalizeRetention(expectedRetention, authorizationTemporal, { enabled: Boolean(authorizationTemporal), taskQueue: resources.find(r=>r.kind==="Deployment"&&r.metadata?.name==="agentsec-api")?.spec?.template?.spec?.containers?.[0]?.env?.find(e=>e.name==="ZASP_TEMPORAL_TASK_QUEUE")?.value, discoveryTaskQueue: resources.find(r=>r.kind==="Deployment"&&r.metadata?.name==="agentsec-api")?.spec?.template?.spec?.containers?.[0]?.env?.find(e=>e.name==="ZASP_TEMPORAL_DISCOVERY_TASK_QUEUE")?.value });
  const deployments = new Map(resources.filter(({ kind }) => kind === "Deployment").map((resource) => [resource.metadata?.name, resource]));
  const deploymentIdentities = new Map([
    ["web", "agentsec-web"],
    ["agentsec-api", "agentsec-api"],
    ["agentsec-discovery-scheduler", "zasp-discovery-scheduler"],
    ["agentsec-discovery-worker", "zasp-discovery-worker"],
    ["agentsec-security-agent", "zasp-security-agent"],
    ["agentsec-security-agent-action", "zasp-security-agent-action"],
    ["agentsec-policy-deployment", "zasp-policy-deployment"],
    ["agentsec-outbox-publisher", "zasp-outbox-publisher"],
    ["agentsec-recovery-backup-outbox", "zasp-recovery-backup-outbox"],
    ["agentsec-recovery-restore-outbox", "zasp-recovery-restore-outbox"],
    ["agentsec-recovery-backup", "zasp-recovery-backup"],
    ["agentsec-recovery-restore", "zasp-recovery-restore"],
    ["agentsec-red-team-outbox", "zasp-red-team-outbox"],
    ["agentsec-red-team-worker", "zasp-red-team-worker"],
    ["agentsec-red-team-adapter", "zasp-red-team-adapter"],
    ["agentsec-attack-lab-controller", "zasp-attack-lab-controller"],
    ["agentsec-attack-lab-outbox", "zasp-attack-lab-outbox"],
    ["agentsec-attack-lab-proxy", "zasp-attack-lab-proxy"],
    ["agentsec-projection-risk", "zasp-projection-risk"],
    ["agentsec-projection-graph", "zasp-projection-graph"],
    ["agentsec-projection-search", "zasp-projection-search"],
    ["agentsec-event-ingest", "zasp-runtime-ingest"],
    ["agentsec-gateway-control", "zasp-gateway-control"],
    ["agentsec-runtime-outbox", "zasp-runtime-outbox"],
    ["agentsec-runtime-coordinator", "zasp-runtime-coordinator"],
    ["agentsec-runtime-archive", "zasp-runtime-archive"],
    ["agentsec-runtime-index", "zasp-runtime-index"],
    ["agentsec-runtime-correlation", "zasp-runtime-correlation"],
    ["agentsec-runtime-projection", "zasp-runtime-projection"],
    ["agentsec-runtime-complete", "zasp-runtime-complete"],
    ["nango", "nango"],
    ["otel-collector", "otel-collector"],
  ]);
  if (retention?.enabled) deploymentIdentities.set("agentsec-retention-reference-expiry", "zasp-retention-reference-expiry");
  if (sessionSearchPhase !== "compatibility") deploymentIdentities.set("agentsec-runtime-session-index-v2", "zasp-runtime-index");
  if (attackLabReconciler) deploymentIdentities.set("security-agent-attack-lab-reconciler", "security-agent-attack-lab-reconciler");
  if (testReconciler) deploymentIdentities.set("zasp-test-reconciler", "zasp-test-reconciler");
  if (complianceExports) for (const name of ["zasp-compliance-export-worker", "zasp-compliance-cleanup-worker"]) deploymentIdentities.set(name, name);
  if (auditExports) {
    deploymentIdentities.set("zasp-audit-export-worker", "zasp-audit-export-worker");
    deploymentIdentities.set("zasp-audit-export-outbox", "zasp-audit-export-outbox");
  }
  if (deployments.size !== deploymentIdentities.size || [...deploymentIdentities].some(([name, serviceAccount]) => deployments.get(name)?.spec?.template?.spec?.serviceAccountName !== serviceAccount)) throw new Error("release rejected");
  validateSessionSearchResources(resources, sessionSearchPhase, retention);
  validateDiscoveryScheduleReplayResources(resources, authorizationTemporal ? 60 : schemaVersion, discoveryScheduleReplayPhase);
  // Pre-stage the compatible reader before a later migration routes new v2 work.
  // A downgraded reader can claim those jobs and exhaust their retry budget.
  const correlation = deployments.get("agentsec-runtime-correlation").spec.template.spec.containers;
  const correlationVersions = correlation?.length === 1 && Array.isArray(correlation[0].env)
    ? correlation[0].env.filter(({ name }) => name === "ZASP_RUNTIME_STAGE_VERSION") : [];
  if (correlationVersions.length !== 1 || correlationVersions[0].value !== (["precision-consumers", "precision-intake"].includes(sessionSearchPhase) ? "runtime-correlation-v4" : "runtime-correlation-v2") || correlationVersions[0].valueFrom !== undefined) throw new Error("release rejected");
  const identityContracts = new Map([
    ["agentsec-web", null],
    ["agentsec-api", "api"],
    ["zasp-discovery-scheduler", "discovery-scheduler"],
    ["zasp-discovery-worker", "discovery-worker"],
    ["zasp-security-agent", "security-agent-worker"],
    ["zasp-security-agent-action", "security-agent-action-worker"],
    ["zasp-policy-deployment", "policy-deployment-worker"],
    ["zasp-outbox-publisher", "outbox"],
    ["zasp-recovery-backup-outbox", "recovery-backup-outbox"],
    ["zasp-recovery-restore-outbox", "recovery-restore-outbox"],
    ["zasp-recovery-backup", "recovery-backup"],
    ["zasp-recovery-restore", "recovery-restore"],
    ["zasp-red-team-outbox", "red-team-outbox"],
    ["zasp-red-team-worker", "red-team-worker"],
    ["zasp-red-team-adapter", "red-team-adapter"],
    ["zasp-attack-lab-controller", "attack-lab-controller"],
    ["zasp-attack-lab-outbox", "attack-lab-outbox"],
    ["zasp-attack-lab-proxy", "attack-lab-proxy"],
    ["agentsec-attack-lab-runner", "attack-lab-runner-test"],
    ["zasp-projection-risk", "projection-risk"],
    ["zasp-projection-graph", "projection-graph"],
    ["zasp-projection-search", "projection-search"],
    ["zasp-runtime-ingest", "runtime-ingest"],
    ["zasp-gateway-control", "gateway-control"],
    ["zasp-runtime-outbox", "runtime-outbox"],
    ["zasp-runtime-coordinator", "runtime-coordinator"],
    ["zasp-runtime-archive", "runtime-archive"],
    ["zasp-runtime-index", "runtime-index"],
    ["zasp-runtime-correlation", "runtime-correlation"],
    ["zasp-runtime-projection", "runtime-projection"],
    ["zasp-runtime-complete", "runtime-complete"],
    ["nango", null],
    ["nango-migrate", null],
    ["otel-collector", null],
    ["agentsec-migration", "migration"],
    ["agentsec-projection-graph-init", "projection-graph-init"],
    ["agentsec-projection-search-init", "projection-search-init"],
    ["agentsec-canary", null],
    ["agentsec-canary-secret-sync", "canary-secret-sync"],
  ]);
  if (auditExports) {
    identityContracts.set("zasp-audit-export-worker", auditExports.writerRoleArn);
    identityContracts.set("zasp-audit-export-outbox", auditExports.publisherRoleArn);
  }
  const accounts = new Map(resources.filter(({ kind }) => kind === "ServiceAccount").map((resource) => [resource.metadata?.name, resource]));
  if (authorizationTemporal) {
    identityContracts.set("zasp-security-agent", authorizationTemporal.workerRoleArn);
    identityContracts.set("zasp-red-team-adapter", authorizationTemporal.adapterRoleArn);
    identityContracts.set("zasp-authorization-projector", authorizationTemporal.projectorRoleArn);
  }
  if (attackLabReconciler) identityContracts.set("security-agent-attack-lab-reconciler", attackLabReconciler.roleArn);
  if (testReconciler) identityContracts.set("zasp-test-reconciler", testReconciler.roleArn);
  if (complianceExports) {
    identityContracts.set("zasp-compliance-export-worker", complianceExports.writerRoleArn);
    identityContracts.set("zasp-compliance-cleanup-worker", complianceExports.cleanupRoleArn);
  }
  if (retention?.enabled) identityContracts.set("zasp-retention-reference-expiry", null);
  if (accounts.size !== identityContracts.size) throw new Error("release rejected");
  for (const [name, role] of identityContracts) {
    const rendered = accounts.get(name);
    const roleArn = rendered?.metadata?.annotations?.["eks.amazonaws.com/role-arn"];
    const explicitRole = (authorizationTemporal && ["zasp-security-agent", "zasp-red-team-adapter", "zasp-authorization-projector"].includes(name)) || (attackLabReconciler && name === "security-agent-attack-lab-reconciler") || (auditExports && ["zasp-audit-export-worker", "zasp-audit-export-outbox"].includes(name)) || (testReconciler && name === "zasp-test-reconciler") || (complianceExports && ["zasp-compliance-export-worker", "zasp-compliance-cleanup-worker"].includes(name));
    const expectedRole = explicitRole ? role : `arn:aws:iam::${platformAccountID}:role/zasp-production-${role}`;
    if (!rendered || (role === null ? roleArn !== undefined : roleArn !== expectedRole)) throw new Error("release rejected");
  }
  const jobIdentities = new Map([
    [`agentsec-schema-v${schemaVersion}`, "agentsec-migration"],
    ["agentsec-projection-graph-init-v1", "agentsec-projection-graph-init"],
    ["agentsec-projection-search-init-v1", "agentsec-projection-search-init"],
    ["nango-migrate", "nango-migrate"],
    ["zasp-canary-secret-sync", "agentsec-canary-secret-sync"],
  ]);
  const jobs = resources.filter(({ kind }) => kind === "Job");
  if (sessionSearchPhase !== "compatibility") jobIdentities.set("agentsec-projection-search-init-v2", "agentsec-projection-search-init");
  if (jobs.length !== jobIdentities.size || jobs.some((resource) => jobIdentities.get(resource.metadata?.name) !== resource.spec?.template?.spec?.serviceAccountName)) throw new Error("release rejected");
  const migration = jobs.find(({ metadata }) => metadata.name === `agentsec-schema-v${schemaVersion}`);
  let command = complianceExports ? complianceExportMigrationCommand(schemaVersion, Boolean(auditExports)) : auditExports ? auditExportMigrationCommand(schemaVersion) : `export ZASP_POSTGRES_DSN="$(cat /var/run/secrets/zasp-migration/postgres-dsn)"; exec /app/agentsec-migrate up-to-${schemaVersion}`;
  if (attackLabReconciler) command = attackLabReconcilerMigrationCommand(command);
  if (authorizationTemporal) command = authorizationTemporalMigrationShell(authorizationTemporal);
  const migrationContainers = migration?.spec?.template?.spec?.containers;
  if (!Array.isArray(migrationContainers) || migrationContainers.length !== 1 || JSON.stringify(migrationContainers[0].command) !== JSON.stringify(["/bin/sh", "-ec"]) || JSON.stringify(migrationContainers[0].args) !== JSON.stringify([command])) throw new Error("release rejected");
  for (const deployment of deployments.values()) {
    const annotation = deployment.spec?.template?.metadata?.annotations?.["zasp.io/schema-version"];
    if (annotation !== undefined && annotation !== String(schemaVersion)) throw new Error("release rejected");
  }
  const api = deployments.get("agentsec-api");
  const expected = api?.spec?.template?.spec?.containers?.[0]?.env?.filter(({ name }) => name === "ZASP_EXPECTED_SCHEMA_VERSION");
  if (api?.spec?.template?.metadata?.annotations?.["zasp.io/schema-version"] !== String(schemaVersion) || expected?.length !== 1 || expected[0].value !== String(schemaVersion) || expected[0].valueFrom !== undefined) throw new Error("release rejected");
  const cronJobIdentities = new Map([["production-readonly-canary", "agentsec-canary"]]);
  if (authorizationTemporal) cronJobIdentities.set("zasp-authorization-projector", "zasp-authorization-projector");
  const cronJobs = resources.filter(({ kind }) => kind === "CronJob");
  if (cronJobs.length !== cronJobIdentities.size || cronJobs.some((resource) => cronJobIdentities.get(resource.metadata?.name) !== resource.spec?.jobTemplate?.spec?.template?.spec?.serviceAccountName)) throw new Error("release rejected");
  validateAuthorizationTemporalResources(resources, authorizationTemporal, platformAccountID, retention);
  const optionalRuntime = { enabled: Boolean(authorizationTemporal), clientSecret: api?.spec?.template?.spec?.volumes?.find(v=>v.name==='runtime-services')?.secret?.secretName };
  const optionalEgress = normalizeOptionalEgress(expectedOptionalEgress, authorizationTemporal, optionalRuntime);
  validateOptionalEgressResources(resources, optionalEgress, expectedOptionalPlannerCIDRs);
  validateRetentionResources(resources, retention, authorizationTemporal);
  const environmentClass = normalizeEnvironmentClass(expectedEnvironmentClass, authorizationTemporal, optionalRuntime);
  validateEnvironmentClassResources(resources, environmentClass);
  const agentOwnerFilter = normalizeAgentOwnerFilter(expectedAgentOwnerFilter, authorizationTemporal, optionalRuntime);
  validateAgentOwnerFilterResources(resources, agentOwnerFilter);
  const agentRead = normalizeAgentRead(expectedAgentRead, authorizationTemporal, optionalRuntime);
  validateAgentReadResources(resources, agentRead);
  validateSensorNodeCoverageResources(resources, normalizeSensorNodeCoverage(expectedSensorNodeCoverage, authorizationTemporal, optionalRuntime));
  validateGatewayInstallationResources(resources, normalizeGatewayInstallation(expectedGatewayInstallation, authorizationTemporal, optionalRuntime));
  validateGatewayBootstrapResources(resources, normalizeGatewayBootstrap(expectedGatewayBootstrap, authorizationTemporal, optionalRuntime));
  const agentOwnershipWrite = normalizeAgentOwnershipWrite(expectedAgentOwnershipWrite, authorizationTemporal, optionalRuntime);
  validateAgentOwnershipWriteResources(resources, agentOwnershipWrite);
  const agentExposureFilter = normalizeAgentExposureFilter(expectedAgentExposureFilter, authorizationTemporal, optionalRuntime);
  validateAgentExposureFilterResources(resources, agentExposureFilter);
  return Object.freeze({ deployments: deployments.size, identities: accounts.size, platformAccountID });
}

function authorizationTemporalMigrationShell(profile) {
  return 'export ZASP_POSTGRES_DSN="$(cat /var/run/secrets/zasp-migration/postgres-dsn)"; export ZASP_WORKFLOW_SIGNING_KEY="$(cat /var/run/secrets/zasp-migration/workflow-signing-key)"; export ZASP_STYTCH_PROJECT_ID="$(cat /var/run/secrets/zasp-migration/stytch-project-id)"; export ZASP_STYTCH_ORGANIZATION_ID="$(cat /var/run/secrets/zasp-migration/stytch-organization-id)"; ' + authorizationTemporalMigrationCommands(profile).map(command => `/app/agentsec-migrate ${command}`).join('; ');
}

function validCABundle(value) {
  if (typeof value !== "string" || value.length < 256 || value.length > 65536 || !/^[A-Za-z0-9+/]+={0,2}$/.test(value)) return false;
  let decoded;
  try {
    decoded = Buffer.from(value, "base64");
  } catch {
    return false;
  }
  if (decoded.toString("base64") !== value) return false;
  const pem = decoded.toString("utf8");
  const certificates = pem.match(/-----BEGIN CERTIFICATE-----\n(?:[A-Za-z0-9+/]{1,64}\n)+[A-Za-z0-9+/]{1,64}={0,2}\n-----END CERTIFICATE-----\n/g);
  if (!certificates || certificates.join("") !== pem || certificates.length > 8) return false;
  try {
    for (const certificate of certificates) new X509Certificate(certificate);
  } catch {
    return false;
  }
  return true;
}

function validCIDRList(value) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 16 || new Set(value).size !== value.length) return false;
  return value.every((cidr) => cidrRange(cidr) !== undefined);
}

function validGatewayProxyCIDRList(value) {
  if (!validCIDRList(value) || hasCIDROverlap(value)) return false;
  return value.every((cidr) => {
    const { first, second, prefix } = cidrRange(cidr);
    return prefix >= 16 && first !== 0 && first !== 127 && first < 224 && !(first === 169 && second === 254);
  });
}

function validPrivateCIDRList(value) {
  if (!validCIDRList(value) || hasCIDROverlap(value)) return false;
  return value.every((cidr) => {
    const { first, second, prefix } = cidrRange(cidr);
    return prefix >= 24 && (first === 10 || (first === 172 && second >= 16 && second <= 31) || (first === 192 && second === 168));
  });
}

function validProviderCIDRList(value) {
  if (!validCIDRList(value) || hasCIDROverlap(value)) return false;
  return value.every((cidr) => {
    const { first, second, prefix } = cidrRange(cidr);
    const nonPublic = first === 0 || first === 10 || first === 127 || first >= 224 ||
      (first === 100 && second >= 64 && second <= 127) ||
      (first === 169 && second === 254) ||
      (first === 172 && second >= 16 && second <= 31) ||
      (first === 192 && second === 168) ||
      (first === 198 && (second === 18 || second === 19));
    return prefix >= 16 && !nonPublic;
  });
}

function validS3CIDRList(value) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 64 || new Set(value).size !== value.length || hasCIDROverlap(value)) return false;
  return value.every((cidr) => {
    const range = cidrRange(cidr);
    if (!range || range.prefix < 16) return false;
    const { first, second } = range;
    return first !== 0 && first !== 10 && first !== 127 && first < 224 &&
      !(first === 100 && second >= 64 && second <= 127) &&
      !(first === 169 && second === 254) &&
      !(first === 172 && second >= 16 && second <= 31) &&
      !(first === 192 && second === 168) &&
      !(first === 198 && (second === 18 || second === 19));
  });
}

function hasCIDROverlap(value) {
  const ranges = value.map(cidrRange).sort((left, right) => left.start - right.start || left.end - right.end);
  return ranges.some((range, index) => index > 0 && range.start <= ranges[index - 1].end);
}

function cidrRange(cidr) {
  if (typeof cidr !== "string" || cidr.includes(" ")) return undefined;
  const match = /^([^/]+)\/([0-9]{1,2})$/.exec(cidr);
  if (!match || isIP(match[1]) !== 4 || match[1].split(".").some((part) => String(Number(part)) !== part)) return undefined;
  const prefix = Number(match[2]);
  if (prefix < 1 || prefix > 32) return undefined;
  const octets = match[1].split(".").map(Number);
  const address = octets.reduce((result, part) => ((result << 8) | part) >>> 0, 0);
  const mask = prefix === 32 ? 0xffffffff : (0xffffffff << (32 - prefix)) >>> 0;
  const start = (address & mask) >>> 0;
  if (start !== address) return undefined;
  return { start, end: start + (2 ** (32 - prefix)) - 1, prefix, first: octets[0], second: octets[1] };
}
