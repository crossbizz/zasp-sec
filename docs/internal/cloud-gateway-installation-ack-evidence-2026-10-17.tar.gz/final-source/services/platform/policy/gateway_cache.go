package policy

import (
	"bufio"
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/zasp-ai/zasp-sec/services/platform/domain"
	wire "github.com/zasp-ai/zasp-sec/services/platform/gatewayinstallationwire"
	"github.com/zasp-ai/zasp-sec/services/platform/internal/cacheownership"
)

var ErrGatewayPolicy = errors.New("gateway policy rejected")

var gatewayKeyIDPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{7,63}$`)

const (
	GatewayPolicyValid            = "valid"
	GatewayPolicyExpiredOpen      = "expired_open"
	GatewayPolicyExpiredClosed    = "expired_closed"
	maximumGatewayPolicyBytes     = 1024 * 1024
	maximumGatewayPolicyDiskBytes = maximumGatewayPolicyBytes + 8192
	ed25519RawURLSignatureLength  = 86
	maximumGatewayPolicies        = 100
)

type GatewayPolicyBinding struct {
	OrganizationID string `json:"organization_id"`
	WorkspaceID    string `json:"workspace_id"`
	EnvironmentID  string `json:"environment_id"`
	DeviceID       string `json:"device_id"`
}

type GatewayPolicyEnvelope struct {
	ContractVersion int              `json:"contract_version"`
	KeyID           string           `json:"key_id"`
	Algorithm       string           `json:"algorithm"`
	Audience        string           `json:"audience"`
	OrganizationID  string           `json:"organization_id"`
	WorkspaceID     string           `json:"workspace_id"`
	EnvironmentID   string           `json:"environment_id"`
	DeviceID        string           `json:"device_id"`
	Sequence        uint64           `json:"sequence"`
	PolicyVersion   uint64           `json:"policy_version"`
	IssuedAt        time.Time        `json:"issued_at"`
	ExpiresAt       time.Time        `json:"expires_at"`
	FailureMode     string           `json:"failure_mode"`
	PayloadDigest   string           `json:"payload_digest"`
	Policies        []CompiledPolicy `json:"policies"`
	Signature       string           `json:"signature"`
}

type GatewayPolicySigningInput struct {
	KeyID                    string
	Binding                  GatewayPolicyBinding
	Sequence, PolicyVersion  uint64
	Now, IssuedAt, ExpiresAt time.Time
	FailureMode              string
	Policies                 []CompiledPolicy
}

type gatewayPolicyDiskState struct {
	Version      int                        `json:"version,omitempty"`
	Installation *gatewayPolicyInstallation `json:"installation,omitempty"`
	Envelope     GatewayPolicyEnvelope      `json:"envelope"`
	ObservedAt   time.Time                  `json:"observed_at"`
}

type GatewayPolicyKeys struct {
	values map[string]ed25519.PublicKey
}

// Valid reports whether the immutable verifier set still has the exact shape
// accepted by NewGatewayPolicyKeys. It performs no provider or filesystem I/O.
func (keys GatewayPolicyKeys) Valid() bool {
	if len(keys.values) < 1 || len(keys.values) > 32 {
		return false
	}
	for keyID, key := range keys.values {
		if !gatewayKeyIDPattern.MatchString(keyID) || len(key) != ed25519.PublicKeySize {
			return false
		}
	}
	return true
}

// Contains checks one exact public signing identity without exposing the key
// map to callers.
func (keys GatewayPolicyKeys) Contains(keyID string, key ed25519.PublicKey) bool {
	return keys.Valid() && len(key) == ed25519.PublicKeySize && bytes.Equal(keys.values[keyID], key)
}

// HasKeyID checks configured membership without obtaining a private key.
func (keys GatewayPolicyKeys) HasKeyID(keyID string) bool {
	_, exists := keys.values[keyID]
	return keys.Valid() && exists
}

func NewGatewayPolicyKeys(values map[string]ed25519.PublicKey) (GatewayPolicyKeys, error) {
	if len(values) < 1 || len(values) > 32 {
		return GatewayPolicyKeys{}, ErrGatewayPolicy
	}
	result := GatewayPolicyKeys{values: make(map[string]ed25519.PublicKey, len(values))}
	for keyID, key := range values {
		if !gatewayKeyIDPattern.MatchString(keyID) || len(key) != ed25519.PublicKeySize {
			return GatewayPolicyKeys{}, ErrGatewayPolicy
		}
		result.values[keyID] = append(ed25519.PublicKey(nil), key...)
	}
	return result, nil
}

func VerifyGatewayPolicyEnvelope(envelope GatewayPolicyEnvelope, keys GatewayPolicyKeys, binding GatewayPolicyBinding, now time.Time) (GatewayPolicyEnvelope, error) {
	return verifyGatewayPolicyEnvelope(envelope, keys, binding, now, false)
}

func SignGatewayPolicyEnvelope(input GatewayPolicySigningInput, privateKey ed25519.PrivateKey) (GatewayPolicyEnvelope, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	envelope, payload, err := validatedGatewayPolicySigningInput(input)
	if err != nil {
		return GatewayPolicyEnvelope{}, err
	}
	envelope.Signature = base64.RawURLEncoding.EncodeToString(ed25519.Sign(privateKey, payload))
	publicKey, ok := privateKey.Public().(ed25519.PublicKey)
	if !ok {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	keys, err := NewGatewayPolicyKeys(map[string]ed25519.PublicKey{input.KeyID: publicKey})
	if err != nil {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	return VerifyGatewayPolicyEnvelope(envelope, keys, input.Binding, input.Now)
}

// ValidateGatewayPolicySigningInput uses the signer's complete authority and
// compiled-policy validation, without obtaining a key or producing a signature.
func ValidateGatewayPolicySigningInput(input GatewayPolicySigningInput) error {
	_, _, err := validatedGatewayPolicySigningInput(input)
	return err
}

func validatedGatewayPolicySigningInput(input GatewayPolicySigningInput) (GatewayPolicyEnvelope, []byte, error) {
	if !gatewayKeyIDPattern.MatchString(input.KeyID) || !validGatewayBinding(input.Binding) || input.Sequence < 1 || input.PolicyVersion < 1 ||
		!canonicalGatewayTime(input.Now) || !canonicalGatewayTime(input.IssuedAt) || !canonicalGatewayTime(input.ExpiresAt) || input.IssuedAt.After(input.Now.Add(30*time.Second)) ||
		!input.ExpiresAt.After(input.Now) || !input.ExpiresAt.After(input.IssuedAt) || input.ExpiresAt.Sub(input.IssuedAt) > 24*time.Hour || input.FailureMode != "open" && input.FailureMode != "closed" ||
		len(input.Policies) > maximumGatewayPolicies {
		return GatewayPolicyEnvelope{}, nil, ErrGatewayPolicy
	}
	envelope := GatewayPolicyEnvelope{
		ContractVersion: 1,
		KeyID:           input.KeyID,
		Algorithm:       "Ed25519",
		Audience:        "runtime-gateway-policy",
		OrganizationID:  input.Binding.OrganizationID,
		WorkspaceID:     input.Binding.WorkspaceID,
		EnvironmentID:   input.Binding.EnvironmentID,
		DeviceID:        input.Binding.DeviceID,
		Sequence:        input.Sequence,
		PolicyVersion:   input.PolicyVersion,
		IssuedAt:        input.IssuedAt,
		ExpiresAt:       input.ExpiresAt,
		FailureMode:     input.FailureMode,
		Policies:        make([]CompiledPolicy, len(input.Policies)),
	}
	for index, compiled := range input.Policies {
		envelope.Policies[index] = cloneCompiledPolicy(compiled)
	}
	digest, payload, err := canonicalGatewayPolicyPayload(envelope)
	if err != nil {
		return GatewayPolicyEnvelope{}, nil, ErrGatewayPolicy
	}
	envelope.PayloadDigest = digest
	return envelope, payload, nil
}

func verifyGatewayPolicyEnvelope(envelope GatewayPolicyEnvelope, keys GatewayPolicyKeys, binding GatewayPolicyBinding, now time.Time, allowExpired bool) (GatewayPolicyEnvelope, error) {
	if !validGatewayBinding(binding) || !canonicalGatewayTime(now) || len(keys.values) < 1 || envelope.ContractVersion != 1 || !gatewayKeyIDPattern.MatchString(envelope.KeyID) ||
		envelope.Algorithm != "Ed25519" || envelope.Audience != "runtime-gateway-policy" || envelope.Sequence < 1 || envelope.PolicyVersion < 1 ||
		envelope.OrganizationID != binding.OrganizationID || envelope.WorkspaceID != binding.WorkspaceID || envelope.EnvironmentID != binding.EnvironmentID || envelope.DeviceID != binding.DeviceID ||
		!canonicalGatewayTime(envelope.IssuedAt) || !canonicalGatewayTime(envelope.ExpiresAt) || !envelope.ExpiresAt.After(envelope.IssuedAt) || envelope.ExpiresAt.Sub(envelope.IssuedAt) > 24*time.Hour ||
		envelope.IssuedAt.After(now.Add(30*time.Second)) || !allowExpired && !envelope.ExpiresAt.After(now) || envelope.FailureMode != "open" && envelope.FailureMode != "closed" ||
		len(envelope.Policies) > maximumGatewayPolicies || len(envelope.PayloadDigest) != sha256.Size*2 {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	publicKey, exists := keys.values[envelope.KeyID]
	if !exists || len(publicKey) != ed25519.PublicKeySize {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	if len(envelope.Signature) != ed25519RawURLSignatureLength {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	encoded, err := json.Marshal(envelope)
	if err != nil || len(encoded) > maximumGatewayPolicyBytes {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	digest, payload, err := canonicalGatewayPolicyPayload(envelope)
	if err != nil || digest != envelope.PayloadDigest {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	signature, err := base64.RawURLEncoding.DecodeString(envelope.Signature)
	if err != nil || len(signature) != ed25519.SignatureSize || base64.RawURLEncoding.EncodeToString(signature) != envelope.Signature || !ed25519.Verify(publicKey, payload, signature) {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	verified := cloneGatewayPolicyEnvelope(envelope)
	sort.Slice(verified.Policies, func(left, right int) bool { return verified.Policies[left].ID < verified.Policies[right].ID })
	return verified, nil
}

func canonicalGatewayPolicyPayload(envelope GatewayPolicyEnvelope) (string, []byte, error) {
	if len(envelope.Policies) > maximumGatewayPolicies {
		return "", nil, ErrGatewayPolicy
	}
	policies := make([]CompiledPolicy, len(envelope.Policies))
	seen := make(map[string]struct{}, len(envelope.Policies))
	for index, policy := range envelope.Policies {
		if verifyCompiled(policy) != nil {
			return "", nil, ErrGatewayPolicy
		}
		if _, exists := seen[policy.ID]; exists {
			return "", nil, ErrGatewayPolicy
		}
		seen[policy.ID] = struct{}{}
		policies[index] = cloneCompiledPolicy(policy)
	}
	sort.Slice(policies, func(left, right int) bool { return policies[left].ID < policies[right].ID })
	payload, err := json.Marshal(struct {
		ContractVersion int              `json:"contract_version"`
		KeyID           string           `json:"key_id"`
		Algorithm       string           `json:"algorithm"`
		Audience        string           `json:"audience"`
		OrganizationID  string           `json:"organization_id"`
		WorkspaceID     string           `json:"workspace_id"`
		EnvironmentID   string           `json:"environment_id"`
		DeviceID        string           `json:"device_id"`
		Sequence        uint64           `json:"sequence"`
		PolicyVersion   uint64           `json:"policy_version"`
		IssuedAt        time.Time        `json:"issued_at"`
		ExpiresAt       time.Time        `json:"expires_at"`
		FailureMode     string           `json:"failure_mode"`
		Policies        []CompiledPolicy `json:"policies"`
	}{
		ContractVersion: envelope.ContractVersion,
		KeyID:           envelope.KeyID,
		Algorithm:       envelope.Algorithm,
		Audience:        envelope.Audience,
		OrganizationID:  envelope.OrganizationID,
		WorkspaceID:     envelope.WorkspaceID,
		EnvironmentID:   envelope.EnvironmentID,
		DeviceID:        envelope.DeviceID,
		Sequence:        envelope.Sequence,
		PolicyVersion:   envelope.PolicyVersion,
		IssuedAt:        envelope.IssuedAt,
		ExpiresAt:       envelope.ExpiresAt,
		FailureMode:     envelope.FailureMode,
		Policies:        policies,
	})
	if err != nil || len(payload) > maximumGatewayPolicyBytes {
		return "", nil, ErrGatewayPolicy
	}
	digest := sha256.Sum256(payload)
	return hex.EncodeToString(digest[:]), payload, nil
}

type GatewayPolicyCache struct {
	ownership           *cacheownership.Guard
	installationEnabled bool
	diskVersion         int
	installation        *gatewayPolicyInstallation
	mu                  sync.Mutex
	keys                GatewayPolicyKeys
	binding             GatewayPolicyBinding
	now                 func() time.Time
	root                *os.Root
	name                string
	closed              bool
	current             *GatewayPolicyEnvelope
	observedAt          time.Time
}

func NewGatewayPolicyCache(keys GatewayPolicyKeys, binding GatewayPolicyBinding, now func() time.Time) (*GatewayPolicyCache, error) {
	return newGatewayPolicyCache("", keys, binding, now)
}

func NewGatewayPolicyDiskCache(path string, keys GatewayPolicyKeys, binding GatewayPolicyBinding, now func() time.Time) (*GatewayPolicyCache, error) {
	return newGatewayPolicyDiskCache(path, keys, binding, now, false)
}
func newGatewayPolicyDiskCache(path string, keys GatewayPolicyKeys, binding GatewayPolicyBinding, now func() time.Time, installationEnabled bool) (*GatewayPolicyCache, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path || filepath.Base(path) == "." || filepath.Base(path) == string(filepath.Separator) {
		return nil, ErrGatewayPolicy
	}
	cache, err := newGatewayPolicyCache("", keys, binding, now)
	if err != nil {
		return nil, err
	}
	root, name, err := openGatewayPolicyRoot(path)
	if err != nil {
		return nil, ErrGatewayPolicy
	}
	cache.root, cache.name = root, name
	if installationEnabled && !cacheownership.Supported() {
		_ = cache.Close()
		return nil, ErrGatewayPolicy
	}
	if cacheownership.Supported() {
		cache.ownership, err = cacheownership.Acquire(root, name)
		if err != nil {
			_ = cache.Close()
			return nil, ErrGatewayPolicy
		}
	}
	cache.installationEnabled = installationEnabled
	raw, err := readGatewayPolicyRoot(root, name)
	if errors.Is(err, os.ErrNotExist) {
		return cache, nil
	}
	if err != nil {
		_ = cache.Close()
		return nil, ErrGatewayPolicy
	}
	state, err := decodeGatewayPolicyDiskState(bytes.NewReader(raw))
	if err != nil {
		_ = cache.Close()
		return nil, err
	}
	if !canonicalGatewayTime(state.ObservedAt) || state.Version != 0 && state.Version != 2 || state.Version == 0 && state.Installation != nil {
		_ = cache.Close()
		return nil, ErrGatewayPolicy
	}
	effectiveNow := laterGatewayTime(cache.observedAt, state.ObservedAt)
	verified, err := verifyGatewayPolicyEnvelope(state.Envelope, cache.keys, cache.binding, effectiveNow, true)
	if err != nil {
		_ = cache.Close()
		return nil, err
	}
	if !validGatewayInstallation(state.Installation, verified) {
		_ = cache.Close()
		return nil, ErrGatewayPolicy
	}
	if state.Installation != nil {
		witness, err := wire.ParseObservation(state.Installation.Body)
		if err != nil || witness.InstalledObservedAt.After(state.ObservedAt) {
			_ = cache.Close()
			return nil, ErrGatewayPolicy
		}
	}
	cache.diskVersion, cache.installation = state.Version, cloneGatewayInstallation(state.Installation)
	canonical, err := marshalGatewayPolicyState(verified, state.ObservedAt, state.Version, state.Installation)
	if err != nil || !bytes.Equal(raw, canonical) {
		_ = cache.Close()
		return nil, ErrGatewayPolicy
	}
	// Re-establish full durability of a recovered witness before exposing it.
	// This also covers a previous process whose final write outcome was unknown.
	if effectiveNow.After(state.ObservedAt) || installationEnabled && state.Installation != nil {
		if err := cache.persistInstallationStateLocked(verified, effectiveNow, cache.installation, cache.diskVersion); err != nil {
			_ = cache.Close()
			return nil, err
		}
	}
	cache.current = &verified
	cache.observedAt = effectiveNow
	return cache, nil
}

func newGatewayPolicyCache(path string, keys GatewayPolicyKeys, binding GatewayPolicyBinding, now func() time.Time) (*GatewayPolicyCache, error) {
	if !validGatewayBinding(binding) || len(keys.values) < 1 || now == nil {
		return nil, ErrGatewayPolicy
	}
	clonedKeys, err := NewGatewayPolicyKeys(keys.values)
	if err != nil {
		return nil, err
	}
	nowValue, ok := gatewayNow(now)
	if !ok {
		return nil, ErrGatewayPolicy
	}
	return &GatewayPolicyCache{keys: clonedKeys, binding: binding, now: now, observedAt: nowValue}, nil
}

func (cache *GatewayPolicyCache) Store(envelope GatewayPolicyEnvelope) error {
	if cache == nil || cache.now == nil {
		return ErrGatewayPolicy
	}
	nowValue, ok := gatewayNow(cache.now)
	if !ok {
		return ErrGatewayPolicy
	}
	cache.mu.Lock()
	defer cache.mu.Unlock()
	if cache.closed || cache.ownership != nil && !cache.ownership.Valid() {
		return ErrGatewayPolicy
	}
	effectiveNow := laterGatewayTime(nowValue, cache.observedAt)
	verified, err := VerifyGatewayPolicyEnvelope(envelope, cache.keys, cache.binding, effectiveNow)
	if err != nil {
		return err
	}
	if cache.current != nil {
		if verified.Sequence < cache.current.Sequence || verified.PolicyVersion < cache.current.PolicyVersion {
			return ErrGatewayPolicy
		}
		if verified.Sequence == cache.current.Sequence {
			if !equalGatewayEnvelope(verified, *cache.current) {
				return ErrGatewayPolicy
			}
			if cache.root != nil {
				if err := cache.persistInstallationStateLocked(verified, effectiveNow, cache.installation, cache.diskVersion); err != nil {
					return err
				}
			}
			cache.observedAt = effectiveNow
			return nil
		}
		if verified.PolicyVersion == cache.current.PolicyVersion && !equalGatewayPolicySemantics(verified, *cache.current) {
			return ErrGatewayPolicy
		}
	}
	if cache.root != nil {
		// A genuinely newer legacy Store supersedes the old credential-bound
		// witness explicitly. It cannot attribute that witness to this envelope.
		if err := cache.persistInstallationStateLocked(verified, effectiveNow, nil, cache.diskVersion); err != nil {
			return err
		}
	}
	cache.installation = nil
	cloned := cloneGatewayPolicyEnvelope(verified)
	cache.current = &cloned
	cache.observedAt = effectiveNow
	return nil
}

func (cache *GatewayPolicyCache) Current() (GatewayPolicyEnvelope, string, error) {
	if cache == nil || cache.now == nil {
		return GatewayPolicyEnvelope{}, "", ErrGatewayPolicy
	}
	nowValue, ok := gatewayNow(cache.now)
	if !ok {
		return GatewayPolicyEnvelope{}, "", ErrGatewayPolicy
	}
	cache.mu.Lock()
	defer cache.mu.Unlock()
	if cache.closed || cache.ownership != nil && !cache.ownership.Valid() {
		return GatewayPolicyEnvelope{}, "", ErrGatewayPolicy
	}
	if cache.current == nil {
		return GatewayPolicyEnvelope{}, "", ErrGatewayPolicy
	}
	current := cloneGatewayPolicyEnvelope(*cache.current)
	effectiveNow := laterGatewayTime(nowValue, cache.observedAt)
	verified, err := verifyGatewayPolicyEnvelope(current, cache.keys, cache.binding, effectiveNow, true)
	if err != nil {
		return GatewayPolicyEnvelope{}, "", err
	}
	if effectiveNow.After(cache.observedAt) {
		if cache.root != nil {
			if err := cache.persistInstallationStateLocked(verified, effectiveNow, cache.installation, cache.diskVersion); err != nil {
				return GatewayPolicyEnvelope{}, "", err
			}
		}
		cache.observedAt = effectiveNow
	}
	if effectiveNow.Before(verified.ExpiresAt) {
		return verified, GatewayPolicyValid, nil
	}
	if verified.FailureMode == "open" {
		return verified, GatewayPolicyExpiredOpen, nil
	}
	return verified, GatewayPolicyExpiredClosed, nil
}

// Close releases the pinned disk authority. Memory-only caches have no
// external resource and Close remains idempotent.
func (cache *GatewayPolicyCache) Close() error {
	if cache == nil {
		return nil
	}
	cache.mu.Lock()
	defer cache.mu.Unlock()
	if cache.closed {
		return nil
	}
	cache.closed = true
	cache.current = nil
	if cache.root == nil {
		return nil
	}
	var ownershipErr error
	if cache.ownership != nil {
		ownershipErr = cache.ownership.Close()
		cache.ownership = nil
	}
	err := cache.root.Close()
	cache.root = nil
	if err != nil || ownershipErr != nil {
		return ErrGatewayPolicy
	}
	return nil
}

func decodeGatewayPolicyEnvelope(reader io.Reader) (GatewayPolicyEnvelope, error) {
	decoder := json.NewDecoder(bufio.NewReader(reader))
	decoder.DisallowUnknownFields()
	var envelope GatewayPolicyEnvelope
	if err := decoder.Decode(&envelope); err != nil {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		return GatewayPolicyEnvelope{}, ErrGatewayPolicy
	}
	return envelope, nil
}

func decodeGatewayPolicyDiskState(reader io.Reader) (gatewayPolicyDiskState, error) {
	decoder := json.NewDecoder(bufio.NewReader(reader))
	decoder.DisallowUnknownFields()
	var state gatewayPolicyDiskState
	if err := decoder.Decode(&state); err != nil {
		return gatewayPolicyDiskState{}, ErrGatewayPolicy
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		return gatewayPolicyDiskState{}, ErrGatewayPolicy
	}
	return state, nil
}

func marshalGatewayPolicyDiskState(envelope GatewayPolicyEnvelope, observedAt time.Time) ([]byte, error) {
	return marshalGatewayPolicyState(envelope, observedAt, 0, nil)
}
func marshalGatewayPolicyState(envelope GatewayPolicyEnvelope, observedAt time.Time, version int, installation *gatewayPolicyInstallation) ([]byte, error) {
	if !canonicalGatewayTime(observedAt) {
		return nil, ErrGatewayPolicy
	}
	bytesValue, err := json.Marshal(gatewayPolicyDiskState{Version: version, Installation: cloneGatewayInstallation(installation), Envelope: cloneGatewayPolicyEnvelope(envelope), ObservedAt: observedAt})
	if err != nil || len(bytesValue) > maximumGatewayPolicyDiskBytes {
		return nil, ErrGatewayPolicy
	}
	return bytesValue, nil
}

func readGatewayPolicyRoot(root *os.Root, name string) ([]byte, error) {
	if root == nil || name == "" {
		return nil, ErrGatewayPolicy
	}
	before, err := root.Lstat(name)
	if errors.Is(err, os.ErrNotExist) {
		return nil, os.ErrNotExist
	}
	if err != nil || !before.Mode().IsRegular() || before.Mode().Perm() != 0o600 || before.Size() < 2 || before.Size() > maximumGatewayPolicyDiskBytes {
		return nil, ErrGatewayPolicy
	}
	file, err := root.Open(name)
	if err != nil {
		return nil, ErrGatewayPolicy
	}
	defer file.Close()
	opened, err := file.Stat()
	if err != nil || !os.SameFile(before, opened) || !opened.Mode().IsRegular() || opened.Mode().Perm() != 0o600 {
		return nil, ErrGatewayPolicy
	}
	after, err := root.Lstat(name)
	if err != nil || !os.SameFile(opened, after) || after.Mode()&os.ModeSymlink != 0 {
		return nil, ErrGatewayPolicy
	}
	raw, err := io.ReadAll(io.LimitReader(file, maximumGatewayPolicyDiskBytes+1))
	if err != nil || len(raw) > maximumGatewayPolicyDiskBytes {
		return nil, ErrGatewayPolicy
	}
	return raw, nil
}

func writeGatewayPolicyRoot(root *os.Root, name string, envelope GatewayPolicyEnvelope, observedAt time.Time) error {
	bytesValue, err := marshalGatewayPolicyDiskState(envelope, observedAt)
	if err != nil {
		return ErrGatewayPolicy
	}
	return writeGatewayPolicyBytesRoot(root, name, bytesValue)
}
func writeGatewayPolicyBytesRoot(root *os.Root, name string, bytesValue []byte) (result error) {
	if root == nil || name == "" {
		return ErrGatewayPolicy
	}
	if info, statErr := root.Lstat(name); statErr == nil {
		if !info.Mode().IsRegular() || info.Mode().Perm() != 0o600 {
			return ErrGatewayPolicy
		}
	} else if !errors.Is(statErr, os.ErrNotExist) {
		return ErrGatewayPolicy
	}
	temporaryName, err := gatewayPolicyTemporaryName()
	if err != nil {
		return ErrGatewayPolicy
	}
	temporary, err := root.OpenFile(temporaryName, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		return ErrGatewayPolicy
	}
	defer func() {
		_ = temporary.Close()
		if result != nil {
			_ = root.Remove(temporaryName)
		}
	}()
	if _, err := temporary.Write(bytesValue); err != nil {
		return ErrGatewayPolicy
	}
	if err := temporary.Sync(); err != nil {
		return ErrGatewayPolicy
	}
	if err := temporary.Close(); err != nil {
		return ErrGatewayPolicy
	}
	if err := root.Rename(temporaryName, name); err != nil {
		return ErrGatewayPolicy
	}
	directoryFile, err := root.Open(".")
	if err != nil {
		return ErrGatewayPolicy
	}
	defer directoryFile.Close()
	if err := directoryFile.Sync(); err != nil {
		return ErrGatewayPolicy
	}
	// Emission is permitted only after the completed fsync/rename/directory
	// fsync sequence and an exact readback through the pinned parent.
	readback, err := readGatewayPolicyRoot(root, name)
	if err != nil || !bytes.Equal(readback, bytesValue) {
		return ErrGatewayPolicy
	}
	return nil
}

func openGatewayPolicyRoot(path string) (*os.Root, string, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return nil, "", ErrGatewayPolicy
	}
	name := filepath.Base(path)
	if name == "." || name == string(filepath.Separator) {
		return nil, "", ErrGatewayPolicy
	}
	root, err := os.OpenRoot(string(filepath.Separator))
	if err != nil {
		return nil, "", ErrGatewayPolicy
	}
	directory := filepath.Dir(path)
	relative, err := filepath.Rel(string(filepath.Separator), directory)
	if err != nil {
		root.Close()
		return nil, "", ErrGatewayPolicy
	}
	if relative == "." {
		return root, name, nil
	}
	for _, component := range splitGatewayPath(relative) {
		before, statErr := root.Lstat(component)
		if statErr != nil || !before.IsDir() || before.Mode()&os.ModeSymlink != 0 {
			root.Close()
			return nil, "", ErrGatewayPolicy
		}
		child, openErr := root.OpenRoot(component)
		if openErr != nil {
			root.Close()
			return nil, "", ErrGatewayPolicy
		}
		opened, openStatErr := child.Stat(".")
		after, afterErr := root.Lstat(component)
		root.Close()
		if openStatErr != nil || afterErr != nil || !os.SameFile(before, opened) || !os.SameFile(opened, after) || after.Mode()&os.ModeSymlink != 0 {
			child.Close()
			return nil, "", ErrGatewayPolicy
		}
		root = child
	}
	return root, name, nil
}

func splitGatewayPath(path string) []string {
	if path == "." || path == "" {
		return nil
	}
	return strings.Split(path, string(filepath.Separator))
}

func gatewayPolicyTemporaryName() (string, error) {
	var bytesValue [16]byte
	if _, err := rand.Read(bytesValue[:]); err != nil {
		return "", ErrGatewayPolicy
	}
	return ".zasp-gateway-policy-" + hex.EncodeToString(bytesValue[:]), nil
}

func validGatewayBinding(value GatewayPolicyBinding) bool {
	for _, text := range []string{value.OrganizationID, value.WorkspaceID, value.EnvironmentID, value.DeviceID} {
		if _, err := domain.ParseProductID(text); err != nil {
			return false
		}
	}
	return value.OrganizationID != value.WorkspaceID && value.OrganizationID != value.EnvironmentID && value.OrganizationID != value.DeviceID &&
		value.WorkspaceID != value.EnvironmentID && value.WorkspaceID != value.DeviceID && value.EnvironmentID != value.DeviceID
}

func canonicalGatewayTime(value time.Time) bool {
	return !value.IsZero() && value.Location() == time.UTC && value.Nanosecond() == 0
}

func gatewayNow(now func() time.Time) (time.Time, bool) {
	defer func() { _ = recover() }()
	value := now()
	return value, canonicalGatewayTime(value)
}

func laterGatewayTime(left, right time.Time) time.Time {
	if right.After(left) {
		return right
	}
	return left
}

func cloneGatewayPolicyEnvelope(value GatewayPolicyEnvelope) GatewayPolicyEnvelope {
	policies := value.Policies
	value.Policies = make([]CompiledPolicy, len(policies))
	for index, policy := range policies {
		value.Policies[index] = cloneCompiledPolicy(policy)
	}
	return value
}

func cloneCompiledPolicy(value CompiledPolicy) CompiledPolicy {
	value.Conditions = append([]Condition(nil), value.Conditions...)
	return value
}

func equalGatewayEnvelope(left, right GatewayPolicyEnvelope) bool {
	leftBytes, leftErr := json.Marshal(cloneGatewayPolicyEnvelope(left))
	rightBytes, rightErr := json.Marshal(cloneGatewayPolicyEnvelope(right))
	return leftErr == nil && rightErr == nil && bytes.Equal(leftBytes, rightBytes)
}

func equalGatewayPolicySemantics(left, right GatewayPolicyEnvelope) bool {
	leftBytes, leftErr := json.Marshal(struct {
		FailureMode string           `json:"failure_mode"`
		Policies    []CompiledPolicy `json:"policies"`
	}{FailureMode: left.FailureMode, Policies: left.Policies})
	rightBytes, rightErr := json.Marshal(struct {
		FailureMode string           `json:"failure_mode"`
		Policies    []CompiledPolicy `json:"policies"`
	}{FailureMode: right.FailureMode, Policies: right.Policies})
	return leftErr == nil && rightErr == nil && bytes.Equal(leftBytes, rightBytes)
}
