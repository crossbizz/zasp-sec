package migrations

import (
 "os"
 "path/filepath"
 "testing"
)

// Diagnostic compiler extraction only. This is not installer/native/SQL execution.
func TestGatewayInstallationEmitCompiledSQLForGrammarDiagnostic(t *testing.T) {
 if os.Getenv("ZASP_GATEWAY_INSTALLATION_EMIT_COMPILED_SQL") != "1" {
  t.Fatal("explicit compiler extraction diagnostic opt-in required")
 }
 const output = "/tmp/gateway-ack-connected-evidence-20261017"
 for _, selected := range []struct{name string; audit bool}{{"normal", false}, {"audit", true}} {
  source, pin := compiledGatewayInstallationSource(selected.audit)
  if source == "" || !IsGatewayInstallationProfileChecksum(pin) { t.Fatal("compiled source identity unavailable") }
  if err := os.WriteFile(filepath.Join(output,"gateway-installation-compiled-"+selected.name+".sql"), []byte(source),0600); err != nil {t.Fatal("compiled SQL diagnostic output refused")}
  if err := os.WriteFile(filepath.Join(output,"gateway-installation-compiled-"+selected.name+".profile-pin"), []byte(pin+"\n"),0600); err != nil {t.Fatal("compiled pin diagnostic output refused")}
 }
}
