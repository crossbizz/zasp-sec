// Package gatewayinstallationwire defines authenticated gateway installation testimony.
package gatewayinstallationwire

import (
	"errors"
	"time"
)

const ObservationSchema = "gateway-policy-installation-v1"
const ReceiptSchema = "gateway-policy-installation-receipt-v1"
const MaximumBytes = 4096

var ErrInvalid = errors.New("invalid gateway installation wire")

type Observation struct {
	Schema               string    `json:"schema"`
	CredentialGeneration uint64    `json:"credential_generation"`
	ContractVersion      int       `json:"contract_version"`
	KeyID                string    `json:"key_id"`
	Algorithm            string    `json:"algorithm"`
	Audience             string    `json:"audience"`
	Sequence             uint64    `json:"sequence"`
	PolicyVersion        uint64    `json:"policy_version"`
	IssuedAt             time.Time `json:"issued_at"`
	ExpiresAt            time.Time `json:"expires_at"`
	FailureMode          string    `json:"failure_mode"`
	PayloadDigest        string    `json:"payload_digest"`
	Signature            string    `json:"signature"`
	InstalledObservedAt  time.Time `json:"installed_observed_at"`
}
type Binding struct{ OrganizationID, WorkspaceID, EnvironmentID, DeviceID, CredentialID string }
type Receipt struct {
	Schema                            string    `json:"schema"`
	RequestSHA256                     string    `json:"request_sha256"`
	OrganizationID                    string    `json:"organization_id"`
	WorkspaceID                       string    `json:"workspace_id"`
	EnvironmentID                     string    `json:"environment_id"`
	DeviceID                          string    `json:"device_id"`
	CredentialID                      string    `json:"credential_id"`
	CredentialGeneration              uint64    `json:"credential_generation"`
	Disposition                       string    `json:"disposition"`
	RepresentativeSHA256              string    `json:"representative_sha256"`
	RepresentativeSequence            uint64    `json:"representative_sequence"`
	RepresentativeInstalledObservedAt time.Time `json:"representative_installed_observed_at"`
	RepresentativeRecordedAt          time.Time `json:"representative_recorded_at"`
}

func ParseObservation(raw []byte) (Observation, error)     { return Observation{}, ErrInvalid }
func MarshalObservation(value Observation) ([]byte, error) { return nil, ErrInvalid }
func ParseReceipt(raw []byte) (Receipt, error)             { return Receipt{}, ErrInvalid }
func MarshalReceipt(value Receipt) ([]byte, error)         { return nil, ErrInvalid }
func Digest(raw []byte) string                             { return "" }
func ValidateAt(value Observation, now time.Time) error    { return ErrInvalid }
func ReceiptMatches(receipt Receipt, observation Observation, requestSHA256 string, binding Binding) bool {
	return false
}
func RankCompare(sequence uint64, observed time.Time, digest string, otherSequence uint64, otherObserved time.Time, otherDigest string) int {
	return 0
}
