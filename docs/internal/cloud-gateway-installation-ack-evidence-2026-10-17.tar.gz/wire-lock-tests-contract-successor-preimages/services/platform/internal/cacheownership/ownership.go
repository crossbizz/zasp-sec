// Package cacheownership serializes cooperating processes sharing a logical cache path.
package cacheownership

import (
	"errors"
	"os"
	"runtime"
)

var ErrUnavailable = errors.New("cache ownership unavailable")

type Guard struct{}

func Supported() bool                                        { return runtime.GOOS == "linux" }
func Acquire(root *os.Root, basename string) (*Guard, error) { return nil, ErrUnavailable }
func (g *Guard) Close() error                                { return nil }
func (g *Guard) Valid() bool                                 { return false }
