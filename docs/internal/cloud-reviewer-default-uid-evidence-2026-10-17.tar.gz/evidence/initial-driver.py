import base64,hashlib,json,subprocess,time,uuid
from pathlib import Path
out=Path('/tmp/reviewer-default-uid-evidence-20261017');out.mkdir(exist_ok=False)
docker=['env','-u','DOCKER_HOST','-u','DOCKER_CONTEXT','-u','DOCKER_TLS','-u','DOCKER_TLS_VERIFY','-u','DOCKER_CERT_PATH','docker','--host=unix:///var/run/docker.sock']
def call(*args,input=None):return subprocess.run(docker+list(args),input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25,check=True)
image='sha256:dcc7436a6411b7287d9ac2de62e3ce569705ce1d681714b8e8332916ebb1d995'
helper='zasp/reviewer-provisioning-helper:component-ec877795'
owned='zasp-reviewer-uid-'+uuid.uuid4().hex[:12];volumes=[owned+'-source',owned+'-private'];cid=None
record={'qualification':'Local default-image UID65532 component with explicitly provisioned dedicated Docker volumes, synthetic JWTs and no network. Not Kubernetes, fsGroup, real TokenReview authentication, deployed workload, registry or attestation evidence.','image':image,'user_override':False,'volumes_removed':False}
def mountargs(readonly=False):
 return ['--mount','type=volume,src='+volumes[0]+',dst=/source'+(',readonly' if readonly else ''),'--mount','type=volume,src='+volumes[1]+',dst=/private']
def admin(script,input=None):return call('run','--rm','-i','--network','none','--read-only','--cap-drop','ALL','--cap-add','CHOWN','--cap-add','DAC_OVERRIDE','--security-opt','no-new-privileges=true',*mountargs(),helper,'sh','-ec',script,input=input)
def token(label):
 enc=lambda b:base64.urlsafe_b64encode(b).rstrip(b'=')
 return b'.'.join([enc(b'{"alg":"RS256"}'),enc(json.dumps({'exp':int(time.time())+3600,'fixture':label},separators=(',',':')).encode()),enc(b'synthetic-default-uid-component')])
def observe(expected):
 deadline=time.monotonic()+8
 while time.monotonic()<deadline:
  result=admin('if test -f /private/credential; then stat -c "%u:%g:%a:%h" /private/credential; sha256sum /private/credential; fi').stdout.decode().splitlines()
  if len(result)==2 and result[1].split()[0]==hashlib.sha256(expected).hexdigest():
   assert result[0]=='65532:65532:600:1',result[0];return result[0]
  time.sleep(.1)
 raise AssertionError('default UID publication deadline exceeded')
try:
 for name in volumes:call('volume','create',name)
 metadata=json.loads(call('image','inspect',image,'--format','{{json .Config}}').stdout)
 assert metadata['User']=='65532:65532'
 first=token('first');second=token('second')
 admin('chmod 755 /source; mkdir /source/..first; chmod 755 /source/..first; cat > /source/..first/token; chown 0:65532 /source/..first/token; chmod 440 /source/..first/token; ln -s ..first /source/..data; ln -s ..data/token /source/token; chown 65532:65532 /private; chmod 700 /private',first)
 cid=call('create','--name',owned,'--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges=true','--pids-limit','32','--memory','64m',*mountargs(True),image,'-source-directory','/source','-source-name','token','-destination-directory','/private','-poll-interval','250ms','-minimum-remaining-lifetime','5s').stdout.decode().strip()
 # Only selected non-secret settings, never container environment.
 config=json.loads(call('inspect',cid,'--format','{{json .HostConfig}}').stdout)
 assert config['ReadonlyRootfs'] and config['NetworkMode']=='none' and config['CapDrop']==['ALL']
 call('start',cid);record['initial_output_owner_mode_links']=observe(first)
 admin('mkdir /source/..second; chmod 755 /source/..second; cat > /source/..second/token; chown 0:65532 /source/..second/token; chmod 440 /source/..second/token; ln -s ..second /source/..next; mv -Tf /source/..next /source/..data',second)
 record['rotated_output_owner_mode_links']=observe(second)
 call('stop','--signal','SIGTERM','--timeout','5',cid)
 exitcode=int(call('wait',cid).stdout.decode());assert exitcode==0
 logs=call('logs',cid);assert not logs.stdout and not logs.stderr
 admin('test ! -e /private/credential; test ! -e /private/.credential.next; test "$(stat -c "%u:%g:%a" /private)" = 65532:65532:700')
 record.update(status='PASS',exit_code=exitcode,rotation_observed=True,owned_output_withdrawn=True,signal_shutdown_joined=True,network='none',read_only_rootfs=True,source_mount_read_only=True,capabilities_dropped='ALL',no_new_privileges=True)
except Exception as exc:
 record.update(status='FAIL',error_class=type(exc).__name__)
 raise
finally:
 if cid is not None:record['owned_container_removed']=subprocess.run(docker+['rm','--force',cid],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15).returncode==0
 removed=[]
 for name in volumes:removed.append(subprocess.run(docker+['volume','rm',name],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15).returncode==0)
 record['volumes_removed']=all(removed)
 (out/'actual-default-uid-component.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
