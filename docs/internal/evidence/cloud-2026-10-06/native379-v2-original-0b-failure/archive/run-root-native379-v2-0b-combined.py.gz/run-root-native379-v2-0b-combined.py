import ast,ctypes,hashlib,json,os,pathlib,signal,stat,subprocess,time,uuid
P=pathlib.Path
os.umask(0o077)
script=P('/workspace/.zasp-cloud-owned/native379-v2-combined-foundation-vg_j3yv2/prepare-frozen-source.py')
def checked(path,expected):
 assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==expected
checked(script,'26c1815e71ee125b9db9b88ebf96e18ad2dca3f5911983ba676ee0c8595e39e7')
full_review=P('/tmp/zasp-cloud-evidence/runtime-continuation/native379-v2-independent-actual-combined-frozen-envelope-review.json')
pg_review=P('/tmp/zasp-cloud-evidence/runtime-continuation/independent-provider-fresh0b-PG-static-review.json')
checked(full_review,'708d97d53de3cfa7f701707a547ce1cc5c9a20612b31ae0df9b0c0763ee985cf')
checked(pg_review,'b179d099aad696a11ae8dd4552976cdbfd6e70f05978c4fcc2ef804683b181e6')
base=P('/workspace/.zasp-cloud-owned/native379-v2-combined-foundation-vg_j3yv2');prep=base/'outputs/frozen-source-preparation'
checked(prep/'go-build-envelope-candidate.json','d0b9ab860927c940b3d143f751124ea8928cff1326e89fdb11b0de9d97a911d1')
checked(prep/'native379-v2-envelope-candidate.json','502673d7d471cf672b8dd7a84e52fd467a61d1dcba29cfc8af6c18d8bcc619e3')
checked(base/'bin/apiserver.test','4aa1f24d8c0a82af4e965aebf2952ed9c5c33760f8c4059b396d8c811b5cc719')
env=json.loads((prep/'environment.json').read_text())
assert set(env)==set('CGO_ENABLED GOARCH GOCACHE GOENV GOEXPERIMENT GOFLAGS GOMODCACHE GOOS GOPROXY GOROOT GOSUMDB GOTOOLCHAIN GOWORK HOME LANG PATH TMPDIR TZ'.split())
assert not any(k.startswith(('LD_','PG','ZASP_')) for k in env)
nonce=uuid.uuid4().hex;evidence=base/('outputs/native379-v2-root-attempt-0b-combined-'+nonce);evidence.mkdir(mode=0o700)
env.update(ZASP_ORDERED_CURRENT_NATIVE379_V2='1',ZASP_ORDERED_CURRENT_NATIVE379_V2_BUILD=str(prep/'native379-v2-envelope-candidate.json'),ZASP_ORDERED_CURRENT_NATIVE379_V2_BUILD_SHA256='502673d7d471cf672b8dd7a84e52fd467a61d1dcba29cfc8af6c18d8bcc619e3',ZASP_ORDERED_CURRENT_NATIVE379_V2_OUTPUT=str(evidence/'native-result.json'))
assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
records=[]
tree=ast.parse(script.read_text());defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['sha','write']]
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');run=next(n for n in ast.walk(main) if isinstance(n,ast.FunctionDef) and n.name=='run')
exec(compile(ast.fix_missing_locations(ast.Module(body=defs+[run],type_ignores=[])),str(script),'exec'))
write(evidence/'closed-environment.json',env)
write(evidence/'root-launch-binding.json',{'source_commit':'0b788520159170a825a925a3f639b0b1d63169f5','nonce':nonce,'GoEnvelopeSHA256':'d0b9ab860927c940b3d143f751124ea8928cff1326e89fdb11b0de9d97a911d1','V2EnvelopeSHA256':env['ZASP_ORDERED_CURRENT_NATIVE379_V2_BUILD_SHA256'],'independent_full_review_sha256':sha(full_review),'independent_PG_review_sha256':sha(pg_review),'supervisor_sha256':sha(script),'scope':'root-owned bounded local native attempt; no product/provider authorization'})
try:
 run('actual-native379',[str(base/'bin/apiserver.test'),'-test.run=^TestP7OrderedCurrentIntegrityNativeV2$','-test.count=1','-test.v','-test.timeout=15m'],base/'module-cache/owned-source/services/platform/apiserver',seconds=930)
except RuntimeError:
 print(json.dumps({'supervisor_completed':True,'result_exists':(evidence/'native-result.json').exists(),'evidence':str(evidence),'record':records[-1]}),flush=True)
 raise SystemExit(records[-1]['exit_code'] or 1)
print(json.dumps({'supervisor_completed':True,'result_exists':(evidence/'native-result.json').exists(),'evidence':str(evidence),'record':records[-1]}),flush=True)
