package main
import (
 "context"
 "strings"
 "testing"
 "time"
 "github.com/zasp-ai/zasp-sec/services/platform/apiserver"
 "github.com/zasp-ai/zasp-sec/services/platform/migrations"
)
func TestPrivateColdFactoriesTiming(t *testing.T) {
 start:=time.Now(); checksum:=migrations.ProductionAuthorizationEnforcement().Checksum();first:=time.Since(start)
 start=time.Now();audit:=migrations.AuthorizationAuditProfileChecksum();second:=time.Since(start)
 start=time.Now();same:=migrations.AuthorizationAuditProfileChecksum()==audit;warm:=time.Since(start)
 t.Logf("stage=enforcement_factory duration=%s checksum_length=%d",first,len(checksum))
 t.Logf("stage=audit_profile_cold duration=%s checksum_length=%d",second,len(audit))
 t.Logf("stage=audit_profile_warm duration=%s stable=%t",warm,same)
}
type privateTimingDriver struct { *runtimeAuthorizationProbeDriver; start time.Time; queryDuration time.Duration; queryContextErr error }
func (d *privateTimingDriver) QueryRow(ctx context.Context,q string,args ...any) apiserver.PostgresRow {
 d.queryDuration=time.Since(d.start);d.queryContextErr=ctx.Err()
 return d.runtimeAuthorizationProbeDriver.QueryRow(ctx,q,args...)
}
func TestPrivateColdThenWarmCallbackTiming(t *testing.T) {
 key:=strings.Repeat("a",64)
 coreD:=&privateTimingDriver{runtimeAuthorizationProbeDriver:&runtimeAuthorizationProbeDriver{t:t,role:"zasp_discovery_api",key:key}}
 agentD:=&privateTimingDriver{runtimeAuthorizationProbeDriver:&runtimeAuthorizationProbeDriver{t:t,role:"zasp_security_agent_api",key:key}}
 core,_:=apiserver.NewPostgresJSONDatabase(coreD);agent,_:=apiserver.NewPostgresJSONDatabase(agentD);defer core.Close();defer agent.Close()
 start:=time.Now();if core.RequireCurrentAuthorization()!=nil||agent.RequireCurrentAuthorization()!=nil {t.Fatal("activation")};t.Logf("stage=activation duration=%s",time.Since(start))
 services,previous:=0,0
 callback:=authorizationRuntimeReadiness(func(context.Context)error{services++;return nil},func(context.Context)error{previous++;return nil},core,agent,key,time.Second)
 for _,name:=range []string{"cold","warm"} {
  coreD.calls=0;agentD.calls=0;services=0;previous=0
  start=time.Now();coreD.start=start;agentD.start=start;err:=callback(context.Background())
  t.Logf("stage=%s_callback duration=%s error=%v services=%d core=%d agent=%d previous=%d core_query_elapsed=%s core_query_context_error=%v",name,time.Since(start),err,services,coreD.calls,agentD.calls,previous,coreD.queryDuration,coreD.queryContextErr)
 }
}
