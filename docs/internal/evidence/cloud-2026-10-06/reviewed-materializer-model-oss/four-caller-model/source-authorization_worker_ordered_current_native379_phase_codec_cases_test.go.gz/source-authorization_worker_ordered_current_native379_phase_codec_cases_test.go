package apiserver

import (
 "bytes"
 "context"
 "compress/gzip"
 "crypto/sha256"
 "errors"
 "encoding/binary"
 "encoding/json"
 "fmt"
 "io"
 "os"
 "path/filepath"
 "reflect"
 "strings"
 "testing"
 "time"
)
func native379PhaseCodecUnit(t *testing.T)(native379PhaseCodecSpec,[][]native379PhaseCodecRecord) {
 t.Helper();ctx,cancel:=context.WithTimeout(context.Background(),time.Second);t.Cleanup(cancel)
 records:=[][]native379PhaseCodecRecord{{{Kind:1,Rows:1,Key:"fact:0",Value:json.RawMessage(`{"identity":"example","value":null}`)},{Kind:5,Rows:0,Key:"receipt:0",Value:json.RawMessage(`{"kind":"scripted-component-only"}`)}}}
 spec:=native379PhaseCodecSpec{PacketSHA256:strings.Repeat("1",64),MaxRows:10,MaxBytes:100000,Context:ctx,Phases:[]native379PhaseCodecPhase{{ID:"pristine-truth",MaxRows:10,MaxBytes:100000,MaxMilliseconds:1000,Keys:[]string{"fact:0","receipt:0"},Context:ctx}}}
 return spec,records
}
func TestNative379PhaseCodecRoundtripAndExactCosts(t *testing.T) {
 spec,records:=native379PhaseCodecUnit(t)
 encoded,cost,err:=native379PhaseCodecEncode(spec,records);if err!=nil { t.Fatal(err) }
 decoded,replay,err:=native379PhaseCodecDecode(spec,encoded);if err!=nil || !reflect.DeepEqual(records,decoded) || !reflect.DeepEqual(cost,replay) { t.Fatal("complete preimage/cost roundtrip",err) }
 values:=uint64(len(records[0][0].Value)+len(records[0][1].Value))
 framing:=uint64(16+len(records[0][0].Key)+len(records[0][1].Key))
 if cost.Total.Rows!=1 || cost.Total.CanonicalValueBytes!=values || cost.Total.ExpandedBytes!=values+framing || cost.Total.EncodedBytes!=uint64(len(encoded)) || cost.Total.ChargedBytes!=values+framing+uint64(len(encoded)) { t.Fatal("encoded/expanded framing silently discounted") }
 reencoded,_,err:=native379PhaseCodecEncode(spec,decoded);if err!=nil || !bytes.Equal(encoded,reencoded) { t.Fatal("fixed codec changed complete evidence",err) }
}
func TestNative379PhaseCodecClosedFraming(t *testing.T) {
 spec,records:=native379PhaseCodecUnit(t);encoded,_,err:=native379PhaseCodecEncode(spec,records);if err!=nil { t.Fatal(err) }
 start:=50+1+len(spec.Phases[0].ID);gzipStart:=start+48
 for _,kind:=range []string{"version","packet","phase-count","phase-id","record-count","length","hash","codec-header","crc","truncated","trailing","additional-member","oversize"} {
  t.Run(kind,func(t *testing.T){
   changed:=append([]byte(nil),encoded...)
   switch kind {
   case "version":changed[15]++
   case "packet":changed[16]++
   case "phase-count":changed[49]++
   case "phase-id":changed[51]='x'
   case "record-count":changed[start+3]++
   case "length":binary.BigEndian.PutUint64(changed[start+4:start+12],100000000)
   case "hash":changed[start+16]++
   case "codec-header":changed[gzipStart+3]=8
   case "crc":changed[len(changed)-8]++
   case "truncated":changed=changed[:len(changed)-1]
   case "trailing":changed=append(changed,0)
   case "additional-member":member:=append([]byte(nil),changed[gzipStart:]...);changed=append(changed,member...);binary.BigEndian.PutUint32(changed[start+12:start+16],uint32(len(changed)-gzipStart))
   case "oversize":changed=make([]byte,native379PhaseCodecCap+1)
   }
   if _,_,err:=native379PhaseCodecDecode(spec,changed);err==nil { t.Fatal("unknown/noncomplete framing accepted") }
  })
 }
 for _,kind:=range []string{"unknown-kind","row-kind","key","duplicate-key","duplicate-json","noncanonical","null-absent"} {
  changed:=[][]native379PhaseCodecRecord{append([]native379PhaseCodecRecord(nil),records[0]...)};local:=spec;local.Phases=append([]native379PhaseCodecPhase(nil),spec.Phases...)
  switch kind {
  case "unknown-kind":changed[0][0].Kind=99
  case "row-kind":changed[0][0].Rows=0
  case "key":changed[0][0].Key="borrowed"
  case "duplicate-key":local.Phases[0].Keys=[]string{"fact:0","fact:0"}
  case "duplicate-json":changed[0][0].Value=json.RawMessage(`{"k":1,"k":2}`)
  case "noncanonical":changed[0][0].Value=json.RawMessage(`{"z":0,"a":0}`)
  case "null-absent":changed[0][0].Value=nil
  }
  if _,_,err:=native379PhaseCodecEncode(local,changed);err==nil { t.Fatal("nonclosed record admitted",kind) }
 }
}
func TestNative379PhaseCodecBudgetAndCancellation(t *testing.T) {
 spec,records:=native379PhaseCodecUnit(t);encoded,cost,err:=native379PhaseCodecEncode(spec,records);if err!=nil { t.Fatal(err) }
 for _,kind:=range []string{"phase-byte","global-byte","phase-row","global-row","cancel","expired","missing-deadline"} {
  local:=spec;local.Phases=append([]native379PhaseCodecPhase(nil),spec.Phases...)
  switch kind {
  case "phase-byte":local.Phases[0].MaxBytes=cost.Total.ChargedBytes-1
  case "global-byte":local.MaxBytes=cost.Total.ChargedBytes-1;local.Phases[0].MaxBytes=local.MaxBytes
  case "phase-row":local.Phases[0].MaxRows=0
  case "global-row":local.MaxRows=0
  case "cancel":ctx,stop:=context.WithCancel(spec.Context);stop();local.Context=ctx
  case "expired":ctx,stop:=context.WithDeadline(context.Background(),time.Now().Add(-time.Second));defer stop();local.Context=ctx
  case "missing-deadline":local.Context=context.Background()
  }
  if _,_,err:=native379PhaseCodecEncode(local,records);err==nil { t.Fatal("encode budget/context refusal lost",kind) }
  if _,_,err:=native379PhaseCodecDecode(local,encoded);err==nil { t.Fatal("decode budget/context refusal lost",kind) }
 }
 // A highly compressible expanded value still consumes its full raw bytes.
 records[0][0].Value=json.RawMessage(`{"payload":"`+strings.Repeat("a",20000)+`"}`)
 spec.Phases[0].MaxBytes=10000
 if _,_,err:=native379PhaseCodecEncode(spec,records);err==nil { t.Fatal("compression discounted expanded preimage") }
}
func TestNative379PhaseCodecOwnedPublication(t *testing.T) {
 spec,records:=native379PhaseCodecUnit(t);encoded,_,err:=native379PhaseCodecEncode(spec,records);if err!=nil { t.Fatal(err) }
 destination:=filepath.Join(t.TempDir(),"component.phase4")
 digest,err:=native379PhaseCodecPublish(spec,destination,encoded);if err!=nil || digest!=orderedCurrentNative379V3SHA256(encoded) { t.Fatal("owned atomic publication",err) }
 preserved,_:=os.ReadFile(destination)
 if next,err:=native379PhaseCodecPublish(spec,destination,encoded);err==nil || next!="" { t.Fatal("existing destination replaced") }
 after,_:=os.ReadFile(destination);if !bytes.Equal(preserved,after) { t.Fatal("exclusive destination changed") }
 bad:=append([]byte(nil),encoded...);bad[0]++
 other:=filepath.Join(t.TempDir(),"bad.phase4")
 if digest,err:=native379PhaseCodecPublish(spec,other,bad);err==nil || digest!="" { t.Fatal("invalid artifact published") }
 if _,err:=os.Lstat(other);!os.IsNotExist(err) { t.Fatal("refused artifact left acceptance file") }
 ctx,stop:=context.WithCancel(spec.Context);stop();spec.Context=ctx
 if digest,err:=native379PhaseCodecPublish(spec,other,encoded);err==nil || digest!="" { t.Fatal("canceled publication accepted") }
}

// Complete source-driven raw ledger MODEL. Scripted snapshots, completion and
// elapsed=0 are not observations. Source programs are unchanged and bound by
// the exact packet digest. Full adapter/outcome/recovery schema remains open.
func native379PhaseCodecResolveModel(value any,user string,pid int32) any {
 switch x:=value.(type) {
 case map[string]any:
  if binding,ok:=x["binding"];ok && len(x)==1 { if binding=="owned-session-user" { return user };return pid }
  copy:=map[string]any{};for k,v:=range x { copy[k]=native379PhaseCodecResolveModel(v,user,pid) };return copy
 case []any:
  copy:=make([]any,len(x));for i,v:=range x { copy[i]=native379PhaseCodecResolveModel(v,user,pid) };return copy
 };return value
}
func native379PhaseCodecModel(t *testing.T,packet orderedCurrentNative379V3Packet,sha,user string,pid int32)(native379PhaseCodecSpec,[][]native379PhaseCodecRecord) {
 t.Helper();ctx,stop:=context.WithTimeout(context.Background(),90*time.Second);t.Cleanup(stop)
 spec:=native379PhaseCodecSpec{PacketSHA256:sha,MaxRows:uint64(packet.Limits.MaxRows),MaxBytes:uint64(packet.Limits.MaxBytes),Context:ctx}
 records:=make([][]native379PhaseCodecRecord,len(packet.Phases));for i:=range records { records[i]=[]native379PhaseCodecRecord{} };phaseIndex:=map[string]int{}
 for i,p:=range packet.Phases { phaseCtx,cancel:=context.WithTimeout(ctx,time.Duration(p.Limits.MaxMilliseconds)*time.Millisecond);t.Cleanup(cancel);phaseIndex[p.ID]=i;spec.Phases=append(spec.Phases,native379PhaseCodecPhase{ID:p.ID,MaxRows:uint64(p.Limits.MaxRows),MaxBytes:uint64(p.Limits.MaxBytes),MaxMilliseconds:int64(p.Limits.MaxMilliseconds),Context:phaseCtx}) }
 put:=func(phase string,kind,rows byte,key string,value any) { encoded,err:=orderedCurrentNative379V3CanonicalJSONFromValue(value);if err!=nil { t.Fatal(err) };i,ok:=phaseIndex[phase];if !ok { t.Fatal("source phase absent") };records[i]=append(records[i],native379PhaseCodecRecord{Kind:kind,Rows:rows,Key:key,Value:encoded});spec.Phases[i].Keys=append(spec.Phases[i].Keys,key) }
 routines,err:=orderedCurrentNative379V3ExpectedRoutines(packet);if err!=nil { t.Fatal(err) }
 for _,fixed:=range []struct{key string;value any}{{"preinstall",[]any{packet.Identity.ServerVersionNum,packet.Identity.Postgres,packet.Identity.Pgcrypto,"127.0.0.1",5432,0,0}},{"inventory",[]any{"zasp_discovery_authority",[]string{"zasp_authorization80_ordered_current.expected","zasp_authorization80_ordered_current.registration"},routines,1,len(packet.ExpectedFacts),0}},{"frame-before",[]string{user,user,"pg_catalog","UTC","off","read committed"}},{"frame-after",[]string{user,user,"pg_catalog","UTC","off","read committed"}},{"admission",true},{"catalog",true}} { put("pristine-truth",2,1,"fixed:"+fixed.key,fixed.value) }
 for i,fact:=range packet.ExpectedFacts { put("pristine-truth",1,1,fmt.Sprintf("fact:%d",i),map[string]any{"kind":fact.Kind,"identity":fact.Identity,"fact":fact.Fact}) }
 for _,control:=range packet.Controls {
  bootstrap:=native379CompactBootstrapFor(control.ID,user,pid);put(control.Phase,3,1,control.ID+":bootstrap",bootstrap)
  for index,step:=range control.Program.Steps {
   placement,role,err:=native379V3RolePlacement(control,index);if err!=nil { t.Fatal(err) }
   if placement!="before-poison" {
    receipt:=native379CompactReceiptFor(bootstrap,step,placement,role,0)
    put(control.Phase,5,0,control.ID+":"+step.ID+":assertion",receipt)
    // Model v2 retains the genuine bootstrap and assertion receipt once.
    // Exact original Marshal parameter preimage is reconstructed and checked;
    // it is not an independently observed output row or optional second copy.
    if _,err:=native379PhaseCodecReconstructModelParameters(bootstrap,receipt,control,index,user,pid);err!=nil { t.Fatal("exact source/owned binding parameter reconstruction",err) }
   }
   state:="00000";if step.Expected.SQLState!=nil { state=*step.Expected.SQLState }
   var value any=map[string]any{"sqlState":state}
   switch step.Expected.Outcome {
   case "capture","equal-captured":value=[]any{map[string]any{"snapshot":"mock-"+step.Expected.Key}}
   case "rows":source,err:=orderedCurrentNative379V3DecodeExpected(step.Expected.Rows);if err!=nil { t.Fatal(err) };value=native379PhaseCodecResolveModel(source,user,pid)
   case "one-row","one-json-row":source,err:=orderedCurrentNative379V3DecodeExpected(step.Expected.Value);if err!=nil { t.Fatal(err) };value=[]any{map[string]any{"value":native379PhaseCodecResolveModel(source,user,pid)}}
   }
   if output,ok:=value.([]any);ok { for i,row:=range output { put(control.Phase,4,1,fmt.Sprintf("%s:%s:row:%d",control.ID,step.ID,i),row) } } else { put(control.Phase,7,0,control.ID+":"+step.ID+":status",value) }
  }
 }
 return spec,records
}
func native379PhaseCodecFullSourceCostModel(t *testing.T, users []string) {
 path:=os.Getenv("ZASP_NATIVE379_PHASE_CODEC_SOURCE_PACKET")
 if path=="" { t.Fatal("explicit source-only pinned packet path required for this selected cost group") }
 info,statErr:=os.Lstat(path);if statErr!=nil || !info.Mode().IsRegular() || info.Size()>33554432 { t.Fatal("bounded regular source packet required") }
 source,openErr:=os.Open(path);if openErr!=nil { t.Fatal("source packet unavailable") }
 raw,err:=io.ReadAll(io.LimitReader(source,33554433));closeErr:=source.Close();if err!=nil || closeErr!=nil || len(raw)>33554432 { t.Fatal("bounded source packet unavailable") }
 const expectedSHA="41141f2ed08cfaee0bfea75dd11152c95d898a625a5f0d87f1f1b65be939d035"
 admission,err:=native379V3AdmitReviewedRaw(raw,expectedSHA);if err!=nil { t.Fatal("pinned source packet refused",err) };packet:=admission.packet
 steps:=0;for _,control:=range packet.Controls { steps+=len(control.Program.Steps) }
 if len(packet.Controls)!=589 || steps!=6348 || len(packet.Rules)!=379 || len(packet.ExpectedFacts)!=10052 || len(packet.SourceInventory.Sites)!=565 { t.Fatal("complete original source census changed") }
 for _,user:=range users {
  if user!="zasp_test" && len([]byte(user))!=63 { t.Fatal("model caller is not an actual legal63-byte fixture") }
  spec,records:=native379PhaseCodecModel(t,packet,expectedSHA,user,2147483647)
  rows:=uint64(0);preimages:=0;canonicalBytes:=uint64(0);expandedBytes:=uint64(0)
  requiredRows,rowErr:=native379V3PhysicalRowCosts(packet);if rowErr!=nil { t.Fatal(rowErr) }
  for index,phase:=range records {
   phaseRows:=uint64(0);phaseCanonical:=uint64(0);phaseExpanded:=uint64(0)
   for _,record:=range phase { phaseRows+=uint64(record.Rows);preimages++;phaseCanonical+=uint64(len(record.Value));phaseExpanded+=uint64(8+len(record.Key)+len(record.Value)) }
   if phaseRows!=uint64(requiredRows[spec.Phases[index].ID]) { t.Fatal("source-model physical row conservation differs") }
   rows+=phaseRows;canonicalBytes+=phaseCanonical;expandedBytes+=phaseExpanded
   t.Logf("SCRIPTED phase=%s rows=%d canonicalBytes=%d expandedBytes=%d originalByteCap=%d; encoded overhead not yet included",spec.Phases[index].ID,phaseRows,phaseCanonical,phaseExpanded,spec.Phases[index].MaxBytes)
  }
  t.Logf("SCRIPTED complete source raw-ledger model: userUTF8Bytes=%d controls=589 steps=6348 rows=%d records=%d canonicalBytes=%d expandedBytesWithRecordFraming=%d; modelVersion=2 exact reconstructed parameters; optional duplicate arrays absent; no full-result metadata or native observations",len([]byte(user)),rows,preimages,canonicalBytes,expandedBytes)
  encoded,cost,err:=native379PhaseCodecEncode(spec,records)
  if err!=nil { if !errors.Is(err,native379PhaseCodecBoundRefused) { t.Fatal("unexpected source/schema/codec/context error; NOT budget evidence",err) };t.Logf("SCRIPTED encoded-fit NOT demonstrated: typed unchanged row/byte cap refused; no compression ratio or native acceptance inferred. completedPhases=%d",len(cost.Phases));continue }
  decoded,replayed,err:=native379PhaseCodecDecode(spec,encoded)
  if err!=nil { t.Fatal("complete source decoder refused",err) }
  if !reflect.DeepEqual(records,decoded) { t.Fatal("complete source record projection differs") }
  if !reflect.DeepEqual(cost,replayed) { t.Fatal("complete source cost projection differs") }
  if len(encoded)>native379PhaseCodecCap { t.Fatal("complete source encoded capacity differs") }
  t.Logf("SCRIPTED RAW-LEDGER ONLY encodedBytes=%d chargedBytes=%d; not full result/adapter/native acceptance",len(encoded),cost.Total.ChargedBytes)
 }
 // Historical full JSON publisher retains its original refusal and schema.
 result:=orderedCurrentNative379V3Result{Format:"ordered-current-native379-result-v3"}
 for _,fact:=range packet.ExpectedFacts { value,_:=orderedCurrentNative379V3CanonicalJSONFromValue(map[string]any{"kind":fact.Kind,"identity":fact.Identity,"fact":fact.Fact});result.Budget.Charges=append(result.Budget.Charges,native379V3BudgetCharge{Phase:"pristine-truth",Rows:1,Value:value}) }
 destination:=filepath.Join(t.TempDir(),"old-full-result.json")
 if publishOrderedCurrentNative379V3Result(destination,result,orderedCurrentNative379V3MaxResultBytes)==nil { t.Fatal("old fullresult cap silently relaxed") }
 if _,err:=os.Lstat(destination);!os.IsNotExist(err) { t.Fatal("old oversized result published") }
}

func TestNative379PhaseCodecValueBoundBeforeAllocation(t *testing.T) {
 spec,_:=native379PhaseCodecUnit(t)
 spec.MaxBytes=85983232;spec.Phases[0].MaxBytes=85983232;spec.Phases[0].Keys=[]string{"fact:0"}
 // Tiny actual member with oversized DECLARED value. Allocation callback makes
 // the preallocation boundary observable without allocating32MiB in the test.
 body:=[]byte{1,1,0,6,0,0,0,0};binary.BigEndian.PutUint32(body[4:8],33554433);body=append(body,[]byte("fact:0null")...)
 var compressed bytes.Buffer;gz,err:=gzip.NewWriterLevel(&compressed,gzip.BestSpeed);if err!=nil { t.Fatal(err) };gz.Write(body);if gz.Close()!=nil { t.Fatal("fixture compressor close") }
 var artifact bytes.Buffer;artifact.Write(native379PhaseCodecMagic[:]);artifact.Write(bytes.Repeat([]byte{0x11},32));binary.Write(&artifact,binary.BigEndian,uint16(1));artifact.WriteByte(byte(len(spec.Phases[0].ID)));artifact.WriteString(spec.Phases[0].ID);binary.Write(&artifact,binary.BigEndian,uint32(1));binary.Write(&artifact,binary.BigEndian,uint64(8+6+33554433));binary.Write(&artifact,binary.BigEndian,uint32(compressed.Len()));sum:=sha256.Sum256(body);artifact.Write(sum[:]);artifact.Write(compressed.Bytes())
 calls:=0
 _,_,err=native379PhaseCodecDecodeWithAllocator(spec,artifact.Bytes(),func(length int)[]byte{calls++;return nil})
 if err==nil || calls!=0 { t.Fatal("oversized value reached allocation before closed value bound") }
}
func TestNative379PhaseCodecCheckedOwnedTemporaryCleanup(t *testing.T) {
 spec,records:=native379PhaseCodecUnit(t);encoded,_,err:=native379PhaseCodecEncode(spec,records);if err!=nil { t.Fatal(err) }
 destination:=filepath.Join(t.TempDir(),"refused.phase4");calls:=0
 // Genuine tiny owned filesystem fault: rename the temporary before removing
 // its original path, causing actual os.Remove ENOENT. No daemon/provider.
 digest,err:=native379PhaseCodecPublishWithRemove(spec,destination,encoded,func(name string)error{calls++;if renameErr:=os.Rename(name,name+"-quarantined");renameErr!=nil{return renameErr};return os.Remove(name)})
 if err==nil || digest!="" || calls!=1 { t.Fatal("owned temporary cleanup refusal became accepted publication") }
 if info,statErr:=os.Lstat(destination);statErr!=nil || !info.Mode().IsRegular() { t.Fatal("truthful quarantined final file missing") }
 ctx,stop:=context.WithCancel(spec.Context);spec.Context=ctx;spec.Phases[0].Context=ctx
 late:=filepath.Join(t.TempDir(),"late.phase4")
 digest,err=native379PhaseCodecPublishWithRemove(spec,late,encoded,func(name string)error{removeErr:=os.Remove(name);stop();return removeErr})
 if err==nil || digest!="" { t.Fatal("late context cancellation during actual temp cleanup accepted") }
}

func TestNative379PhaseCodecLateHashCancellation(t *testing.T) {
 spec,records:=native379PhaseCodecUnit(t);encoded,_,err:=native379PhaseCodecEncode(spec,records);if err!=nil { t.Fatal(err) }
 ctx,stop:=context.WithCancel(spec.Context);spec.Context=ctx;spec.Phases[0].Context=ctx
 destination:=filepath.Join(t.TempDir(),"late-hash.phase4")
 digest,err:=native379PhaseCodecPublishWithFunctions(spec,destination,encoded,os.Remove,func(data []byte)[32]byte{sum:=sha256.Sum256(data);stop();return sum})
 if err==nil || digest!="" { t.Fatal("cancellation in actual final hash interval returned success") }
}

// Source-cost model v2 only; this helper grants no producer/source authority.
// Live adapter must supply independently admitted source and actual owned
// bootstrap/stream completion. Public hashes are not PostgreSQL signatures.
const native379PhaseCodecSourceModelVersion = 2
func native379PhaseCodecReconstructModelParameters(bootstrap native379CompactBootstrap, receipt native379CompactReceipt, control orderedCurrentNative379V3Control, index int, user string, pid int32)([]byte,error) {
 if index<0 || index>=len(control.Program.Steps) || native379CompactValidateBootstrap(bootstrap,control.ID,user,pid)!=nil { return nil,errors.New("model source/owned bootstrap refused") }
 step:=control.Program.Steps[index]
 if step.SQLSHA256!=orderedCurrentNative379V3SHA256([]byte(step.SQL)) { return nil,errors.New("model source SQL binding refused") }
 placement,token,err:=native379V3RolePlacement(control,index)
 if err!=nil || placement=="before-poison" || native379CompactValidateReceipt(receipt,bootstrap,step,placement,token)!=nil { return nil,errors.New("model source placement/receipt refused") }
 role:=orderedCurrentNative379V3ExpectedAssertedRole(token,user)
 parameters,err:=json.Marshal([]any{role,user,pid})
 if err!=nil || receipt.ParameterSHA256!=orderedCurrentNative379V3SHA256(parameters) { return nil,errors.New("model exact original Marshal parameters refused") }
 return parameters,nil
}
func TestNative379PhaseCodecReconstructedParameterAssociations(t *testing.T) {
 if native379PhaseCodecSourceModelVersion!=2 { t.Fatal("separate source model version absent") }
 for _,user:=range []string{"zasp_test",strings.Repeat("u",63),strings.Repeat("\x01",63),strings.Repeat("é",31)+"a","quote\"backslash\\<&\u2028\u2029"} {
  for _,token:=range []string{"fixture-owner","zasp_test","zasp_discovery_authority"} {
   step:=native379CompactUnitStep();step.Role=token
   control:=orderedCurrentNative379V3Control{ID:"control"};control.Program.Steps=[]orderedCurrentNative379V3ProgramStep{step}
   bootstrap:=native379CompactBootstrapFor(control.ID,user,2147483647)
   receipt:=native379CompactReceiptFor(bootstrap,step,"before",token,1)
   parameters,err:=native379PhaseCodecReconstructModelParameters(bootstrap,receipt,control,0,user,2147483647)
   original:=native379V3AssertionReceiptFor(native379V3SessionBinding{ControlID:control.ID,User:user,PID:2147483647},step,"before",orderedCurrentNative379V3ExpectedAssertedRole(token,user),1)
   want,_:=json.Marshal([]any{orderedCurrentNative379V3ExpectedAssertedRole(token,user),user,int32(2147483647)})
   if err!=nil || !bytes.Equal(parameters,want) || receipt.ParameterSHA256!=original.ParameterSHA256 { t.Fatal("exact original parameter/alias equivalence",err) }
   for _,kind:=range []string{"parameter-hash","bootstrap-hash","source-step-hash","placement-hash","placement","role-token","caller","pid","control","source-sql","source-role","completed-state","completed-rows","completed-tag","completed-timeout"} {
    t.Run(fmt.Sprintf("%d/%s/%s",len([]byte(user)),token,kind),func(t *testing.T){
     b,r,c:=bootstrap,receipt,control;c.Program.Steps=append([]orderedCurrentNative379V3ProgramStep(nil),control.Program.Steps...)
     switch kind {
     case "parameter-hash":r.ParameterSHA256=strings.Repeat("a",64)
     case "bootstrap-hash":r.BootstrapSHA256=strings.Repeat("a",64)
     case "source-step-hash":r.SourceStepSQLSHA256=strings.Repeat("a",64)
     case "placement-hash":r.PlacementSHA256=strings.Repeat("a",64)
     case "placement":r.Placement="after-recovery"
     case "role-token":r.RoleBinding="borrowed"
     case "caller":b.Captured.User=user+"x"
     case "pid":b.Captured.PID=2147483646
     case "control":c.ID="borrowed"
     case "source-sql":c.Program.Steps[0].SQL="SELECT 2";c.Program.Steps[0].SQLSHA256=orderedCurrentNative379V3SHA256([]byte("SELECT 2"))
     case "source-role":c.Program.Steps[0].Role="borrowed"
     case "completed-state":r.SQLState="22012"
     case "completed-rows":r.RowCount=1
     case "completed-tag":r.CommandTag="SELECT 1"
     case "completed-timeout":r.TimedOut=true
     }
     if _,err:=native379PhaseCodecReconstructModelParameters(b,r,c,0,user,2147483647);err==nil { t.Fatal("detached source/owned/completion parameter evidence admitted") }
    })
   }
  }
 }
 // Preserve source-derived post-recovery override and no before-poison receipt.
 state:="42501";prior:=native379CompactUnitStep();prior.Expected=orderedCurrentNative379V3StepExpectation{Outcome:"error",SQLState:&state}
 restore:=native379CompactUnitStep();restore.ID="restore";restore.SQL=native379V3FullRestoreSQL;restore.SQLSHA256=orderedCurrentNative379V3SHA256([]byte(restore.SQL));restore.Expected.Outcome="command-success"
 c:=orderedCurrentNative379V3Control{ID:"recovery"};c.Program.Steps=[]orderedCurrentNative379V3ProgramStep{prior,restore}
 b:=native379CompactBootstrapFor(c.ID,"different-owner",2147483647);r:=native379CompactReceiptFor(b,restore,"after-recovery","zasp_discovery_authority",1)
 if _,err:=native379PhaseCodecReconstructModelParameters(b,r,c,1,"different-owner",2147483647);err!=nil { t.Fatal("source recovery override refused",err) }
 wrong:=native379CompactReceiptFor(b,restore,"before","fixture-owner",1)
 if _,err:=native379PhaseCodecReconstructModelParameters(b,wrong,c,1,"different-owner",2147483647);err==nil { t.Fatal("borrowed pre-recovery binding admitted") }
 c.ID="restore:transaction";c.Program.Steps=[]orderedCurrentNative379V3ProgramStep{native379CompactUnitStep()};b=native379CompactBootstrapFor(c.ID,"different-owner",2147483647)
 r=native379CompactReceiptFor(b,c.Program.Steps[0],"before","fixture-owner",1)
 if _,err:=native379PhaseCodecReconstructModelParameters(b,r,c,0,"different-owner",2147483647);err==nil { t.Fatal("before-poison gained new assertion") }
}

func TestNative379PhaseCodecEmptyPhaseModelRegression(t *testing.T) {
 // Small component fixture; no authentic-source/native admission claimed.
 facts:=[]map[string]string{}
 for i:=0;i<8;i++ { identity,_:=json.Marshal([]string{"private-routines",fmt.Sprintf("routine:%d",i)});facts=append(facts,map[string]string{"identity":string(identity)}) }
 phases:=[]map[string]any{}
 for _,id:=range []string{"preflight","pristine-truth","cleanup-result"} { phases=append(phases,map[string]any{"id":id,"limits":map[string]any{"maxRows":100,"maxBytes":100000,"maxMilliseconds":10000}}) }
 raw,err:=json.Marshal(map[string]any{"entry":map[string]any{"privateRoutineFacts":facts},"phases":phases,"limits":map[string]any{"maxRows":100,"maxBytes":100000}})
 if err!=nil { t.Fatal(err) };var packet orderedCurrentNative379V3Packet;if json.Unmarshal(raw,&packet)!=nil { t.Fatal("small model fixture decode") }
 spec,records:=native379PhaseCodecModel(t,packet,strings.Repeat("1",64),"zasp_test",2147483647)
 for _,index:=range []int{0,2} { if records[index]==nil || len(records[index])!=0 { t.Fatal("model zero-record phase is not explicit canonical empty list") } }
 encoded,cost,err:=native379PhaseCodecEncode(spec,records);if err!=nil { t.Fatal("empty-phase encoding",err) }
 decoded,replayed,err:=native379PhaseCodecDecode(spec,encoded);if err!=nil { t.Fatal("empty-phase decoding",err) }
 if !reflect.DeepEqual(records,decoded) { t.Fatal("empty-phase record projection differs") }
 if !reflect.DeepEqual(cost,replayed) { t.Fatal("empty-phase cost projection differs") }
 // Nil and empty input have the same physical wire: neither means an absent
 // phase. Decode emits explicit [] for both, preserving all0row charges.
 nilInput:=append([][]native379PhaseCodecRecord(nil),records...);nilInput[0]=nil;nilInput[2]=nil
 nilEncoded,nilCost,err:=native379PhaseCodecEncode(spec,nilInput)
 if err!=nil || !bytes.Equal(encoded,nilEncoded) || !reflect.DeepEqual(cost,nilCost) { t.Fatal("nil/empty phase physical wire or accounting differs",err) }
 nilDecoded,nilReplay,err:=native379PhaseCodecDecode(spec,nilEncoded)
 if err!=nil || !reflect.DeepEqual(records,nilDecoded) || !reflect.DeepEqual(cost,nilReplay) { t.Fatal("nil-input canonical empty projection differs",err) }
}

// Original all-caller entry remains available; ROOT selects the exact four
// individually named groups below to retain90s per process and shared270s.
func TestNative379PhaseCodecFullSourceCostModel(t *testing.T) { native379PhaseCodecFullSourceCostModel(t,[]string{"zasp_test",strings.Repeat("u",63),strings.Repeat("\x01",63),strings.Repeat("é",31)+"a"}) }
func TestNative379PhaseCodecSourceCallerShort(t *testing.T) { native379PhaseCodecFullSourceCostModel(t,[]string{"zasp_test"}) }
func TestNative379PhaseCodecSourceCallerASCII63(t *testing.T) { native379PhaseCodecFullSourceCostModel(t,[]string{strings.Repeat("u",63)}) }
func TestNative379PhaseCodecSourceCallerControl63(t *testing.T) { native379PhaseCodecFullSourceCostModel(t,[]string{strings.Repeat("\x01",63)}) }
func TestNative379PhaseCodecSourceCallerUTF8_63(t *testing.T) { native379PhaseCodecFullSourceCostModel(t,[]string{strings.Repeat("é",31)+"a"}) }
