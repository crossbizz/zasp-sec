package apiserver

// Component only: this transports complete canonical preimages. It does not
// admit owned observations, execute SQL, validate outcomes, or grant readiness.
import (
 "bytes"
 "compress/gzip"
 "context"
 "crypto/sha256"
 "encoding/binary"
 "encoding/hex"
 "encoding/json"
 "errors"
 "io"
 "os"
 "path/filepath"
 "strings"
 "time"
)

const native379PhaseCodecCap = 4 * 1024 * 1024
var native379PhaseCodecMagic = [16]byte{'N','3','7','9','P','H','A','S','E','G','Z','I','P','4',0,1}
// Only fixed standard Go gzip, no optional dictionary or external dependency.
// Each phase is exactly one member. The total containing artifact is <=4MiB.
type native379PhaseCodecRecord struct {
 Kind byte
 Rows byte
 Key string
 Value json.RawMessage
}
type native379PhaseCodecPhase struct {
 ID string
 MaxRows uint64
 MaxBytes uint64
 MaxMilliseconds int64
 Keys []string
 Context context.Context // actual shared remaining-phase deadline in an adapter
}
type native379PhaseCodecSpec struct {
 PacketSHA256 string
 MaxRows uint64
 MaxBytes uint64
 Context context.Context
 Phases []native379PhaseCodecPhase
}
type native379PhaseCodecCost struct {
 Rows uint64
 CanonicalValueBytes uint64
 ExpandedBytes uint64 // includes record framing and keys, not just values
 EncodedBytes uint64 // includes phase framing; first owns the fixed global header
 ChargedBytes uint64 // exact ExpandedBytes+EncodedBytes, no rebate
}
type native379PhaseCodecReport struct {
 Phases []native379PhaseCodecCost
 Total native379PhaseCodecCost
}
var native379PhaseCodecRefused = errors.New("native379 phase codec refused")
var native379PhaseCodecBoundRefused = errors.New("native379 phase codec row/byte bound refused")

func native379PhaseCodecLive(ctx context.Context) error {
 if ctx==nil || ctx.Err()!=nil { return native379PhaseCodecRefused }
 deadline,ok:=ctx.Deadline(); if !ok || !time.Now().Before(deadline) { return native379PhaseCodecRefused }
 return nil
}
func native379PhaseCodecSpecClosed(spec native379PhaseCodecSpec) error {
 raw,err:=hex.DecodeString(spec.PacketSHA256)
 if err!=nil || len(raw)!=32 || strings.ToLower(spec.PacketSHA256)!=spec.PacketSHA256 || len(spec.Phases)==0 || len(spec.Phases)>16 || spec.MaxRows==0 || spec.MaxRows>38240 || spec.MaxBytes==0 || spec.MaxBytes>85983232 || native379PhaseCodecLive(spec.Context)!=nil { return native379PhaseCodecRefused }
 globalDeadline,_:=spec.Context.Deadline();if time.Until(globalDeadline)>750000*time.Millisecond { return native379PhaseCodecRefused }
 seen:=map[string]bool{}
 for _,phase:=range spec.Phases {
  if len(phase.ID)==0 || len(phase.ID)>64 || seen[phase.ID] || phase.MaxRows==0 || phase.MaxRows>spec.MaxRows || phase.MaxBytes==0 || phase.MaxBytes>spec.MaxBytes || phase.MaxMilliseconds<=0 || phase.MaxMilliseconds>750000 || native379PhaseCodecLive(phase.Context)!=nil { return native379PhaseCodecRefused }
  for _,c:=range []byte(phase.ID) { if !(c>='a'&&c<='z' || c>='0'&&c<='9' || c=='-') { return native379PhaseCodecRefused } }
  deadline,_:=phase.Context.Deadline()
  if deadline.After(globalDeadline) || time.Until(deadline)>time.Duration(phase.MaxMilliseconds)*time.Millisecond { return native379PhaseCodecRefused }
  seen[phase.ID]=true
  keys:=map[string]bool{}
  if len(phase.Keys)>38240 { return native379PhaseCodecRefused }
  for _,key:=range phase.Keys { if len(key)==0 || len(key)>512 || keys[key] { return native379PhaseCodecRefused };keys[key]=true }
 }
 return nil
}
func native379PhaseCodecKindRows(kind,rows byte) bool {
 // fact, fixed, bootstrap, data are physical rows; assertion and actual
 // parameter arrays/command-status preimages are zero-row evidence. No synthetic observed labels.
 return (kind>=1 && kind<=4 && rows==1) || ((kind==5 || kind==6 || kind==7) && rows==0)
}
func native379PhaseCodecCanonical(ctx,phase context.Context,raw json.RawMessage) bool {
 if len(raw)==0 || len(raw)>33554432 { return false }
 // Preflight bounds parser objects independently of value bytes. Source census
 // must demonstrate all current preimages below this component ceiling before
 // any adapter adoption. Strings still have the existing32MiB byte bound.
 scan:=json.NewDecoder(bytes.NewReader(raw));scan.UseNumber();tokens:=0
 for { if native379PhaseCodecLive(ctx)!=nil || native379PhaseCodecLive(phase)!=nil { return false };_,err:=scan.Token();if err==io.EOF { break };if err!=nil { return false };tokens++;if tokens>65536 { return false } }
 // Wrap arbitrary canonical value to reuse exact duplicate/UTF8/depth checks.
 wrapped:=make([]byte,0,len(raw)+6);wrapped=append(wrapped,[]byte(`{"v":`)...);wrapped=append(wrapped,raw...);wrapped=append(wrapped,'}')
 if _,err:=native379V3StrictJSON(wrapped);err!=nil { return false }
 canonical,err:=orderedCurrentNative379V3CanonicalJSON(raw)
 return err==nil && bytes.Equal(canonical,raw)
}
func native379PhaseCodecAdd(dst *uint64,value uint64,cap uint64) error {
 if *dst>cap || value>cap-*dst { return native379PhaseCodecBoundRefused };*dst+=value;return nil
}
func native379PhaseCodecCostAdd(report *native379PhaseCodecReport,phase native379PhaseCodecPhase,cost native379PhaseCodecCost,spec native379PhaseCodecSpec) error {
 if cost.Rows>phase.MaxRows || cost.ChargedBytes>phase.MaxBytes || report.Total.Rows>spec.MaxRows || report.Total.ChargedBytes>spec.MaxBytes || cost.Rows>spec.MaxRows-report.Total.Rows || cost.ChargedBytes>spec.MaxBytes-report.Total.ChargedBytes { return native379PhaseCodecBoundRefused }
 report.Total.Rows+=cost.Rows;report.Total.ChargedBytes+=cost.ChargedBytes
 report.Total.CanonicalValueBytes+=cost.CanonicalValueBytes
 report.Total.ExpandedBytes+=cost.ExpandedBytes
 report.Total.EncodedBytes+=cost.EncodedBytes
 report.Phases=append(report.Phases,cost);return nil
}
type native379PhaseCodecWriter struct { ctx context.Context; phase context.Context; buffer bytes.Buffer; cap int }
func (w *native379PhaseCodecWriter) Write(p []byte)(int,error) {
 if native379PhaseCodecLive(w.ctx)!=nil || native379PhaseCodecLive(w.phase)!=nil { return 0,native379PhaseCodecRefused };if len(p)>w.cap-w.buffer.Len() { return 0,native379PhaseCodecBoundRefused };return w.buffer.Write(p)
}
type native379PhaseCodecReader struct { ctx context.Context; phase context.Context; r io.Reader; left uint64 }
func (r *native379PhaseCodecReader) Read(p []byte)(int,error) {
 if native379PhaseCodecLive(r.ctx)!=nil || native379PhaseCodecLive(r.phase)!=nil { return 0,native379PhaseCodecRefused }
 if r.left==0 { return 0,io.EOF };if uint64(len(p))>r.left { p=p[:int(r.left)] }
 n,err:=r.r.Read(p);r.left-=uint64(n);return n,err
}
func native379PhaseCodecEncode(spec native379PhaseCodecSpec,records [][]native379PhaseCodecRecord)([]byte,native379PhaseCodecReport,error) {
 var report native379PhaseCodecReport
 if native379PhaseCodecSpecClosed(spec)!=nil || len(records)!=len(spec.Phases) { return nil,report,native379PhaseCodecRefused }
 var artifact bytes.Buffer;artifact.Write(native379PhaseCodecMagic[:]);packet,_:=hex.DecodeString(spec.PacketSHA256);artifact.Write(packet);binary.Write(&artifact,binary.BigEndian,uint16(len(spec.Phases)))
 for index,phase:=range spec.Phases {
  if len(records[index])!=len(phase.Keys) || native379PhaseCodecLive(spec.Context)!=nil || native379PhaseCodecLive(phase.Context)!=nil { return nil,report,native379PhaseCodecRefused }
  out:=native379PhaseCodecWriter{ctx:spec.Context,phase:phase.Context,cap:native379PhaseCodecCap-artifact.Len()}
  gz,err:=gzip.NewWriterLevel(&out,gzip.BestSpeed);if err!=nil { return nil,report,native379PhaseCodecRefused }
  h:=sha256.New();expanded:=io.MultiWriter(gz,h);cost:=native379PhaseCodecCost{}
  writeErr:=error(nil)
  for ordinal,record:=range records[index] {
   if record.Key!=phase.Keys[ordinal] || !native379PhaseCodecKindRows(record.Kind,record.Rows) || !native379PhaseCodecCanonical(spec.Context,phase.Context,record.Value) { writeErr=native379PhaseCodecRefused;break }
   length:=uint64(8+len(record.Key)+len(record.Value))
   if native379PhaseCodecAdd(&cost.ExpandedBytes,length,phase.MaxBytes)!=nil || native379PhaseCodecAdd(&cost.Rows,uint64(record.Rows),phase.MaxRows)!=nil || cost.Rows>spec.MaxRows-report.Total.Rows || cost.ExpandedBytes>spec.MaxBytes-report.Total.ChargedBytes { writeErr=native379PhaseCodecBoundRefused;break }
   reservedFraming:=uint64(1+len(phase.ID)+48);if index==0 { reservedFraming+=50 }
   remaining:=phase.MaxBytes-cost.ExpandedBytes
   globalRemaining:=spec.MaxBytes-report.Total.ChargedBytes-cost.ExpandedBytes
   if globalRemaining<remaining { remaining=globalRemaining }
   if remaining<reservedFraming { writeErr=native379PhaseCodecBoundRefused;break };remaining-=reservedFraming
   if remaining<uint64(out.cap) { out.cap=int(remaining) }
   if out.buffer.Len()>out.cap { writeErr=native379PhaseCodecBoundRefused;break }
   cost.CanonicalValueBytes+=uint64(len(record.Value))
   header:=[]byte{record.Kind,record.Rows,0,0,0,0,0,0};binary.BigEndian.PutUint16(header[2:4],uint16(len(record.Key)));binary.BigEndian.PutUint32(header[4:8],uint32(len(record.Value)))
   for _,part:=range [][]byte{header,[]byte(record.Key),record.Value} { if _,err=expanded.Write(part);err!=nil { writeErr=err;break } }
   if writeErr!=nil { break }
  }
  closeErr:=gz.Close();if writeErr!=nil { return nil,report,writeErr };if closeErr!=nil { return nil,report,closeErr }
  // Phase header: ID length+ID, record count, expanded length, gzip length, SHA.
  headerBytes:=1+len(phase.ID)+4+8+4+32
  cost.EncodedBytes=uint64(headerBytes+out.buffer.Len());if index==0 { cost.EncodedBytes+=50 }
  cost.ChargedBytes=cost.ExpandedBytes+cost.EncodedBytes
  if artifact.Len()+headerBytes+out.buffer.Len()>native379PhaseCodecCap || native379PhaseCodecCostAdd(&report,phase,cost,spec)!=nil { return nil,report,native379PhaseCodecBoundRefused }
  artifact.WriteByte(byte(len(phase.ID)));artifact.WriteString(phase.ID);binary.Write(&artifact,binary.BigEndian,uint32(len(records[index])));binary.Write(&artifact,binary.BigEndian,cost.ExpandedBytes);binary.Write(&artifact,binary.BigEndian,uint32(out.buffer.Len()));artifact.Write(h.Sum(nil));artifact.Write(out.buffer.Bytes())
 }
 if native379PhaseCodecLive(spec.Context)!=nil { return nil,report,native379PhaseCodecRefused }
 return artifact.Bytes(),report,nil
}
func native379PhaseCodecDecode(spec native379PhaseCodecSpec,artifact []byte)([][]native379PhaseCodecRecord,native379PhaseCodecReport,error) {
 return native379PhaseCodecDecodeWithAllocator(spec,artifact,func(length int)[]byte{return make([]byte,length)})
}
func native379PhaseCodecDecodeWithAllocator(spec native379PhaseCodecSpec,artifact []byte,allocate func(int)[]byte)([][]native379PhaseCodecRecord,native379PhaseCodecReport,error) {
 var report native379PhaseCodecReport
 if native379PhaseCodecSpecClosed(spec)!=nil || len(artifact)<50 || len(artifact)>native379PhaseCodecCap || !bytes.Equal(artifact[:16],native379PhaseCodecMagic[:]) || hex.EncodeToString(artifact[16:48])!=spec.PacketSHA256 || int(binary.BigEndian.Uint16(artifact[48:50]))!=len(spec.Phases) { return nil,report,native379PhaseCodecRefused }
 input:=bytes.NewReader(artifact[50:]);result:=make([][]native379PhaseCodecRecord,0,len(spec.Phases))
 for index,phase:=range spec.Phases {
  idLength,err:=input.ReadByte();if err!=nil || int(idLength)!=len(phase.ID) { return nil,report,native379PhaseCodecRefused }
  id:=make([]byte,int(idLength));if _,err=io.ReadFull(input,id);err!=nil || string(id)!=phase.ID { return nil,report,native379PhaseCodecRefused }
  header:=make([]byte,48);if _,err=io.ReadFull(input,header);err!=nil { return nil,report,native379PhaseCodecRefused }
  count:=binary.BigEndian.Uint32(header[0:4]);rawLength:=binary.BigEndian.Uint64(header[4:12]);gzipLength:=binary.BigEndian.Uint32(header[12:16]);wantSHA:=header[16:48]
  framing:=uint64(1+len(id)+48);if index==0 { framing+=50 }
  cost:=native379PhaseCodecCost{ExpandedBytes:rawLength,EncodedBytes:framing+uint64(gzipLength)}
  if count!=uint32(len(phase.Keys)) || uint64(gzipLength)>uint64(input.Len()) || rawLength>phase.MaxBytes || cost.EncodedBytes>phase.MaxBytes-rawLength || rawLength>spec.MaxBytes-report.Total.ChargedBytes || cost.EncodedBytes>spec.MaxBytes-report.Total.ChargedBytes-rawLength { return nil,report,native379PhaseCodecRefused }
  cost.ChargedBytes=cost.ExpandedBytes+cost.EncodedBytes
  compressed:=make([]byte,int(gzipLength));if _,err=io.ReadFull(input,compressed);err!=nil { return nil,report,native379PhaseCodecRefused }
  // Fixed gzip header: no name/comment/extra/dictionary/time metadata.
  if len(compressed)<18 || !bytes.Equal(compressed[:10],[]byte{31,139,8,0,0,0,0,0,4,255}) { return nil,report,native379PhaseCodecRefused }
  compressedReader:=bytes.NewReader(compressed);gz,err:=gzip.NewReader(compressedReader);if err!=nil { return nil,report,native379PhaseCodecRefused };gz.Multistream(false)
  h:=sha256.New();limited:=&native379PhaseCodecReader{ctx:spec.Context,phase:phase.Context,r:gz,left:rawLength}
  decoded:=io.TeeReader(limited,h);phaseRecords:=make([]native379PhaseCodecRecord,0,int(count));failure:=false
  for ordinal:=uint32(0);ordinal<count;ordinal++ {
   itemHeader:=make([]byte,8);if _,err=io.ReadFull(decoded,itemHeader);err!=nil { failure=true;break }
   kind,rows:=itemHeader[0],itemHeader[1];keyLength:=binary.BigEndian.Uint16(itemHeader[2:4]);valueLength:=binary.BigEndian.Uint32(itemHeader[4:8])
   if valueLength==0 || valueLength>33554432 || !native379PhaseCodecKindRows(kind,rows) || int(keyLength)!=len(phase.Keys[ordinal]) || uint64(keyLength)+uint64(valueLength)>limited.left || native379PhaseCodecAdd(&cost.Rows,uint64(rows),phase.MaxRows)!=nil || cost.Rows>spec.MaxRows-report.Total.Rows { failure=true;break }
   key:=make([]byte,int(keyLength));if _,err=io.ReadFull(decoded,key);err!=nil || string(key)!=phase.Keys[ordinal] { failure=true;break }
   value:=allocate(int(valueLength));if len(value)!=int(valueLength) { failure=true;break };if _,err=io.ReadFull(decoded,value);err!=nil || !native379PhaseCodecCanonical(spec.Context,phase.Context,value) { failure=true;break }
   cost.CanonicalValueBytes+=uint64(len(value));phaseRecords=append(phaseRecords,native379PhaseCodecRecord{Kind:kind,Rows:rows,Key:string(key),Value:value})
  }
  // Reader exact limit is not permission to ignore a gzip overflow/trailer.
  var extra [1]byte;n,tailErr:=gz.Read(extra[:]);closeErr:=gz.Close()
  if failure || limited.left!=0 || n!=0 || tailErr!=io.EOF || closeErr!=nil || compressedReader.Len()!=0 || !bytes.Equal(wantSHA,h.Sum(nil)) || native379PhaseCodecLive(spec.Context)!=nil || native379PhaseCodecLive(phase.Context)!=nil || native379PhaseCodecCostAdd(&report,phase,cost,spec)!=nil { return nil,report,native379PhaseCodecRefused }
  result=append(result,phaseRecords)
 }
 if input.Len()!=0 { return nil,report,native379PhaseCodecRefused };return result,report,nil
}
// Owned component publication; caller must supply independently admitted full
// source/producer proof. Filesystem syscalls require an outer finite supervisor.
func native379PhaseCodecPublish(spec native379PhaseCodecSpec,destination string,artifact []byte) (string,error) {
 return native379PhaseCodecPublishWithRemove(spec,destination,artifact,os.Remove)
}
// Private fault seam; actual wrapper always supplies the owned os.Remove.
func native379PhaseCodecPublishWithRemove(spec native379PhaseCodecSpec,destination string,artifact []byte,remove func(string)error) (digest string,returnedErr error) {
 return native379PhaseCodecPublishWithFunctions(spec,destination,artifact,remove,sha256.Sum256)
}
// Actual wrapper uses fixed standard SHA256; deterministic late-hash fault seam.
func native379PhaseCodecPublishWithFunctions(spec native379PhaseCodecSpec,destination string,artifact []byte,remove func(string)error,hash func([]byte)[32]byte) (digest string,returnedErr error) {
 ctx:=spec.Context
 if _,_,err:=native379PhaseCodecDecode(spec,artifact);err!=nil { return "",native379PhaseCodecRefused }
 if native379PhaseCodecLive(ctx)!=nil || !filepath.IsAbs(destination) || filepath.Clean(destination)!=destination || len(artifact)==0 || len(artifact)>native379PhaseCodecCap { return "",native379PhaseCodecRefused }
 directory:=filepath.Dir(destination)
 for cursor:=directory;;cursor=filepath.Dir(cursor) { info,err:=os.Lstat(cursor);if err!=nil || !info.IsDir() || info.Mode()&os.ModeSymlink!=0 { return "",native379PhaseCodecRefused };if cursor==filepath.Dir(cursor) { break } }
 temporary,err:=os.CreateTemp(directory,".native379-phase4-*");if err!=nil { return "",native379PhaseCodecRefused }
 name:=temporary.Name();cleanupAttempted:=false
 defer func(){if !cleanupAttempted { if cleanupErr:=remove(name);cleanupErr!=nil { digest="";returnedErr=native379PhaseCodecRefused } }}()
 fail:=func() (string,error) { temporary.Close();return "",native379PhaseCodecRefused }
 if err=temporary.Chmod(0600);err!=nil || native379PhaseCodecLive(ctx)!=nil { return fail() }
 for at:=0;at<len(artifact); { if native379PhaseCodecLive(ctx)!=nil { return fail() };end:=at+32768;if end>len(artifact) { end=len(artifact) };n,writeErr:=temporary.Write(artifact[at:end]);if writeErr!=nil || n!=end-at { return fail() };at=end }
 if native379PhaseCodecLive(ctx)!=nil || temporary.Sync()!=nil || temporary.Close()!=nil || native379PhaseCodecLive(ctx)!=nil { return fail() }
 if os.Link(name,destination)!=nil { return "",native379PhaseCodecRefused }
 // Late errors leave a quarantined file but return no acceptance/digest.
 info,statErr:=os.Lstat(destination)
 if statErr!=nil || !info.Mode().IsRegular() || info.Mode().Perm()!=0600 || info.Size()!=int64(len(artifact)) { return "",native379PhaseCodecRefused }
 opened,openErr:=os.Open(destination);if openErr!=nil { return "",native379PhaseCodecRefused }
 openedInfo,openedStatErr:=opened.Stat()
 if openedStatErr!=nil || !os.SameFile(info,openedInfo) || !openedInfo.Mode().IsRegular() || openedInfo.Size()!=int64(len(artifact)) { opened.Close();return "",native379PhaseCodecRefused }
 published,readErr:=io.ReadAll(io.LimitReader(opened,native379PhaseCodecCap+1));afterInfo,afterErr:=opened.Stat();readCloseErr:=opened.Close()
 finalInfo,finalErr:=os.Lstat(destination)
 if readErr!=nil || afterErr!=nil || readCloseErr!=nil || finalErr!=nil || !os.SameFile(info,afterInfo) || !os.SameFile(info,finalInfo) || afterInfo.Size()!=info.Size() || afterInfo.ModTime()!=info.ModTime() || finalInfo.Mode()!=info.Mode() || !bytes.Equal(published,artifact) || native379PhaseCodecLive(ctx)!=nil { return "",native379PhaseCodecRefused }
 dir,openErr:=os.Open(directory);if openErr!=nil { return "",native379PhaseCodecRefused };syncErr:=dir.Sync();closeErr:=dir.Close()
 if syncErr!=nil || closeErr!=nil || native379PhaseCodecLive(ctx)!=nil { return "",native379PhaseCodecRefused }
 cleanupAttempted=true
 if remove(name)!=nil || native379PhaseCodecLive(ctx)!=nil { return "",native379PhaseCodecRefused }
 // Temporary-unlink metadata must also be durable before success.
 cleanupDir,cleanupOpenErr:=os.Open(directory);if cleanupOpenErr!=nil { return "",native379PhaseCodecRefused };cleanupSyncErr:=cleanupDir.Sync();cleanupCloseErr:=cleanupDir.Close()
 if cleanupSyncErr!=nil || cleanupCloseErr!=nil || native379PhaseCodecLive(ctx)!=nil { return "",native379PhaseCodecRefused }
 sum:=hash(artifact)
 if native379PhaseCodecLive(ctx)!=nil { return "",native379PhaseCodecRefused }
 return hex.EncodeToString(sum[:]),nil
}
