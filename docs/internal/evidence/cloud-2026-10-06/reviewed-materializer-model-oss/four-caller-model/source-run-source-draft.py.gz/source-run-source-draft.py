import ctypes
import hashlib
import json
import os
import pathlib
import shutil
import signal
import stat
import subprocess
import time
import uuid

BASE = pathlib.Path('/workspace/.zasp-cloud-owned/native379-phase-codec-four-caller-recipe-6bIKq21E')
SOURCE = pathlib.Path('/workspace/.zasp-cloud-owned/native379-v3-go-source21-initial-lem9djox/source')
MODULE = pathlib.Path('/workspace/.zasp-cloud-owned/native379-v3-go-source21-initial-lem9djox/source/services/platform')
GO = '/tmp/zasp-cloud-tools/go/bin/go'
EXPECTED = {'/workspace/.zasp-cloud-owned/native379-compact-source-icyjmyf_/source/authorization_worker_ordered_current_native379_v3_test.go': '4b29d8318704bc1e4b4637473c19bb2e71323f18b1ed1013fc6f423d833f2f37', '/workspace/.zasp-cloud-owned/native379-compact-source-icyjmyf_/source/authorization_worker_ordered_current_native379_v3_pins_test.go': 'ff4b79953be4e37d3c619ff412ea5bfee07d470d9770530ef911b48daba6faaf', '/workspace/.zasp-cloud-owned/native379-compact-source-icyjmyf_/source/authorization_worker_ordered_current_native379_compact_receipt_test.go': '67fdb6a2e42f464b472414c17a1478bbc425dce85ff4d8b6f5f64e6a1b3c962c', '/workspace/.zasp-cloud-owned/native379-compact-json-repair-64up_411/source/authorization_worker_ordered_current_native379_compact_receipt_test.go': '92fe2bb84aba2f26f063f62e5d4c829e5116852a7cde33a5b88902b1d78e2e28', '/workspace/.zasp-cloud-owned/native379-compact-json-repair-64up_411/new-regression-source.go.txt': 'c2515a9b67e51960053bc0be8d4cb9981fd0df38e6c28bf70f65d095bf5d4166', '/workspace/.zasp-cloud-owned/native379-compact-overlay-recipe-e8843vpa/green-core-only.go.txt': '2199991840df645b6d7a788d7be0496d1d1af1adee618342ee83703086e89cd0', '/workspace/.zasp-cloud-owned/native379-compact-overlay-recipe-e8843vpa/red-overlay.json': '7bd83f5a11cfd5d85d9523f1de94c7dfa657cda78662908ca14826c4c5563cd6', '/workspace/.zasp-cloud-owned/native379-compact-overlay-recipe-e8843vpa/green-overlay.json': 'ebdc4a8db977d582571a9eb10070cf88f8c02dedbc03066b95dc13e6ab2a7c67', '/workspace/.zasp-cloud-owned/native379-v3-go-source21-initial-lem9djox/source/services/platform/go.mod': '3d0176805b0c3fa8ce90b3984650e9dae08baaa13dc2dcbdc5528493326756b0', '/workspace/.zasp-cloud-owned/native379-v3-go-source21-initial-lem9djox/source/services/platform/go.sum': 'a99d2c9979401b020e8ce1c7818276f05c820dce5f43820566ba94121bf48825', '/tmp/zasp-cloud-tools/go/bin/go': '3fb44b0d47becc087cf9e6002366bfbf136d3e08460f12389dbd04687dcf0dd0', '/tmp/zasp-cloud-tools/bin/tini': '93dcc18adc78c65a028a84799ecf8ad40c936fdfc5f2a57b1acda5a8117fa82c', '/tmp/zasp-cloud-evidence/independent-native379-compact-component67fdb6-static-review.json': '7f4e8beda18d10b7a3a325d9f2cbd1ae43c7490e76e22fc80eda53cb4012383a', '/tmp/zasp-cloud-evidence/independent-native379-compact-component92fe2b-static-review.json': '7577695dcee0cbbc215367decac946630c8e7ed15f6cd41151b6bd15d71840c3', '/workspace/.zasp-cloud-owned/native379-compact-wire-fixture-revision-4mogde8y/regression-source.go.txt': '6111257f367dd536d4d27908522b508aca8f2cf820c7052886cd47ee0ac845b1', '/workspace/.zasp-cloud-owned/native379-compact-overlay-fixture-retry-zbhm8t3p/red-overlay.json': 'f75b9c881a4758af1ea66cd8b0ad2421fe7c37460eb5ff17016f7456f17ee371', '/workspace/.zasp-cloud-owned/native379-compact-overlay-fixture-retry-zbhm8t3p/green-overlay.json': 'dd554bf128f77b58193da556be441f25daa6a1e4807129ed9707662917388205', '/tmp/zasp-cloud-evidence/independent-compact-overlay-actual-failed-cdebb6-review.json': '00e74a1ccffeee77cc2829abcca574118c6114fbcfc85a18e67cbf751bd88639', '/workspace/.zasp-cloud-owned/native379-phase-codec-draft-2rhhvy8j/authorization_worker_ordered_current_native379_phase_codec_test.go': 'c8a675e4ecafd41a1b5d289eb7ea0dca73ba8ee7c74a94d5f6ccfb45202f8547', '/workspace/.zasp-cloud-owned/native379-phase-codec-draft-2rhhvy8j/authorization_worker_ordered_current_native379_phase_codec_cases_test.go': '84cba8e4eee1b77905b62e5c0a29987572e3abc27115267d53d42d55e01ca2a1', '/workspace/.zasp-cloud-owned/native379-phase-codec-draft-2rhhvy8j/source-overlay.json': '2554fe08d95c6f844beb32ada85f4b8c85ea9cf3dc0cf6b06666c1b740b1dcef', '/workspace/.zasp-cloud-owned/native379-v3-final81-0atrosfr/evidence/final-v3-canonical-wire.json': '41141f2ed08cfaee0bfea75dd11152c95d898a625a5f0d87f1f1b65be939d035', '/tmp/zasp-cloud-evidence/independent-compact-full-adapter-transport-design-review.json': 'cb394df620b4f0fd67c95fd8d503819b0bfed6467a35e88f88ce6e9bf3af5083', '/workspace/.zasp-cloud-owned/native379-phase-codec-repair-ujm4v_x2/authorization_worker_ordered_current_native379_phase_codec_test.go': '6dd1a1464fb0db85623a14b325c62edd4cebf66c7b7e61ae396330815f959ec7', '/workspace/.zasp-cloud-owned/native379-phase-codec-repair-ujm4v_x2/authorization_worker_ordered_current_native379_phase_codec_cases_test.go': '463fc9e9c1e03d5a8d28566170541cdc784bccfdf5c0e45a5d88f72b5c1f38b2', '/workspace/.zasp-cloud-owned/native379-phase-codec-repair-ujm4v_x2/source-overlay.json': '9464d5da72ab86cb247b5337325095646b02fe84c68216d628bb933d3687fb48', '/tmp/zasp-cloud-evidence/independent-phase-codec-draft-source-blockers.json': 'c5e30f9e7bc98ed923815d2221daa936b85d8b426dd4f4515333169bc554453b', '/tmp/zasp-cloud-evidence/independent-native379-phase-codec-c8a675-static-review.json': 'a67ef60acf8fd9391dc31950a861914994165b113252def0de03c72d75d37bbc', '/workspace/.zasp-cloud-owned/native379-phase-codec-final-guard-fxr3fxmo/authorization_worker_ordered_current_native379_phase_codec_test.go': '8ba722729b2420248a7085d763af2699add4b9bc05cee0bde02e6cc82e70f5dc', '/workspace/.zasp-cloud-owned/native379-phase-codec-final-guard-fxr3fxmo/authorization_worker_ordered_current_native379_phase_codec_cases_test.go': '6e4824b35423056706161332d8f8a877d284ed3e6bf875f5b5eaa89ee89c7b7f', '/workspace/.zasp-cloud-owned/native379-phase-codec-final-guard-fxr3fxmo/source-overlay.json': '69bf6550571ac38dada709a34e3908628815136c8cb4bc73fda4b30b54faa1de', '/workspace/.zasp-cloud-owned/native379-phase-codec-reconstructed-model-fzV8Fdge/authorization_worker_ordered_current_native379_phase_codec_test.go': '8ba722729b2420248a7085d763af2699add4b9bc05cee0bde02e6cc82e70f5dc', '/workspace/.zasp-cloud-owned/native379-phase-codec-reconstructed-model-fzV8Fdge/authorization_worker_ordered_current_native379_phase_codec_cases_test.go': 'b7f3742c767f9cea6281d549014afe788270371e87b22f1643a328cf6b67258a', '/workspace/.zasp-cloud-owned/native379-phase-codec-reconstructed-model-fzV8Fdge/source-overlay.json': '9ada41e2b361714a69321028f1a01a3bc6e27fbc8a4cd8dadb61a0d936d9ddd5', '/tmp/zasp-cloud-evidence/independent-phase-codec-parameter-attribution-design-review.json': '534bbba6e121e1b67bfe9b3ee9a1ee367444c69a0e558b213061fdd715e32d7d', '/workspace/.zasp-cloud-owned/native379-phase-codec-final-guard-fxr3fxmo/actual-phase-codec-source-tests-c8e03c4b4f1c4bb38e8c9def30784fab/result.json': '221fc7967fff9675b52fd5fb8d3f30c5da9bfd933a24f7f72113effaf5595c9f', '/workspace/.zasp-cloud-owned/native379-phase-codec-empty-phase-revision-OspKF33a/authorization_worker_ordered_current_native379_phase_codec_test.go': '8ba722729b2420248a7085d763af2699add4b9bc05cee0bde02e6cc82e70f5dc', '/workspace/.zasp-cloud-owned/native379-phase-codec-empty-phase-revision-OspKF33a/authorization_worker_ordered_current_native379_phase_codec_cases_test.go': '36a21c9a721a1ec6412abe68fbb39bf133c372b6fb435665ac926ae331ee01a0', '/workspace/.zasp-cloud-owned/native379-phase-codec-empty-phase-revision-OspKF33a/red-cases.go.txt': 'af747cd029b236b87d5e59ef12b4c5189f3ae84b025660071edefa776e1423ae', '/workspace/.zasp-cloud-owned/native379-phase-codec-empty-phase-revision-OspKF33a/same-regression.go.txt': '9696e54e6c5cff3c8819acb17134082a5d730c9bcce44a6d350a91cb86fd448a', '/workspace/.zasp-cloud-owned/native379-phase-codec-empty-phase-revision-OspKF33a/red-overlay.json': '095400c468ce11f1017e1232606d9a80877cdef37f1271b12cf1a6ddad9b6869', '/workspace/.zasp-cloud-owned/native379-phase-codec-empty-phase-revision-OspKF33a/green-overlay.json': 'e86ad5bf92815f836bad6b300f3c4c539bbd0774e3b7ab6fc08e4889fddec686', '/tmp/zasp-cloud-evidence/independent-actual-phase-codec-reconstructed-model-failure-review.json': '577e4a3c5dde0540f36a9b14c92c513e5235f7403088582031b2a6af28026abf', '/workspace/.zasp-cloud-owned/native379-phase-codec-reconstructed-model-fzV8Fdge/actual-phase-codec-source-tests-bf69564abf8d42fd9c0d3090cba57006/result.json': 'e2986cd217414ddc8d1114a77bcddfc59e557dbf9c53c09f2303f85b275f2738', '/workspace/.zasp-cloud-owned/native379-phase-codec-four-caller-recipe-6bIKq21E/authorization_worker_ordered_current_native379_phase_codec_test.go': '8ba722729b2420248a7085d763af2699add4b9bc05cee0bde02e6cc82e70f5dc', '/workspace/.zasp-cloud-owned/native379-phase-codec-four-caller-recipe-6bIKq21E/authorization_worker_ordered_current_native379_phase_codec_cases_test.go': 'bbecdcce7dbf849ef581c99ef10961f86c45b5c81ed5f70058d033e2e38c67cc', '/workspace/.zasp-cloud-owned/native379-phase-codec-four-caller-recipe-6bIKq21E/source-overlay.json': 'fc41fb8873cbdae6b2e7584da64bc3311ab43de3b84bf0f25bdb85704887e2fe', '/workspace/.zasp-cloud-owned/native379-phase-codec-four-caller-recipe-6bIKq21E/goroot-tool-source-map.json': '496dcd651bd0192036c1b4062c375d2bbe3b2d36c39bc9416612151b7b695a72', '/tmp/zasp-cloud-evidence/independent-actual-phase-codec-model3-deadline-failure-review.json': '0a06a89c4393718ff831d44b1f966d8e14d802d4671e396081a4abae702daa43', '/workspace/.zasp-cloud-owned/native379-phase-codec-empty-phase-revision-OspKF33a/actual-phase-codec-source-tests-df1ec49e1eeb4f22958846ac23c01512/result.json': 'b89d7e8801722bba6621c0ac19cd3ba4be894a321405d50cb5de0401a99296da'}
REGRESSION_ROSTER = ['TestNative379CompactPublisherFramingRegression', 'TestNative379CompactCompleteShapeRefusedRowAccountingRegression']
GROUP_ROSTER = ['TestNative379CompactOwnerAliasesAndExactParameters', 'TestNative379CompactReceiptAndBootstrapAssociations', 'TestNative379CompactClosedVersionDispatch', 'TestNative379CompactFullRowAndReceiptAccounting', 'TestNative379CompactAccountingAssociationAndBounds', 'TestNative379CompactPublisherFramingRegression', 'TestNative379CompactCompleteShapeRefusedRowAccountingRegression']
RESERVE = 1_500_000_000
os.umask(0o077)
OUT = BASE / ('actual-phase-codec-source-tests-' + uuid.uuid4().hex)
OUT.mkdir(mode=0o700)
TMP = OUT / 'tmp'
TMP.mkdir(mode=0o700)
ENV = {'HOME':'/home/agent','PATH':'/tmp/zasp-cloud-tools/go/bin:/usr/bin:/bin','GOROOT':'/tmp/zasp-cloud-tools/go','GOPATH':'/home/agent/go','GOCACHE':'/home/agent/.cache/go-build','GOMODCACHE':'/home/agent/go/pkg/mod','GOPROXY':'off','GOSUMDB':'off','GOTOOLCHAIN':'local','GOENV':'off','GOWORK':'off','GOFLAGS':'-mod=readonly','CGO_ENABLED':'1','CC':'/usr/bin/gcc','TMPDIR':str(TMP),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','ZASP_NATIVE379_PHASE_CODEC_SOURCE_PACKET':'/workspace/.zasp-cloud-owned/native379-v3-final81-0atrosfr/evidence/final-v3-canonical-wire.json'}
START = time.monotonic()
WORK_DEADLINE = START + 270
FINAL_DEADLINE = START + 300
cancelled=[]
owned={}
waits=[]
stages=[]
space=[]
teardown_errors=[]
cleanup_records=[]
admitted_identity=None
FALLBACK=OUT/'reserved-failure-result.json'
fallback_fd=os.open(FALLBACK,os.O_CREAT|os.O_EXCL|os.O_RDWR,0o600)
fallback_size=65536
os.write(fallback_fd,(json.dumps({'completed':False,'state':'initial_failure_receipt_reserved'})+'\n').encode().ljust(fallback_size,b' '))
os.fsync(fallback_fd)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):
            if time.monotonic()>FINAL_DEADLINE: raise RuntimeError('Identity hashing deadline refused')
            h.update(chunk)
    return h.hexdigest()
def durable(name,value):
    path=OUT/name
    with path.open('x') as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def identity():
    # Complete existing PRIVATE source, not external warmcache. No source
    # writes/chmod/followed-directory links. Symlink metadata is explicit.
    result={}
    for parent,dirs,files in os.walk(SOURCE,followlinks=False):
        dirs.sort();files.sort()
        for name in dirs+files:
            path=pathlib.Path(parent)/name;info=path.lstat()
            row={'mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid,'size':info.st_size,'dev':info.st_dev,'ino':info.st_ino,'nlink':info.st_nlink,'mtime_ns':info.st_mtime_ns}
            if stat.S_ISREG(info.st_mode):row.update(kind='file',sha256=sha(path))
            elif stat.S_ISLNK(info.st_mode):row.update(kind='symlink',target=os.readlink(path))
            elif stat.S_ISDIR(info.st_mode):row.update(kind='directory')
            else:raise RuntimeError('Unsupported source identity type')
            result[str(path)]=row
        if cancelled or time.monotonic()>FINAL_DEADLINE:raise RuntimeError('Source identity refused')
    for name,want in EXPECTED.items():
        path=pathlib.Path(name);info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or sha(path)!=want:raise RuntimeError('Pinned component/tool/module identity refused')
        result[name]={'kind':'file','sha256':want,'mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid,'size':info.st_size,'dev':info.st_dev,'ino':info.st_ino,'nlink':info.st_nlink,'mtime_ns':info.st_mtime_ns}
    selfpath=pathlib.Path(__file__);selfinfo=selfpath.lstat()
    result[str(selfpath)]={'kind':'file','sha256':sha(selfpath),'mode':stat.S_IMODE(selfinfo.st_mode),'uid':selfinfo.st_uid,'gid':selfinfo.st_gid,'size':selfinfo.st_size,'dev':selfinfo.st_dev,'ino':selfinfo.st_ino,'nlink':selfinfo.st_nlink,'mtime_ns':selfinfo.st_mtime_ns}
    return result

def proc_table():
    found = {}
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            stat = (p / 'stat').read_text()
            fields = stat[stat.rfind(')') + 2:].split()
            found[int(p.name)] = {'state': fields[0], 'ppid': int(fields[1]),
                                 'pgrp': int(fields[2]), 'startticks': int(fields[19])}
        except (OSError, ValueError, IndexError) as exc:
            # Vanished PID is normal. Present-but-unreadable/malformed stat
            # cannot prove absence, ownership, or descendant cleanup.
            try:
                present = p.exists()
            except OSError:
                present = True
            if present:
                raise RuntimeError('Process inspection unavailable for present PID ' + p.name) from exc
            continue
    return found

def remember():
    table = proc_table()
    parents = {os.getpid()}
    while True:
        new = {pid for pid, info in table.items() if info['ppid'] in parents}
        if new <= parents:
            break
        parents |= new
    for pid in parents - {os.getpid()}:
        if pid in table:
            owned[(pid, table[pid]['startticks'])] = table[pid]
    return table

def live_owned():
    table = remember()
    return [(pid, start, table[pid]) for pid, start in owned
            if pid in table and table[pid]['startticks'] == start]

def signal_owned(sig):
    for pid, start, info in live_owned():
        try:
            os.kill(pid, sig)
        except ProcessLookupError:
            pass

def reap():
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            return
        if not pid:
            return
        waits.append({'pid': pid, 'wait_status': status, 'reaped_adopted': True})

def cleanup(proc=None):
    record = {'pid': proc.pid if proc is not None else None, 'forced': False,
              'joined': proc is None, 'errors': []}
    try:
        initial = live_owned()
        if proc is not None and proc.poll() is None:
            record['forced'] = True
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        # Live descendants after the leader has completed are unexpected;
        # cleanup them, but never treat their forced teardown as GREEN.
        if initial:
            record['forced'] = True
        signal_owned(signal.SIGTERM)
        grace = min(time.monotonic() + 5, FINAL_DEADLINE)
        while live_owned() and time.monotonic() < grace:
            if proc is not None:
                proc.poll()
            reap()
            time.sleep(.1)
        if proc is not None and proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        signal_owned(signal.SIGKILL)
        if proc is not None:
            try:
                code = proc.wait(timeout=max(.001, FINAL_DEADLINE - time.monotonic()))
                waits.append({'pid': proc.pid, 'returncode': code, 'main_joined': True})
                record['joined'] = True
            except subprocess.TimeoutExpired:
                waits.append({'pid': proc.pid, 'main_joined': False})
        while live_owned() and time.monotonic() < FINAL_DEADLINE:
            reap()
            time.sleep(.05)
        reap()
        record['survivors'] = live_owned()
    except BaseException as exc:
        record['errors'].append(type(exc).__name__)
        teardown_errors.append('cleanup:' + type(exc).__name__)
        # The direct child still has a final unconditional kill/join attempt.
        if proc is not None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except BaseException as nested:
                record['errors'].append('kill:' + type(nested).__name__)
            try:
                code = proc.wait(timeout=max(.001, FINAL_DEADLINE - time.monotonic()))
                waits.append({'pid': proc.pid, 'returncode': code, 'main_joined': True})
                record['joined'] = True
            except BaseException as nested:
                record['errors'].append('join:' + type(nested).__name__)
        record['survivors'] = 'inspection_unavailable'
    cleanup_records.append(record)
    return record

def cancellation(sig, frame):
    cancelled.append(sig)
    current = globals().get('result')
    if isinstance(current, dict):
        current['completed'] = False
        current['late_signal'] = sig

def test_events(path):
    events = []
    for line in path.read_text(errors='replace').splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return events

def compiled_artifact_binding():
    path=OUT/'component.test'
    def fields(info):
        return {'device':info.st_dev,'inode':info.st_ino,'mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid,'links':info.st_nlink,'bytes':info.st_size,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns}
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_nlink!=1 or before.st_size<=0 or before.st_size>536870912:raise RuntimeError('Owned compiled component topology refused')
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        if fields(os.fstat(descriptor))!=fields(before):raise RuntimeError('Compiled component opened identity differs')
        digest=hashlib.sha256()
        while True:
            if cancelled or time.monotonic()>=FINAL_DEADLINE:raise RuntimeError('Compiled component hash deadline refused')
            chunk=os.read(descriptor,65536)
            if not chunk:break
            digest.update(chunk)
        if fields(os.fstat(descriptor))!=fields(before) or fields(path.lstat())!=fields(before):raise RuntimeError('Compiled component changed during bound hash')
        result=fields(before);result['sha256']=digest.hexdigest();return result
    finally:
        os.close(descriptor)

def verify_goroot_tool_source(deadline=None):
    if deadline is None:deadline=FINAL_DEADLINE
    root=pathlib.Path(GO).parent.parent
    admitted=json.loads((BASE/'goroot-tool-source-map.json').read_text())
    actual=[]
    for parent,dirs,files in os.walk(root,followlinks=False):
        for name in dirs:
            if pathlib.Path(parent,name).is_symlink():raise RuntimeError('Go tool source directory symlink refused')
        for name in sorted(files):
            if cancelled or time.monotonic()>=deadline:raise RuntimeError('Go tool source identity deadline refused')
            path=pathlib.Path(parent,name);info=path.lstat()
            if not stat.S_ISREG(info.st_mode):raise RuntimeError('Go tool source nonregular refused')
            actual.append({'path':str(path.relative_to(root)),'sha256':sha(path),'bytes':info.st_size,'mode':stat.S_IMODE(info.st_mode)})
    actual.sort(key=lambda item:item['path'])
    if actual!=admitted:raise RuntimeError('Complete pinned Go tool/source closure changed')

def run_stage(name,pattern,overlay):
    if cancelled or time.monotonic()>=WORK_DEADLINE:raise RuntimeError('Cancelled or elapsed before stage')
    begin=time.monotonic();deadline=min(begin+90,WORK_DEADLINE)
    verify_goroot_tool_source(deadline)
    if name=='component-compile':
        argv=[GO,'test','-race','-c','-o',str(OUT/'component.test'),'-overlay',str(BASE/overlay),'./apiserver']
    else:
        binary=OUT/'component.test';info=binary.lstat()
        if compiled_artifact_binding()!=compiled_binary['binding']:raise RuntimeError('Exact owned compiled component binding refused')
        argv=[GO,'tool','test2json','-p','github.com/zasp-ai/zasp-sec/services/platform/apiserver','-t',str(binary),'-test.v','-test.count=1','-test.timeout=90s','-test.run='+pattern]
    if shutil.disk_usage('/workspace').free<RESERVE:raise RuntimeError('Pre-stage storage reserve refused')
    log=OUT/(name+'.jsonl');proc=None;reason=None
    with log.open('xb') as stream:
        try:
            if cancelled or time.monotonic()>=deadline or time.monotonic()>=WORK_DEADLINE:raise RuntimeError('Cancelled/elapsed immediately before normal child spawn')
            if name!='component-compile' and compiled_artifact_binding()!=compiled_binary['binding']:raise RuntimeError('Compiled component changed immediately before spawn')
            if cancelled or time.monotonic()>=deadline or time.monotonic()>=WORK_DEADLINE:raise RuntimeError('Cancelled/elapsed after artifact hash immediately before spawn')
            proc=subprocess.Popen(argv,cwd=MODULE,env=ENV,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            current=proc_table().get(proc.pid)
            if current is None:raise RuntimeError('Immediate child ownership binding unavailable')
            owned[(proc.pid,current['startticks'])]=current
            durable(name+'-process-binding.json',{'pid':proc.pid,**current,'argv':argv,'environment':ENV,'monotonic_start':begin,'overlay_sha256':sha(BASE/overlay)})
            while proc.poll() is None:
                remember();free=shutil.disk_usage('/workspace').free
                space.append({'stage':name,'elapsed':time.monotonic()-START,'free_bytes':free})
                if cancelled:reason='cancelled'
                elif free<RESERVE:reason='storage_reserve_refusal'
                elif time.monotonic()>=deadline:reason='absolute_stage_or_aggregate_deadline'
                if reason:break
                time.sleep(.1)
        finally:
            teardown=cleanup(proc);stream.flush();os.fsync(stream.fileno())
    if time.monotonic()>deadline and reason is None:reason='actual_stage_end_exceeded_absolute_deadline'
    free_after_stage=shutil.disk_usage('/workspace').free
    if type(free_after_stage) is not int or free_after_stage<RESERVE:reason='actual_post_join_storage_reserve_refusal'
    events=test_events(log)
    record={'name':name,'argv':argv,'returncode':proc.returncode if proc is not None else None,'elapsed_seconds':time.monotonic()-begin,'refusal':reason,'free_after_stage':free_after_stage,'log_sha256':sha(log),'overlay_sha256':sha(BASE/overlay),'top_level_pass':[e['Test'] for e in events if e.get('Action')=='pass' and 'Test' in e and '/' not in e['Test']],'top_level_fail':[e['Test'] for e in events if e.get('Action')=='fail' and 'Test' in e and '/' not in e['Test']],'subtests_fail':[e['Test'] for e in events if e.get('Action')=='fail' and '/' in e.get('Test','')],'run_tests':[e['Test'] for e in events if e.get('Action')=='run' and 'Test' in e],'skips':[e.get('Test','<package>') for e in events if e.get('Action')=='skip'],'survivors':live_owned(),'cleanup':teardown}
    stages.append(record);durable(name+'-result.json',record)
    if reason or cancelled or record['survivors'] or teardown['forced'] or not teardown['joined'] or teardown['errors']:raise RuntimeError('Bounded stage refused')
    return record

def main():
    global admitted_identity
    if ctypes.CDLL(None).prctl(36,1,0,0,0)!=0:raise RuntimeError('Subreaper setup refused')
    for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,cancellation)
    admitted_identity=identity();durable('source-before.json',admitted_identity)
    if shutil.disk_usage('/workspace').free<RESERVE:raise RuntimeError('Initial storage reserve refused')
    durable('initial.json',{'status':'COMPONENT-SOURCE-TEST-ATTEMPT','source_base':str(SOURCE),'module':str(MODULE),'environment':ENV,'supervisor_sha256':sha(pathlib.Path(__file__)),'inputs':EXPECTED,'stage_seconds':90,'absolute_work_seconds':270,'absolute_final_seconds':300,'storage_reserve_bytes':RESERVE,'no_source_swap':True,'compile_once_then_exact_four_caller_tests':True,'overlay_only':True,'warmcache_is_mutable_compiler_output_not_authority':True,'no_native_pg_node_provider':True,'no_standard_package_readiness_claim':True})
    global compiled_binary
    verify_goroot_tool_source(WORK_DEADLINE)
    built=run_stage('component-compile','','source-overlay.json')
    if built['returncode']!=0 or built['top_level_pass'] or built['top_level_fail'] or built['skips']:raise RuntimeError('Component compilation failed; not test evidence')
    binary=OUT/'component.test';info=binary.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_nlink!=1:raise RuntimeError('Owned compiled component topology refused')
    compiled_binary={'path':str(binary),'sha256':sha(binary),'bytes':info.st_size,'mode':stat.S_IMODE(info.st_mode),'source_identity_equal':identity()==admitted_identity,'source_overlay_sha256':sha(BASE/'source-overlay.json'),'binding':compiled_artifact_binding(),'test2json_source_binding':'Go1.25 builtin cmd/test2json compiled by pinned go tool under same90s caller deadline','goroot_tool_source_map_sha256':sha(BASE/'goroot-tool-source-map.json')}
    if not compiled_binary['source_identity_equal']:raise RuntimeError('Compiler changed source identity')
    if any(compiled_binary[k]!=compiled_binary['binding'][k] for k in ['sha256','bytes','mode']):raise RuntimeError('Compiled component duplicate summary binding inconsistent')
    durable('compiled-component.json',compiled_binary)
    for name,test in [('caller-short','TestNative379PhaseCodecSourceCallerShort'),('caller-ascii63','TestNative379PhaseCodecSourceCallerASCII63'),('caller-control63','TestNative379PhaseCodecSourceCallerControl63'),('caller-utf8-63','TestNative379PhaseCodecSourceCallerUTF8_63')]:
        result=run_stage(name,'^'+test+'$','source-overlay.json')
        if result['returncode']!=0 or result['top_level_fail'] or result['skips'] or result['top_level_pass']!=[test] or compiled_artifact_binding()!=compiled_binary['binding']:raise RuntimeError('Exact bound caller model roster not demonstrated')

compiled_binary={}
error=None
result={'completed':False,'error':'Final result unavailable'}
try:
    main()
except BaseException as exc:
    error=type(exc).__name__+': '+str(exc)
finally:
    try:cleanup()
    except BaseException as exc:teardown_errors.append('outer_cleanup:'+type(exc).__name__)
    try:survivors=live_owned()
    except BaseException as exc:survivors='inspection_unavailable';teardown_errors.append('survivors:'+type(exc).__name__)
    try:
        verify_goroot_tool_source()
        if compiled_binary and compiled_artifact_binding()!=compiled_binary['binding']:raise RuntimeError('Final compiled component identity changed')
        source_after=identity();durable('source-after.json',source_after)
    except BaseException as exc:source_after=None;teardown_errors.append('source_after:'+type(exc).__name__)
    try:free_after=shutil.disk_usage('/workspace').free
    except BaseException as exc:free_after=None;teardown_errors.append('space_after:'+type(exc).__name__)
    if type(free_after) is not int or free_after<RESERVE:
        error=error or 'Final storage reserve unavailable/below unchanged bound'
    try:
        result={'completed':type(free_after) is int and free_after>=RESERVE and error is None and not cancelled and not survivors and not teardown_errors and len(stages)==5 and source_after==admitted_identity and time.monotonic()<=FINAL_DEADLINE and all(not c['forced'] and c['joined'] and not c['errors'] for c in cleanup_records),'error':error,'signals':cancelled,'stages':stages,'process_waits':waits,'cleanup_records':cleanup_records,'teardown_errors':teardown_errors,'survivors':survivors,'elapsed_seconds':time.monotonic()-START,'source_unchanged':source_after==admitted_identity,'source_before_sha256':sha(OUT/'source-before.json') if (OUT/'source-before.json').exists() else None,'source_after_sha256':sha(OUT/'source-after.json') if (OUT/'source-after.json').exists() else None,'space_observations':space,'free_after_cleanup':free_after,'native_approval':False,'full589_admission':False,'representation_fit_claimed':False,'source_cost_model_only':True,'source_model_version':2,'empty_phase_model_revision':3,'caller_grouping_revision':4,'compiled_component':compiled_binary,'only_optional_duplicate_parameter_records_removed':True,'anchors':'EMPTY'}
        durable('result.json',result)
    except BaseException as exc:result={'completed':False,'error':'Final durable result failed:'+type(exc).__name__,'earlier_error':error,'teardown_errors':teardown_errors}
    try:
        payload=(json.dumps({'completed':result['completed'],'error':result.get('error'),'result_file':'result.json','elapsed_seconds':time.monotonic()-START})+'\n').encode()
        if len(payload)>fallback_size:raise RuntimeError('Reserved fallback capacity exceeded')
        os.lseek(fallback_fd,0,os.SEEK_SET);os.write(fallback_fd,payload.ljust(fallback_size,b' '));os.fsync(fallback_fd)
    except BaseException:result['completed']=False
    finally:
        try:os.close(fallback_fd)
        except BaseException as exc:result['completed']=False;result['close_error']=type(exc).__name__
    if cancelled or time.monotonic()>FINAL_DEADLINE:result['completed']=False;result['late_finalize_refusal']=True
    print(json.dumps({'evidence':str(OUT),'completed':result['completed'],'elapsed_seconds':time.monotonic()-START,'error':result.get('error')}))
if cancelled or time.monotonic()>FINAL_DEADLINE:result['completed']=False;result['late_finalize_refusal']=True
if not result['completed']:
    try:durable('finalization-refusal.json',result)
    except BaseException:pass
raise SystemExit(0 if result['completed'] and not cancelled and time.monotonic()<=FINAL_DEADLINE else 1)
