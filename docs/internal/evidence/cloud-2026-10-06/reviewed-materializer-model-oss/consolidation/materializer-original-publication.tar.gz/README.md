Joined historical materializer component verification passed in 435.031 seconds. Original parser failure remains retained.

This selected packet contains small exact test logs, selected stage/wait records, counts, reviews, and hashes/sizes of all original root records. Large source, Go, tool and process-binding maps remain private at their original paths; they are not copied here.

Current seven anchors remain empty. The current compiled adapter and issued-current packet were not exercised. No standard-suite, native, provider, deployed or all 728 readiness promotion follows.
