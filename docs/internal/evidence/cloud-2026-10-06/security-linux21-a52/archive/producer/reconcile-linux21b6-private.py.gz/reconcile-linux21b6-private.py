from pathlib import Path
import json,hashlib,gzip,subprocess,tempfile,os,time,difflib,secrets
R=Path('/workspace/zasp-sec');C='21b6c51c2c177a12c9eef083ff7e291b3da02155';P=Path('/workspace/.zasp-cloud-owned/linux-source-five-publication-mntwz2d7');S=Path('/workspace/.zasp-cloud-owned/linux-source-five-publication-scan-mntwz2d7');old=Path('/tmp/zasp-cloud-evidence/linux21b6-scoped-1791265003486967303');O=Path(tempfile.mkdtemp(prefix='linux21b6-independent-reconciliation-',dir='/tmp/zasp-cloud-evidence'));h=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def ck(n,b):
 assert b,n
 checks.append(n)
def git(*args,cwd=R):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.DEVNULL)
def blob(p):return git('show',C+':'+p)
paths=git('diff-tree','--no-commit-id','--name-only','-r',C).decode().splitlines();ck('exact77 changed blobs',len(paths)==77)
manifest=json.loads((P/'manifest.json').read_text());prefix='docs/internal/evidence/cloud-2026-10-06/linux-reference-source-five/';bindings={prefix+f['path']:(P/f['path']).read_bytes() for f in manifest['members']};bindings[prefix+'manifest.json']=(P/'manifest.json').read_bytes();bindings[prefix+'independent-publication-review.json.gz']=gzip.compress(Path('/tmp/zasp-cloud-evidence/linux-source-publication-independent-2gp04ta2/review.json').read_bytes(),mtime=0)
for n in ['report.json','scan.log','record-and-classification.json']:bindings[prefix+'required-scan-supplement/'+n+'.gz']=gzip.compress((S/n).read_bytes(),mtime=0)
for f in manifest['members']:
 if f['path'].startswith('source/'):bindings['services/platform/migrations/tools/'+Path(f['path']).name]=(P/f['path']).read_bytes()
sp='docs/internal/evidence/cloud-2026-10-06/security-3e159796/';orig=Path('/tmp/zasp-cloud-evidence/doc3e-actual-scan-independent-attachment-f91b4b3cb8')
for f in orig.rglob('*'):
 if f.is_file():bindings[sp+str(f.relative_to(orig))]=f.read_bytes()
for n in paths:
 if n in bindings:
  # Encoding implementations may differ while decoded bytes are identical.
  b=blob(n);a=bindings[n];ck('actual commit reviewed original '+n,b==a or n.endswith('.gz') and gzip.decompress(b)==gzip.decompress(a))
 elif n.startswith(sp+'original-precommit-full-blob-failure/'):
  b=blob(n)
  if n.endswith('.gz'):
   data=gzip.decompress(b)
   if n.endswith('record.json.gz'):
    rec=json.loads(data);ck('original precommit actualFAIL4',rec['exit']==1 and rec['findings']==4);oldscan=Path('/tmp/zasp-cloud-evidence/staged-doc219-scan-xa471vtw')
   bindings[n]=data
  else:ck('honest precommit README scope',b'FAIL4' in b and b'unchanged historical' in b)
 else:raise AssertionError('unmapped changed blob '+n)
for n,data in list(bindings.items()):
 if n.startswith(sp+'original-precommit-full-blob-failure/'):
  fname=Path(n).name[:-3];actual=oldscan/('scan.log' if fname=='scan.log' else fname);ck('precommit gzip exactactual '+fname,data==actual.read_bytes())
ignore=blob('.gitleaksignore');ck('baseline ignore exact0ea',h(ignore)=='0ea55c26ab249af09129f0ee3d060373c9acdd079ba6d6cd363af0902f4d99d8' and (R/'.gitleaksignore').read_bytes()==ignore)
record=json.loads((old/'record.json').read_text());findings=json.loads((old/'report.json').read_text());ck('originalactualFAIL6',record['exit']==1 and record['findings']==len(findings)==6 and h((old/'report.json').read_bytes())==record['report_sha256'] and h((old/'scan.log').read_bytes())==record['log_sha256']);descriptor=json.loads(blob('services/platform/migrations/tools/ordered-current-linux-provenance-v1.json'));proved={}
for n in ['/lib/x86_64-linux-gnu/libgssapi_krb5.so.2','/lib/x86_64-linux-gnu/libkeyutils.so.1']:
 actual=h(Path(n).read_bytes());ck('public actual runtime bytes '+n,actual==descriptor['runtimeFiles'][n]);proved[actual]=n
classification=[]
for f in findings:
 b=blob(f['File']);line=b.decode().splitlines()[f['StartLine']-1];matches=[v for v in proved if v in line];ck('exact independent commit context '+f['File']+':'+str(f['StartLine']),f['Commit']==C and f['RuleID']=='generic-api-key' and len(matches)==1 and f['Fingerprint']==C+':'+f['File']+':generic-api-key:'+str(f['StartLine']));literal=matches[0];classification.append({'commit':C,'file':f['File'],'line':f['StartLine'],'rule':f['RuleID'],'fingerprint':f['Fingerprint'],'actualBlobGitOID':git('rev-parse',C+':'+f['File']).decode().strip(),'actualBlobSHA256':h(b),'publicDigestLiteralSHA256':h(literal.encode()),'actualRuntimePath':proved[literal],'classification':'computed-public-runtime-library-SHA256','credentialSemantic':False})
ck('six exactly2publicdigests aliases',len({x['publicDigestLiteralSHA256'] for x in classification})==2)
fps=sorted(x['fingerprint'] for x in classification);ck('six unique no preexisting',len(set(fps))==6 and all(f.encode() not in ignore for f in fps));ck('prefix newline',ignore.endswith(b'\n'));candidate=ignore+('\n'.join(fps)+'\n').encode();(O/'candidate.gitleaksignore').write_bytes(candidate);(O/'candidate.patch').write_text(''.join(difflib.unified_diff(ignore.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='a/.gitleaksignore',tofile='b/.gitleaksignore')))
classified={'status':'SIX-PUBLIC-DIGEST-COORDINATES-INDEPENDENTLY-CLASSIFIED','originalScan':'FAIL6','unknown':0,'findings':classification,'baselineIgnoreSHA256':h(ignore),'candidateIgnoreSHA256':h(candidate),'addedExactFingerprints':fps,'newExceptions':6,'otherExceptions':0,'checks':checks};(O/'classification.json').write_text(json.dumps(classified,indent=2)+'\n')
W=O/'owned-detached-worktree';subprocess.run(['git','clone','--shared','--no-checkout','--quiet',str(R),str(W)],check=True,stderr=subprocess.DEVNULL);git('update-ref','--no-deref','HEAD',C,cwd=W);git('read-tree',C,cwd=W);(W/'.gitleaksignore').write_bytes(ignore);env=dict(os.environ);ck('no inherited scanner config',not any(k.startswith('GITLEAKS') for k in env));scanrecords=[]
def scan(label,range,expected):
 cmd=['/tmp/zasp-cloud-tools/bin/gitleaks','git','--no-banner','--redact','--log-opts='+range,'--report-format','json','--report-path',str(O/(label+'-report.json'))];start=time.monotonic()
 with (O/(label+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=W,env=env,stdout=log,stderr=log,timeout=120)
 rows=json.loads((O/(label+'-report.json')).read_text());ck(label+' actualexpectedcount',len(rows)==expected and p.returncode==(1 if expected else 0));scanrecords.append({'label':label,'argv':cmd,'cwd':str(W),'exit':p.returncode,'seconds':time.monotonic()-start,'findings':len(rows),'reportPath':str(O/(label+'-report.json')),'reportSHA256':h((O/(label+'-report.json')).read_bytes()),'logPath':str(O/(label+'.log')),'logSHA256':h((O/(label+'.log')).read_bytes()),'ignoreSHA256':h((W/'.gitleaksignore').read_bytes()),'coordinates':[{'commit':r['Commit'],'file':r['File'],'line':r['StartLine'],'rule':r['RuleID'],'fingerprint':r['Fingerprint']} for r in rows]});return rows
red=scan('exact21-baseline-red',C+'^..'+C,6);ck('independentREDexactoriginalcoordinates',{r['Fingerprint'] for r in red}==set(fps));(W/'.gitleaksignore').write_bytes(candidate);scan('exact21-candidate-green',C+'^..'+C,0)
path='services/platform/migrations/tools/ordered-current-linux-provenance-v1.json';text=blob(path).decode();tokens=[secrets.token_hex(32) for _ in range(2)];
for oldvalue,newvalue in zip(proved,tokens):text=text.replace(oldvalue,newvalue)
f=W/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text);git('add','--',path,cwd=W);git('-c','user.name=Independent Synthetic Canary','-c','user.email=nonfunctional@example.invalid','commit','--quiet','-m','Private synthetic same-path detection control',cwd=W);same=git('rev-parse','HEAD',cwd=W).decode().strip();sr=scan('futurecommit-samepath-red',C+'..'+same,2);ck('future samepath still detected',all(r['Commit']==same and r['File']==path for r in sr))
newpath='independent-private-canary/new-path-provenance.json';f=W/newpath;f.parent.mkdir(parents=True);f.write_text(text);git('add','--',newpath,cwd=W);git('-c','user.name=Independent Synthetic Canary','-c','user.email=nonfunctional@example.invalid','commit','--quiet','-m','Private synthetic new-path detection control',cwd=W);new=git('rev-parse','HEAD',cwd=W).decode().strip();nr=scan('futurecommit-newpath-red',same+'..'+new,2);ck('newpath still detected',all(r['Commit']==new and r['File']==newpath for r in nr));scan('combined-future-controls-red',C+'..'+new,4)
# Synthetic literals retained only within private Git objects; no raw reports or values published.
report={'status':'PASS-BOUNDED-EXACT-SIX-FINGERPRINT-CANDIDATE','issues':[],'sourceCommit':C,'changedBlobs':77,'classificationPath':str(O/'classification.json'),'classificationSHA256':h((O/'classification.json').read_bytes()),'candidatePath':str(O/'candidate.gitleaksignore'),'candidateSHA256':h(candidate),'patchPath':str(O/'candidate.patch'),'patchSHA256':h((O/'candidate.patch').read_bytes()),'baselineSHA256':h(ignore),'exactAddedFingerprintCount':6,'originalScan':'FAIL6 remains unchanged','scans':scanrecords,'checkCount':len(checks),'checks':checks,'worktree':'Owned detached shared-object clone, index exact21; only ignore and canary files materialized, no source/compiler/provider execution','limits':['No shared ignore/config/rule/HEAD/history/staging/push mutations','Six exact commit:path:rule:line coordinates only; future samepath/newpath synthetic controls remain detected','CandidateGREEN exact21scope only; root must independently review/apply and scan newactualHEAD/fullhistory','Original sourceFAIL2/publicationFAIL4/exact21FAIL6 unchanged','No runtime/native/provider/deployed/advisory clearance']};(O/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(O/'review.json'),'sha256':h((O/'review.json').read_bytes()),'candidateSHA256':h(candidate),'counts':[x['findings'] for x in scanrecords],'checks':len(checks)}))
