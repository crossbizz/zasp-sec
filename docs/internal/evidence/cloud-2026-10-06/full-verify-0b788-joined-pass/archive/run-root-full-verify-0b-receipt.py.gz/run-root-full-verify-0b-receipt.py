import os,json,time,subprocess,hashlib,pathlib,signal,ctypes,uuid
P=pathlib.Path
base=P('/tmp/zasp-cloud-evidence')/('root-full-0b-'+uuid.uuid4().hex);base.mkdir(mode=0o700);os.umask(0o077)
repo=P('/workspace/.zasp-cloud-owned/sbom-0b-graph-diagnosis-pgt18jsv/candidate')
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
def put(name,x):
 p=base/name
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 p.chmod(0o400)
assert git('rev-parse','HEAD')=='0b788520159170a825a925a3f639b0b1d63169f5'
assert git('status','--porcelain','--untracked-files=no')==''
assert (repo/'node_modules').is_dir() and not (repo/'node_modules').is_symlink()
env=os.environ.copy();tmp=repo.parent/('root-full-tmp-'+base.name);tmp.mkdir(mode=0o700)
env.update(PATH='/tmp/zasp-cloud-tools/node-v22.23.1-linux-x64/bin:/tmp/zasp-cloud-tools/go/bin:/tmp/zasp-cloud-tools/bin:/tmp/zasp-cloud-tools/postgres-18.3/bin:/usr/bin:/bin',GOROOT='/tmp/zasp-cloud-tools/go',GOTOOLCHAIN='local',GOPROXY='direct',GOFLAGS='-mod=readonly',TMPDIR=str(tmp))
assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
before={'source_sha':git('rev-parse','HEAD'),'tracked_status':git('status','--porcelain','--untracked-files=no'),'argv':['/tmp/zasp-cloud-tools/bin/tini','-s','--','npm','run','verify'],'cwd':str(repo),'environment_overrides':{k:env[k] for k in ['PATH','GOROOT','GOTOOLCHAIN','GOPROXY','GOFLAGS','TMPDIR']},'umask':'0077','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'outer_seconds':1500,'cleanup_seconds':30,'scope':'Unchanged complete npm verify; new receipt-bound retry after prior missing owner exit. No provider/PG optins or source/guard/dependency changes.'}
put('before.json',before);started=time.monotonic();timedout=False
with (base/'verify.log').open('xb') as log:
 p=subprocess.Popen(before['argv'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 stat=P(f'/proc/{p.pid}/stat').read_text();fields=stat[stat.rfind(')')+2:].split();put('process-binding.json',{'pid':p.pid,'process_group':os.getpgid(p.pid),'session':os.getsid(p.pid),'kernel_start_ticks':fields[19],'kernel_stat_sha256':hashlib.sha256(stat.encode()).hexdigest(),'source_sha':before['source_sha'],'argv':before['argv']});print(json.dumps({'root_evidence':str(base),'pid':p.pid,'source_sha':before['source_sha']}),flush=True)
 try:code=p.wait(timeout=1500)
 except subprocess.TimeoutExpired:
  timedout=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=30)
 survivors=[];joined=[];joinend=time.monotonic()+30
 while time.monotonic()<joinend:
  try:children=P(f'/proc/self/task/{os.getpid()}/children').read_text().split()
  except FileNotFoundError:children=[]
  if not children:break
  for child in children:
   try:
    got,status=os.waitpid(int(child),os.WNOHANG)
    if got:joined.append({'pid':got,'wait_status':status})
   except ChildProcessError:pass
  time.sleep(.1)
 try:survivors=P(f'/proc/self/task/{os.getpid()}/children').read_text().split()
 except FileNotFoundError:survivors=[]
 result={'exit_code':code,'timed_out':timedout,'main_wait_joined':True,'unexpected_surviving_children':survivors,'adopted_children_joined':joined,'elapsed_seconds':round(time.monotonic()-started,3),'completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source_sha_before':before['source_sha'],'source_sha_after':git('rev-parse','HEAD'),'tracked_status_after':git('status','--porcelain','--untracked-files=no'),'log_sha256':hashlib.sha256((base/'verify.log').read_bytes()).hexdigest()};put('result.json',result);print(json.dumps(result),flush=True)
raise SystemExit(code if code else (1 if timedout or survivors or result['source_sha_after']!=before['source_sha'] or result['tracked_status_after'] else 0))
