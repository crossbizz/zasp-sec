process.stdout.write('UNPINNED_GENERATOR_TOP_LEVEL_EXECUTED\n'); export function buildOrderedCurrentLinuxSuccessorV1(){throw Error('untrusted generator');}
