import subprocess,pathlib,json,time,hashlib
base=pathlib.Path(__file__).parent;node='/tmp/zasp-cloud-tools/node-v22.23.1-linux-x64/bin/node';tools='services/platform/migrations/tools/';env={'PATH':str(pathlib.Path(node).parent)+':/usr/bin:/bin','TMPDIR':str(base/'tmp'),'TZ':'UTC','LANG':'C','LC_ALL':'C'}
for label,args,extra in [('actual-v2-reference-behavioral-red',['--test','--test-name-pattern=actual reference boundary',tools+'ordered-current-native379-packet-v3.test.mjs'],{'ZASP_NATIVE379_V3_OFFLINE_BASELINE':'v2'}),('v3-initial-group-green',['--test',tools+'ordered-current-native379-source-schema-v3.test.mjs',tools+'ordered-current-native379-packet-v3.test.mjs'],{})]:
 argv=[node,*args];start=time.monotonic();log=base/'evidence'/(label+'.log')
 with log.open('wb') as f:r=subprocess.run(argv,cwd=base/'source',env=env|extra,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 record={'label':label,'argv':argv,'cwd':str(base/'source'),'environment':env|extra,'exit':r.returncode,'directProcessJoined':True,'seconds':time.monotonic()-start,'logSHA256':hashlib.sha256(log.read_bytes()).hexdigest(),'sourceCommit':'21b6c51c2c177a12c9eef083ff7e291b3da02155','scope':'offline Node source/draft controls only; no final wire/native/Go'}
 (base/'evidence'/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
