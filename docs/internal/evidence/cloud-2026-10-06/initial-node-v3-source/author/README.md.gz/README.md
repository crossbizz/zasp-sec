Initial four private v3 source files only. Final group7PASS/0FAIL/0SKIP55.177s; exact sources and actual argv/minimal environment are retained. All original Git21b6 source bytes remain equal; only four new source files exist.

Retained actual v2 reference behavioral RED and runtime-before-source behavioral RED are distinct from test-comparison failures. v3-initial-group-green.log is4PASS/2FAIL; green-2 is6PASS/1FAIL; green-3 is actual7PASS. No final artifacts/source roster/wire/anchors/Go/PG/native evidence is issued. Native/raw APIs remain closed. No shared edits.
