import test from 'node:test';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {readOrderedCurrentNative379LinuxReferenceV3,assertOrderedCurrentNative379LinuxReferenceV3,admitOrderedCurrentNative379SourceV3,native379V3Canonical} from './ordered-current-native379-source-schema-v3.mjs';
import {readOrderedCurrentLinuxProvenanceV1} from './ordered-current-linux-provenance-v1.mjs';
let reference;
const load=()=>structuredClone(reference??=readOrderedCurrentNative379LinuxReferenceV3());
test('v3 reference binds exact reviewed Linux capture while final source admission remains closed',()=>{
 const r=load(),identity=readOrderedCurrentLinuxProvenanceV1();
 assert.equal(r.identity.postgres,identity.identity.version);assert.equal(r.referenceProvenance.postgres,r.identity.postgres);
 assert.equal(r.identity.serverVersionNum,180003);assert.equal(r.identity.pgcrypto,'1.4');assert.equal(Object.keys(r.source5Pins).length,5);assert.equal(Object.keys(r.outputs).length,8);
 assert.equal(r.installable,false);assert.equal(r.nativeVerified,false);assert.equal(r.captureAuthority,false);
 assert.throws(()=>admitOrderedCurrentNative379SourceV3(),/frozen Go v3/);
 assert.throws(()=>readOrderedCurrentNative379LinuxReferenceV3({}),/caller-selected/);
});
test('v3 reference refuses historical reference, omitted source/output and status promotion',()=>{
 const r=load();
 for(const mutate of [q=>q.referenceProvenance.postgres='PostgreSQL 18.3 (Homebrew)',q=>q.identity.postgres+=' borrowed',q=>delete q.source5Pins['ordered-current-linux-provenance-v1.json'],q=>delete q.outputs['development-module.sql'],q=>q.outputPins['development-module.sql']='0'.repeat(64),q=>q.outputs['development-module.sql']+='\n',q=>q.manifestPayloadSHA256='0'.repeat(64),q=>q.nativeVerified=true,q=>q.pending=[]]){const q=structuredClone(r);mutate(q);assert.throws(()=>assertOrderedCurrentNative379LinuxReferenceV3(q),/closed Linux/);}
});
test('v3 closure comparison refuses accessors, symbols and ambiguous array authority',()=>{
 const r=load();const q=structuredClone(r);Object.defineProperty(q,'installable',{get(){throw Error('getter invoked');}});assert.throws(()=>assertOrderedCurrentNative379LinuxReferenceV3(q),/accessor/);
 assert.throws(()=>native379V3Canonical([,1]),/sparse/);assert.throws(()=>native379V3Canonical({value:NaN}),/noninteger/);assert.throws(()=>native379V3Canonical({[Symbol('authority')]:true}),/symbol/);
});

test('wrong Node runtime refuses before any reviewed source assembly read',()=>{
 const url=new URL('./ordered-current-native379-source-schema-v3.mjs',import.meta.url).href;
 const code=`import fs from 'node:fs'; Object.defineProperty(process,'version',{value:'v22.23.0'}); fs.readFileSync=()=>{throw Error('reviewed input read before runtime refusal');}; try{await import(${JSON.stringify(url)});process.exitCode=2;}catch(e){if(!/approved executable SHA256/.test(e.message)){process.stderr.write(e.message);process.exitCode=3;}}`;
 const r=spawnSync(process.execPath,['--input-type=module','-e',code],{encoding:'utf8',timeout:10000,maxBuffer:1048576,env:{PATH:process.env.PATH,TMPDIR:process.env.TMPDIR,TZ:'UTC',LANG:'C'}});
 assert.equal(r.error,undefined);assert.equal(r.signal,null);assert.equal(r.status,0,r.stderr);
});
