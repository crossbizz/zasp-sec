// Initial v3 source/reference boundary. Final Go/source manifest is not issued.
// Reads only fixed reviewed source bytes; no target, credentials or SQL execution.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {admitOrderedCurrentNative379SourceV2,readNative379RegularSourceV2} from './ordered-current-native379-source-schema-v2.mjs';
import {buildOrderedCurrentLinuxSuccessorV1} from './build-ordered-current-linux-successor-v1.mjs';
import {readOrderedCurrentLinuxProvenanceV1} from './ordered-current-linux-provenance-v1.mjs';
const root=path.resolve(fileURLToPath(new URL('../../../../',import.meta.url)));
const tools='services/platform/migrations/tools/';
const pins=Object.freeze({
 'build-ordered-current-linux-successor-v1.mjs':'b5a8d9dc9e11a52d07113b3d315ef9c04cc46774e452ebe7a80be366038f2249',
 'build-ordered-current-linux-successor-v1.test.mjs':'94dea86cf72c42b687ec28909b76b7eb06d0292190684c1b9084271a522f70a1',
 'ordered-current-linux-provenance-v1.mjs':'64b0d211765c03071d124d1443831d2d9c3f60393878eadcbaf6ac4635be80e0',
 'ordered-current-linux-provenance-v1.test.mjs':'9e1658847bbc433dcc3755b7d75dfd792b66743153832f7dff37c0a819b60c38',
 'ordered-current-linux-provenance-v1.json':'68425b6efc85e163c5028dadb4b8ff3ec219dfb5d7a8a2772c73a58a45dddfb5'});
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const fail=message=>{throw Error('ordered-current native379 v3 source '+message);};
export function native379V3Canonical(value){
 if(value===null||typeof value==='string'||typeof value==='boolean')return JSON.stringify(value);
 if(typeof value==='number'){if(!Number.isSafeInteger(value))fail('noninteger/nonfinite authority');return JSON.stringify(value);}
 if(typeof value!=='object')fail('non-JSON authority');
 const descriptors=Object.getOwnPropertyDescriptors(value),keys=Reflect.ownKeys(value);
 if(keys.some(key=>typeof key!=='string')||Object.values(descriptors).some(d=>!Object.hasOwn(d,'value')))fail('accessor/symbol authority');
 if(Array.isArray(value)){
  if(Object.getPrototypeOf(value)!==Array.prototype||keys.length!==value.length+1)fail('array authority');
  for(let i=0;i<value.length;i++)if(!Object.hasOwn(descriptors,String(i)))fail('sparse authority');
  return '['+Array.from({length:value.length},(_,i)=>native379V3Canonical(descriptors[i].value)).join(',')+']';
 }
 if(Object.getPrototypeOf(value)!==Object.prototype)fail('object authority');
 return '{'+Object.keys(descriptors).sort().map(k=>JSON.stringify(k)+':'+native379V3Canonical(descriptors[k].value)).join(',')+'}';
}
let admitted;
export function readOrderedCurrentNative379LinuxReferenceV3(){
 if(arguments.length)fail('caller-selected source authority');
 // Recheck immutable baseline and all five newly reviewed inputs on each read.
 admitOrderedCurrentNative379SourceV2();
 for(const [name,pin]of Object.entries(pins))readNative379RegularSourceV2(root,tools+name,pin);
 if(!admitted){
  const descriptor=readOrderedCurrentLinuxProvenanceV1(),built=buildOrderedCurrentLinuxSuccessorV1();
  if(built.installable!==false||built.nativeVerified!==false||built.expectedFromTarget!==false||built.facts.length!==10052||Object.keys(built.outputs).length!==8)fail('source assembly status/cardinality');
  const manifest=JSON.parse(built.outputs['development-manifest.json']);
  const build=manifest.facts.filter(f=>f.kind==='build'&&f.identity==='provenance');
  if(build.length!==1||build[0].fact.postgres!==descriptor.identity.version||build[0].fact.pgcrypto!==descriptor.identity.pgcrypto)fail('exact Linux reference identity');
  admitted={format:'ordered-current-native379-linux-reference-v3',status:'SOURCE-REFERENCE-ONLY',installable:false,nativeVerified:false,captureAuthority:false,source5Pins:{...pins},descriptorSHA256:pins['ordered-current-linux-provenance-v1.json'],identitySHA256:descriptor.evidence.identitySHA256,identity:{postgres:descriptor.identity.version,serverVersionNum:Number(descriptor.identity.server_version_num),pgcrypto:descriptor.identity.pgcrypto},outputs:built.outputs,outputPins:Object.fromEntries(Object.entries(built.outputs).map(([name,text])=>[name,sha(text)])),manifestPayloadSHA256:manifest.payloadSHA256,referenceProvenance:build[0].fact,pending:['source5-verified-push','frozen-Go-v3-implementation','complete-reviewed-v3-source-manifest-and-artifacts','independent-full-v3-wire-and-Go-review','new-frozen-runtime-envelopes','root-owned-native589-acceptance']};
 }
 return structuredClone(admitted);
}
export function assertOrderedCurrentNative379LinuxReferenceV3(value){
 if(arguments.length!==1||native379V3Canonical(value)!==native379V3Canonical(readOrderedCurrentNative379LinuxReferenceV3()))fail('closed Linux reference/output/source/status mismatch');
 return true;
}
export function admitOrderedCurrentNative379SourceV3(){
 if(arguments.length)fail('caller-selected authority');
 fail('final source5 push, frozen Go v3 implementation and independently reviewed source manifest required');
}
