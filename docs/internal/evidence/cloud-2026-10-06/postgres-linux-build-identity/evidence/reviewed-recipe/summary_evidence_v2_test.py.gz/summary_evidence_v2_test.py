"""Actual private filesystem faults; imports definitions only, never PG main."""
import ast, pathlib, tempfile, unittest
ROOT=pathlib.Path(__file__).parent
source=ROOT/'capture-root-pg-build-identity-v2.py'
tree=ast.parse(source.read_bytes())
nodes=[n for n in tree.body if isinstance(n,ast.Import) or (isinstance(n,ast.FunctionDef) and n.name in {'sha','summary_evidence'})]
ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),ns)
class Tests(unittest.TestCase):
    def test_missing_binding_and_identity_have_null_hash_and_errors(self):
        with tempfile.TemporaryDirectory(prefix='zasp-summary-evidence-') as d:
            r=pathlib.Path(d);review=r/'review';review.write_text('actual review bytes')
            e=ns['summary_evidence'](r/'missing-binding',review,r/'missing-identity',[r/'socket'],r/'pid')
            self.assertIsNone(e['binding_sha256']);self.assertIsNone(e['identity_file_sha256']);self.assertEqual([x['label'] for x in e['summary_evidence_errors']],['binding','identity']);self.assertTrue(e['unix_endpoint_clear']);self.assertTrue(e['postmaster_pidfile_clear'])
    def test_actual_non_directory_endpoint_is_unverified_not_clear(self):
        with tempfile.TemporaryDirectory(prefix='zasp-summary-evidence-') as d:
            r=pathlib.Path(d);p=r/'regular';p.write_text('actual bytes')
            e=ns['summary_evidence'](p,p,p,[p/'invalid-child'],r/'pid')
            self.assertIsNone(e['unix_endpoint_clear']);self.assertEqual(e['summary_evidence_errors'],[{'label':'unix-endpoint','failure_class':'NotADirectoryError'}]);self.assertTrue(e['postmaster_pidfile_clear'])
if __name__=='__main__':unittest.main(verbosity=2)
