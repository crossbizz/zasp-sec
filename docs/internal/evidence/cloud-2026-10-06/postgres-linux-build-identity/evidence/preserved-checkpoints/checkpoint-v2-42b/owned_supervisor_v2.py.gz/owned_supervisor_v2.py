"""Bounded owned OS-process supervision; no PostgreSQL implementation."""
import hashlib, json, os, pathlib, signal, subprocess, time

class OwnedFailure(RuntimeError):
    pass

class OwnedSupervisor:
    def __init__(self, root, env, capture_seconds=180, cleanup_seconds=30):
        if not 0 < cleanup_seconds <= 30:
            raise ValueError('cleanup maximum')
        self.root=pathlib.Path(root);self.env=dict(env)
        self.started=time.monotonic();self.capture_deadline=self.started+capture_seconds
        self.cleanup_seconds=cleanup_seconds;self.cleanup_deadline=None
        self.processes={};self.records=[];self.failure=False;self.cleanup_errors=[];self.foreground_records=[]
    def begin_cleanup(self):
        if self.cleanup_deadline is None:
            self.cleanup_deadline=time.monotonic()+self.cleanup_seconds
        return self.cleanup_deadline
    def left(self):
        return max(0,self.begin_cleanup()-time.monotonic())
    def members(self, group):
        result=[]
        for p in pathlib.Path('/proc').iterdir():
            if not p.name.isdigit():continue
            try:
                raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
                if int(f[2])==group:result.append(int(p.name))
            except (FileNotFoundError,ProcessLookupError):pass
        return sorted(result)
    def reap(self, group):
        while True:
            try:
                pid,_=os.waitpid(-group,os.WNOHANG)
                if not pid:break
            except ChildProcessError:break
    def record(self, label, data):
        (self.root/(label+'-record.json')).write_text(json.dumps(data,indent=2)+'\n')
    def finish(self, proc, record, exceptional=False):
        # Always runs for every successfully started process, including signals.
        if exceptional or proc.poll() is None:
            record['forced_cleanup']=True;self.failure=True;self.begin_cleanup()
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        if proc.returncode is None:
            remaining=self.left()
            if remaining>0:
                try:proc.wait(timeout=remaining)
                except subprocess.TimeoutExpired:self.failure=True
        record['joined']=proc.returncode is not None
        record['exit']=proc.returncode
        self.reap(proc.pid)
        remaining_members=self.members(proc.pid)
        if remaining_members:
            record['unexpected_descendants']=True;record['forced_cleanup']=True
            self.failure=True;self.begin_cleanup()
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            while self.left()>0:
                self.reap(proc.pid)
                if not self.members(proc.pid):break
                time.sleep(min(.02,self.left()))
        record['survivors']=self.members(proc.pid)
        if not record['joined'] or record['survivors']:self.failure=True
    def run(self, label, argv, cap, cleanup=False, allowed_codes=(0,)):
        if self.cleanup_deadline is not None and not cleanup:
            raise OwnedFailure('capture closed after cleanup began')
        deadline=self.begin_cleanup() if cleanup else self.capture_deadline-30
        available=deadline-time.monotonic()
        reserve=min(1,self.cleanup_seconds/4) if cleanup else 0
        limit=min(cap,max(0,available-reserve))
        if limit<=0:raise OwnedFailure('owned command deadline')
        rec={'label':label,'argv':argv,'started':False,'joined':False,'timed_out':False,'interrupted':False,'forced_cleanup':False,'unexpected_descendants':False,'survivors':[],'exit':None}
        proc=None;error=None;before=time.monotonic()
        try:
            with (self.root/(label+'.stdout')).open('xb') as out,(self.root/(label+'.stderr')).open('xb') as err:
                proc=subprocess.Popen(argv,env=self.env,cwd=self.root,stdout=out,stderr=err,start_new_session=True)
                rec['started']=True;rec['pid']=proc.pid;self.processes[proc.pid]=proc
                try:proc.wait(timeout=limit)
                except subprocess.TimeoutExpired:
                    rec['timed_out']=True;raise OwnedFailure('owned command timeout')
                except BaseException:
                    rec['interrupted']=True;raise
        except BaseException as exc:
            error=exc;self.failure=True;self.begin_cleanup();rec['failure_class']=type(exc).__name__
        finally:
            try:
                if proc is not None:self.finish(proc,rec,error is not None)
            except BaseException as exc:
                self.failure=True;rec['cleanup_failure_class']=type(exc).__name__
                if error is None:error=exc
            finally:
                rec['seconds']=round(time.monotonic()-before,6)
                for suffix in ['stdout','stderr']:
                    output=self.root/(label+'.'+suffix)
                    rec[suffix+'_sha256']=hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None
                self.records.append(rec);self.record(label,rec)
        if error is not None:raise error
        if rec['forced_cleanup'] or rec['unexpected_descendants'] or not rec['joined'] or rec['survivors'] or rec['exit'] not in allowed_codes:
            self.failure=True;self.begin_cleanup();raise OwnedFailure('owned command refused')
        return rec['exit'],(self.root/(label+'.stdout')).read_text()
    def foreground(self, label, argv):
        if self.cleanup_deadline is not None:raise OwnedFailure('capture closed')
        log=(self.root/(label+'.log')).open('xb')
        try:proc=subprocess.Popen(argv,env=self.env,cwd=self.root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        except BaseException:log.close();raise
        self.processes[proc.pid]=proc
        rec={'label':label,'argv':argv,'pid':proc.pid,'started':True,'log':str(self.root/(label+'.log'))}
        self.foreground_records.append(rec)
        try:self.record(label+'-start',rec)
        except BaseException:
            log.close();self.failure=True;self.begin_cleanup();raise
        return proc,log
    def finalize(self):
        self.begin_cleanup()
        # The one deadline is never reset between stop, wait, fallback and reap.
        for pid,proc in self.processes.items():
            rec={'pid':pid,'joined':False,'exit':None,'forced_cleanup':False,'unexpected_descendants':False,'survivors':[]}
            try:self.finish(proc,rec,proc.poll() is None)
            except BaseException as exc:self.failure=True;rec['cleanup_failure_class']=type(exc).__name__
            self.cleanup_errors.append(rec)
        groups={str(pid):self.members(pid) for pid in self.processes}
        if any(groups.values()):self.failure=True
        return groups
