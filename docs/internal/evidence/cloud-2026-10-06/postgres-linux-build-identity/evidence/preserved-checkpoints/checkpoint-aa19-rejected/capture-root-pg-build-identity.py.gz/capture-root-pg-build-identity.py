"""ROOT-ONLY prospective identity capture. Never a native acceptance runner."""
import ctypes, hashlib, json, os, pathlib, signal, stat, subprocess, time, uuid
P = pathlib.Path
PG = P('/tmp/zasp-cloud-tools/postgres-18.3')
BINDING = P('/tmp/zasp-cloud-evidence/runtime-continuation/native379-v2-root-reviewed-pg-binding.json')
REVIEW = P('/tmp/zasp-cloud-evidence/runtime-continuation/independent-provider-fresh0b-PG-static-review.json')
EXTRA = {'bin/psql': '83513bb26d0cd69c92a95b584c4fd96ac2d808da93136693832dbbeb23510b9f', 'usr/lib/postgresql/18/bin/psql': '9b19f53d3de23ea9d7d909e551e0bbb803d796db54fc7b906c5027805c9bf1f5'}
HOST_EXTRA = {'/lib/x86_64-linux-gnu/libreadline.so.8': 'a3334d88f3f6c6a25736667e0b39db0f68b4e7e6bf758a475aff681ddb33ad8b', '/lib/x86_64-linux-gnu/libtinfo.so.6': '4013e7651ac68f547d8333517def25b2366c97eec7de7f06e105dbf3444ffebf'}
QUERY = "SELECT pg_catalog.json_build_object('version',pg_catalog.version(),'server_version_num',pg_catalog.current_setting('server_version_num'),'pgcrypto',(SELECT e.extversion FROM pg_catalog.pg_extension e WHERE e.extname='pgcrypto'),'backend_pid',pg_catalog.pg_backend_pid(),'session_user',session_user,'current_user',current_user,'tcp_address',pg_catalog.inet_server_addr(),'tcp_port',pg_catalog.inet_server_port());"

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def checked(p, pin):
    real = p.resolve(strict=True)
    if not real.is_file() or sha(real) != pin or os.access(real, os.W_OK):
        raise RuntimeError('pinned file/hash/permission refused')

def group_members(group):
    found = []
    for p in P('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            raw = (p/'stat').read_text(); fields = raw[raw.rfind(')')+2:].split()
            if int(fields[2]) == group:
                found.append(int(p.name))
        except (FileNotFoundError, ProcessLookupError):
            pass
    return sorted(found)

def reap_group(group):
    while True:
        try:
            pid, _ = os.waitpid(-group, os.WNOHANG)
            if pid == 0:
                break
        except ChildProcessError:
            break

def clean_group(group):
    reap_group(group)
    if group_members(group):
        try:
            os.killpg(group, signal.SIGKILL)
        except ProcessLookupError:
            pass
        until = time.monotonic()+5
        while time.monotonic() < until:
            reap_group(group)
            if not group_members(group):
                break
            time.sleep(.05)
    return group_members(group)

def main():
    if os.getuid() != 1000:
        raise RuntimeError('reviewed session UID required')
    checked(BINDING, '40f499a12a8b69daa2f2e6bf527d74e01a7fdd4110b18b025b9ea6887275a500')
    checked(REVIEW, 'b179d099aad696a11ae8dd4552976cdbfd6e70f05978c4fcc2ef804683b181e6')
    binding = json.loads(BINDING.read_text())
    mapping = {str(PG/'bin'/n): h for n,h in binding['pg_binary_sha256'].items()}
    mapping.update(binding['pg_extension_files'])
    mapping.update({str(PG/n):h for n,h in EXTRA.items()})
    mapping.update(HOST_EXTRA)
    for p,h in mapping.items():
        checked(P(p),h)
    for n in [*binding['pg_binary_sha256'], 'psql']:
        expected = '#!/bin/sh\nexport LD_LIBRARY_PATH="'+str(PG/'deps')+'${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"\nexec '+str(PG/'usr/lib/postgresql/18/bin'/n)+' "$@"\n'
        if (PG/'bin'/n).read_text() != expected:
            raise RuntimeError('wrapper text refused')
    if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0) != 0:
        raise RuntimeError('Linux subreaper unavailable')
    os.umask(0o077)
    root=P('/workspace/.zasp-cloud-owned')/('pgid-'+uuid.uuid4().hex)
    root.mkdir(mode=0o700)
    socket=root/'sock'; socket.mkdir(mode=0o700)
    home=root/'home';home.mkdir(mode=0o700)
    tmp=root/'tmp';tmp.mkdir(mode=0o700)
    data=root/'data'
    env={'PATH':str(PG/'bin')+':/usr/bin:/bin','HOME':str(home),'TMPDIR':str(tmp),'LANG':'C','LC_ALL':'C','TZ':'UTC'}
    assert set(env)=={'PATH','HOME','TMPDIR','LANG','LC_ALL','TZ'}
    started=time.monotonic(); deadline=started+180; records=[]; server=None; serverlog=None; identity=None; failure=None; stopped=False; waitcode=None; forced=False
    def run(label,argv,cap,cleanup=False):
        available=(deadline+30 if cleanup else deadline-30)-time.monotonic()
        if available<=0:
            raise RuntimeError('capture deadline reached')
        out=root/(label+'.stdout'); err=root/(label+'.stderr')
        before=time.monotonic(); timed=False
        with out.open('xb') as a, err.open('xb') as b:
            proc=subprocess.Popen(argv,env=env,cwd=root,stdout=a,stderr=b,start_new_session=True)
            try:
                code=proc.wait(timeout=min(cap,available))
            except subprocess.TimeoutExpired:
                timed=True
                os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=5)
        survivors=clean_group(proc.pid)
        records.append({'label':label,'argv':argv,'exit':code,'timed_out':timed,'seconds':round(time.monotonic()-before,6),'joined':True,'survivors':survivors,'stdout_sha256':sha(out),'stderr_sha256':sha(err)})
        if timed or survivors or code:
            raise RuntimeError('bounded command refused: '+label)
        return out.read_text()
    def interrupted(signum, frame):
        raise RuntimeError('capture interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        run('initdb',[str(PG/'bin/initdb'),'-D',str(data),'--username=pgcapture','--auth-local=trust','--auth-host=reject','--encoding=UTF8','--no-locale'],60)
        serverlog=(root/'postgres.log').open('xb')
        argv=[str(PG/'bin/postgres'),'-D',str(data),'-k',str(socket),'-p','5432','-c','listen_addresses=','-c','unix_socket_permissions=0700','-c','max_connections=10','-c','shared_buffers=16MB','-c','statement_timeout=10000']
        server=subprocess.Popen(argv,env=env,cwd=root,stdout=serverlog,stderr=subprocess.STDOUT,start_new_session=True)
        ready=False; until=min(time.monotonic()+20,deadline-30)
        while time.monotonic()<until:
            if server.poll() is not None:
                raise RuntimeError('foreground PostgreSQL exited before readiness')
            try:
                run('ready-'+str(len(records)),[str(PG/'bin/pg_isready'),'-h',str(socket),'-p','5432','-U','pgcapture','-d','postgres','-t','1'],3)
                ready=True;break
            except RuntimeError:
                time.sleep(.1)
        if not ready:
            raise RuntimeError('owned Unix socket readiness refused')
        client=[str(PG/'bin/psql'),'-X','--no-psqlrc','-h',str(socket),'-p','5432','-U','pgcapture','-d','postgres','-v','ON_ERROR_STOP=1','-A','-t']
        run('owned-empty-extension',client+['-c','CREATE EXTENSION pgcrypto;'],10)
        raw=run('readonly-build-identity',client+['-c',QUERY],10)
        identity=json.loads(raw)
        if identity['server_version_num']!='180003' or identity['pgcrypto']!='1.4' or not identity['version'].startswith('PostgreSQL 18.3 ') or 'linux' not in identity['version'].lower() or identity['tcp_address'] is not None or identity['tcp_port'] is not None or identity['current_user']!='pgcapture' or identity['session_user']!='pgcapture' or type(identity['backend_pid']) is not int or identity['backend_pid']<=1:
            raise RuntimeError('actual identity shape/version/socket refused')
        (root/'actual-build-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    except Exception as error:
        failure=type(error).__name__+': '+str(error)
    finally:
        if server is not None:
            try:
                run('normal-stop',[str(PG/'bin/pg_ctl'),'-D',str(data),'-m','fast','-w','-t','15','stop'],20,True)
                stopped=True
                waitcode=server.wait(timeout=10)
            except Exception:
                forced=True
                try:os.killpg(server.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:waitcode=server.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    try:os.killpg(server.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    waitcode=server.wait(timeout=5)
            survivors=clean_group(server.pid)
        else:survivors=[]
        if serverlog is not None:serverlog.close()
        endpoint_clear=not (socket/'.s.PGSQL.5432').exists() and not (socket/'.s.PGSQL.5432.lock').exists()
        pidfile_clear=not (data/'postmaster.pid').exists()
        normal=stopped and waitcode==0 and not forced and not survivors and endpoint_clear and pidfile_clear
        success=identity is not None and failure is None and normal
        # Post-cleanup actual bytes must still match the reviewed bindings.
        try:
            for p,h in mapping.items():checked(P(p),h)
        except Exception:success=False;failure='post-cleanup binding refused'
        summary={'scope':'ROOT-owned actual Linux PostgreSQL build identity only; no native controls/reference acceptance','result':'IDENTITY-CAPTURE-COMPLETE' if success else 'IDENTITY-CAPTURE-FAILED','seconds':round(time.monotonic()-started,6),'capture_budget_seconds':180,'cleanup_reserve_seconds':30,'owned_directory':str(root),'binding_sha256':sha(BINDING),'static_review_sha256':sha(REVIEW),'psql_extra_pins':EXTRA,'psql_host_extra_pins':HOST_EXTRA,'environment':env,'records':records,'failure':failure,'foreground_server_pid':server.pid if server else None,'normal_pg_ctl_stop':stopped,'foreground_wait_exit':waitcode,'forced_cleanup':forced,'survivors':survivors,'unix_endpoint_clear':endpoint_clear,'postmaster_pidfile_clear':pidfile_clear,'identity_file_sha256':sha(root/'actual-build-identity.json') if (root/'actual-build-identity.json').exists() else None,'native_limits_or_programs_changed':False}
        (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        print(str(root/'summary.json'),flush=True)
    return 0 if success else 1

if __name__=='__main__':
    raise SystemExit(main())
