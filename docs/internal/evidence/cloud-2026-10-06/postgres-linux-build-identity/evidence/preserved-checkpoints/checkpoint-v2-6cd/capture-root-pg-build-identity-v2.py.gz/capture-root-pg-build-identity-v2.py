"""ROOT-ONLY prospective identity capture. Never a native acceptance runner."""
import ctypes, hashlib, json, os, pathlib, signal, stat, subprocess, time, uuid
P = pathlib.Path
PG = P('/tmp/zasp-cloud-tools/postgres-18.3')
BINDING = P('/tmp/zasp-cloud-evidence/runtime-continuation/native379-v2-root-reviewed-pg-binding.json')
REVIEW = P('/tmp/zasp-cloud-evidence/runtime-continuation/independent-provider-fresh0b-PG-static-review.json')
EXTRA = {'bin/psql': '83513bb26d0cd69c92a95b584c4fd96ac2d808da93136693832dbbeb23510b9f', 'usr/lib/postgresql/18/bin/psql': '9b19f53d3de23ea9d7d909e551e0bbb803d796db54fc7b906c5027805c9bf1f5'}
HOST_EXTRA = {'/lib/x86_64-linux-gnu/libreadline.so.8': 'a3334d88f3f6c6a25736667e0b39db0f68b4e7e6bf758a475aff681ddb33ad8b', '/lib/x86_64-linux-gnu/libtinfo.so.6': '4013e7651ac68f547d8333517def25b2366c97eec7de7f06e105dbf3444ffebf'}
QUERY = "SELECT pg_catalog.json_build_object('version',pg_catalog.version(),'server_version_num',pg_catalog.current_setting('server_version_num'),'pgcrypto',(SELECT e.extversion FROM pg_catalog.pg_extension e WHERE e.extname='pgcrypto'),'backend_pid',pg_catalog.pg_backend_pid(),'session_user',session_user,'current_user',current_user,'tcp_address',pg_catalog.inet_server_addr(),'tcp_port',pg_catalog.inet_server_port());"

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def checked(p, pin):
    real = p.resolve(strict=True)
    if not real.is_file() or sha(real) != pin or os.access(real, os.W_OK):
        raise RuntimeError('pinned file/hash/permission refused')

def load_supervisor():
    helper=P(__file__).with_name('owned_supervisor_v2.py')
    checked(helper, '57d6558874e1788472b97546149f0dd273e9f94818af6fe40e6966c8a360703d')
    raw=helper.read_bytes()
    if hashlib.sha256(raw).hexdigest()!='57d6558874e1788472b97546149f0dd273e9f94818af6fe40e6966c8a360703d':
        raise RuntimeError('executed helper source hash refused')
    import types
    module=types.ModuleType('root_owned_supervisor_v2');module.__file__=str(helper)
    exec(compile(raw,str(helper),'exec'),module.__dict__)
    return module.OwnedSupervisor

def main():
    if os.getuid() != 1000:
        raise RuntimeError('reviewed session UID required')
    checked(BINDING, '40f499a12a8b69daa2f2e6bf527d74e01a7fdd4110b18b025b9ea6887275a500')
    checked(REVIEW, 'b179d099aad696a11ae8dd4552976cdbfd6e70f05978c4fcc2ef804683b181e6')
    binding = json.loads(BINDING.read_text())
    mapping = {str(PG/'bin'/n): h for n,h in binding['pg_binary_sha256'].items()}
    mapping.update(binding['pg_extension_files'])
    mapping.update({str(PG/n):h for n,h in EXTRA.items()})
    mapping.update(HOST_EXTRA)
    for p,h in mapping.items():
        checked(P(p),h)
    for n in [*binding['pg_binary_sha256'], 'psql']:
        expected = '#!/bin/sh\nexport LD_LIBRARY_PATH="'+str(PG/'deps')+'${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"\nexec '+str(PG/'usr/lib/postgresql/18/bin'/n)+' "$@"\n'
        if (PG/'bin'/n).read_text() != expected:
            raise RuntimeError('wrapper text refused')
    if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0) != 0:
        raise RuntimeError('Linux subreaper unavailable')
    os.umask(0o077)
    root=P('/workspace/.zasp-cloud-owned')/('pgid-'+uuid.uuid4().hex)
    root.mkdir(mode=0o700)
    socket=root/'sock'; socket.mkdir(mode=0o700)
    home=root/'home';home.mkdir(mode=0o700)
    tmp=root/'tmp';tmp.mkdir(mode=0o700)
    data=root/'data'
    env={'PATH':str(PG/'bin')+':/usr/bin:/bin','HOME':str(home),'TMPDIR':str(tmp),'LANG':'C','LC_ALL':'C','TZ':'UTC'}
    assert set(env)=={'PATH','HOME','TMPDIR','LANG','LC_ALL','TZ'}
    supervisor=load_supervisor()(root,env)
    server=None;serverlog=None;identity=None;failure=None;stopped=False;waitcode=None;cleanup_problem=None;interrupted_signals=[]
    def interrupted(signum,frame):
        supervisor.failure=True;interrupted_signals.append(signum)
        if supervisor.cleanup_deadline is None:
            raise RuntimeError('capture interrupted')
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    try:
        supervisor.run('initdb',[str(PG/'bin/initdb'),'-D',str(data),'--username=pgcapture','--auth-local=trust','--auth-host=reject','--encoding=UTF8','--no-locale'],60)
        argv=[str(PG/'bin/postgres'),'-D',str(data),'-k',str(socket),'-p','5432','-c','listen_addresses=','-c','unix_socket_permissions=0700','-c','max_connections=10','-c','shared_buffers=16MB','-c','statement_timeout=10000']
        server,serverlog=supervisor.foreground('postgres',argv)
        ready=False;until=min(time.monotonic()+20,supervisor.capture_deadline-30)
        while time.monotonic()<until:
            if server.poll() is not None:raise RuntimeError('foreground server exited before readiness')
            code,_=supervisor.run('ready-'+str(len(supervisor.records)),[str(PG/'bin/pg_isready'),'-h',str(socket),'-p','5432','-U','pgcapture','-d','postgres','-t','1'],3,allowed_codes=(0,1,2))
            if code==0:ready=True;break
            time.sleep(.1)
        if not ready:raise RuntimeError('owned socket readiness refused')
        client=[str(PG/'bin/psql'),'-X','--no-psqlrc','-h',str(socket),'-p','5432','-U','pgcapture','-d','postgres','-v','ON_ERROR_STOP=1','-A','-t']
        supervisor.run('owned-empty-extension',client+['-c','CREATE EXTENSION pgcrypto;'],10)
        _,raw=supervisor.run('readonly-build-identity',client+['-c',QUERY],10)
        identity=json.loads(raw)
        expected={'version','server_version_num','pgcrypto','backend_pid','session_user','current_user','tcp_address','tcp_port'}
        if set(identity)!=expected or identity['server_version_num']!='180003' or identity['pgcrypto']!='1.4' or not identity['version'].startswith('PostgreSQL 18.3 ') or 'linux' not in identity['version'].lower() or identity['tcp_address'] is not None or identity['tcp_port'] is not None or identity['current_user']!='pgcapture' or identity['session_user']!='pgcapture' or type(identity['backend_pid']) is not int or identity['backend_pid']<=1:
            raise RuntimeError('actual identity shape/version/socket refused')
        (root/'actual-build-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    except BaseException as exc:
        failure=type(exc).__name__;supervisor.failure=True
    finally:
        # All cleanup operations share the FIRST absolute 30-second deadline.
        supervisor.begin_cleanup()
        try:
            if server is not None:
                try:
                    supervisor.run('normal-stop',[str(PG/'bin/pg_ctl'),'-D',str(data),'-m','fast','-w','-t','15','stop'],20,cleanup=True)
                    stopped=True
                    remaining=supervisor.left()
                    if remaining<=0:raise RuntimeError('foreground join deadline')
                    waitcode=server.wait(timeout=min(10,remaining))
                except BaseException as exc:
                    supervisor.failure=True;cleanup_problem=type(exc).__name__
        finally:
            try:groups=supervisor.finalize()
            except BaseException as exc:
                supervisor.failure=True;cleanup_problem=type(exc).__name__
                groups={str(pid):['UNVERIFIED'] for pid in supervisor.processes}
            finally:
                if serverlog is not None:
                    try:serverlog.close()
                    except BaseException as exc:supervisor.failure=True;cleanup_problem=type(exc).__name__
                endpoint_clear=not (socket/'.s.PGSQL.5432').exists() and not (socket/'.s.PGSQL.5432.lock').exists()
                pidfile_clear=not (data/'postmaster.pid').exists()
                try:
                    for p,h in mapping.items():checked(P(p),h)
                except BaseException as exc:supervisor.failure=True;failure='postbinding-'+type(exc).__name__
                normal=stopped and waitcode==0 and not supervisor.failure and not any(groups.values()) and endpoint_clear and pidfile_clear
                success=identity is not None and failure is None and cleanup_problem is None and normal
                summary={'scope':'ROOT actual Linux build identity only; no native/control/reference acceptance','result':'IDENTITY-CAPTURE-COMPLETE' if success else 'IDENTITY-CAPTURE-FAILED','seconds':round(time.monotonic()-supervisor.started,6),'capture_budget_seconds':180,'absolute_cleanup_budget_seconds':30,'cleanup_deadline_monotonic':supervisor.cleanup_deadline,'owned_directory':str(root),'binding_sha256':sha(BINDING),'static_review_sha256':sha(REVIEW),'psql_extra_pins':EXTRA,'psql_host_extra_pins':HOST_EXTRA,'environment':env,'records':supervisor.records,'foreground_start_records':supervisor.foreground_records,'interrupted_signals':interrupted_signals,'failure_class':failure,'cleanup_problem_class':cleanup_problem,'foreground_server_pid':server.pid if server else None,'normal_pg_ctl_stop':stopped,'foreground_wait_exit':waitcode,'owned_groups':groups,'owned_group_cleanup':supervisor.cleanup_errors,'unix_endpoint_clear':endpoint_clear,'postmaster_pidfile_clear':pidfile_clear,'identity_file_sha256':sha(root/'actual-build-identity.json') if (root/'actual-build-identity.json').exists() else None,'native_limits_or_programs_changed':False}
                (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
                print(str(root/'summary.json'),flush=True)
    return 0 if success else 1

if __name__=='__main__':
    raise SystemExit(main())
