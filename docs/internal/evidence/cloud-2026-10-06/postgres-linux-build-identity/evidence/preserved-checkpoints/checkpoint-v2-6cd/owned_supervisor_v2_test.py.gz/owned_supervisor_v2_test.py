"""Actual owned-child tests only; never executes PostgreSQL."""
import ast, ctypes, json, os, pathlib, signal, subprocess, sys, tempfile, time, types, unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).parent
BASELINE='--baseline' in sys.argv
if BASELINE:sys.argv.remove('--baseline')
new=types.ModuleType('sup');exec(compile((ROOT/'owned_supervisor_v2.py').read_bytes(),str(ROOT/'owned_supervisor_v2.py'),'exec'),new.__dict__)
ctypes.CDLL(None).prctl(36,1,0,0,0)
class Legacy:
    def __init__(self,root,env,cleanup_seconds=30):
        self.root=pathlib.Path(root);self.env=env;self.records=[];self.processes={};self.cleanup_seconds=cleanup_seconds;self.cleanup_deadline=None
        p=ROOT/'checkpoint-aa19-rejected/capture-root-pg-build-identity.py'
        old=types.ModuleType('old');exec(compile(p.read_bytes(),str(p),'exec'),old.__dict__)
        tree=ast.parse(p.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');fn=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='run')
        ns={'root':self.root,'env':env,'deadline':time.monotonic()+180,'records':self.records,'time':time,'subprocess':subprocess,'os':os,'signal':signal,'clean_group':old.clean_group,'sha':old.sha}
        exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p),'exec'),ns);self.original=ns['run']
    def begin_cleanup(self):
        if self.cleanup_deadline is None:self.cleanup_deadline=time.monotonic()+self.cleanup_seconds
    def run(self,label,argv,cap,cleanup=False):
        saved=subprocess.Popen
        def tracked(*a,**k):
            p=saved(*a,**k);self.processes[p.pid]=p;return p
        with patch.object(subprocess,'Popen',tracked):return self.original(label,argv,cap,cleanup)
    def finalize(self):return {}
class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='zasp-owned-child-tdd-');self.root=pathlib.Path(self.temp.name)
        self.env={'PATH':'/usr/bin:/bin','HOME':str(self.root),'LANG':'C','LC_ALL':'C'}
        self.sup=(Legacy if BASELINE else new.OwnedSupervisor)(self.root,self.env)
    def tearDown(self):
        # Test owner disposes every actual fixture child even after a RED assertion.
        for pid,p in self.sup.processes.items():
            try:os.killpg(pid,signal.SIGKILL)
            except ProcessLookupError:pass
            try:p.wait(timeout=2)
            except subprocess.TimeoutExpired:pass
            until=time.monotonic()+2
            while time.monotonic()<until:
                try:
                    found,_=os.waitpid(-pid,os.WNOHANG)
                    if not found:break
                except ChildProcessError:break
        self.temp.cleanup()
    def cmd(self,body):return [sys.executable,'-c',body]
    def test_interrupted_wait_always_joins_and_records(self):
        import threading
        prior=signal.signal(signal.SIGUSR1,lambda *_: (_ for _ in ()).throw(InterruptedError('owned fault')))
        timer=threading.Timer(.1,lambda:os.kill(os.getpid(),signal.SIGUSR1));timer.start()
        try:
            with self.assertRaises(InterruptedError):self.sup.run('interrupted',self.cmd('import time;time.sleep(30)'),5)
        finally:timer.join();signal.signal(signal.SIGUSR1,prior)
        self.assertEqual(len(self.sup.records),1)
        rec=self.sup.records[0];self.assertTrue(rec['joined']);self.assertTrue(rec['interrupted']);self.assertTrue(rec['forced_cleanup']);self.assertEqual(rec['survivors'],[])
        self.assertTrue((self.root/'interrupted-record.json').is_file());self.assertFalse(any(self.sup.finalize().values()))
    def test_normal_exit_leftover_child_refuses(self):
        body='import subprocess,sys;subprocess.Popen([sys.executable,"-c","import time;time.sleep(30)"])'
        with self.assertRaises(RuntimeError):self.sup.run('leftover',self.cmd(body),5)
        rec=self.sup.records[0];self.assertTrue(rec['unexpected_descendants']);self.assertTrue(rec['forced_cleanup']);self.assertEqual(rec['survivors'],[])
    def test_cleanup_stop_error_is_recorded_and_closed(self):
        self.sup.begin_cleanup()
        with self.assertRaises(RuntimeError):self.sup.run('stop-fault',self.cmd('raise SystemExit(7)'),1,cleanup=True)
        self.assertEqual(self.sup.records[0]['exit'],7)
        self.assertFalse(any(self.sup.finalize().values()))
    def test_shared_cleanup_deadline_is_not_reset(self):
        self.sup.cleanup_seconds=.4;self.sup.begin_cleanup();original=self.sup.cleanup_deadline;start=time.monotonic()
        self.sup.run('first-cleanup',self.cmd('import time;time.sleep(.1)'),1,cleanup=True)
        with self.assertRaises(RuntimeError):self.sup.run('second-cleanup',self.cmd('import time;time.sleep(2)'),3,cleanup=True)
        self.assertEqual(self.sup.cleanup_deadline,original)
        self.assertLess(time.monotonic()-start,.9)
        self.assertFalse(any(self.sup.finalize().values()))
        self.assertTrue(self.sup.records[-1]['timed_out'])
if __name__=='__main__':unittest.main(verbosity=2)
