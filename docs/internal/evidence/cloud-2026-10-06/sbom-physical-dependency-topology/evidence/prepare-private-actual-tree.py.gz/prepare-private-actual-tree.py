from pathlib import Path
import os,stat,json,hashlib,time,subprocess,tempfile,shutil
owner=Path('/workspace/.zasp-cloud-owned/sbom-0b-graph-diagnosis-pgt18jsv');repo=Path('/workspace/zasp-sec');source=repo/'node_modules';candidate=owner/'candidate';deadline=time.monotonic()+420;sha=lambda b:hashlib.sha256(b).hexdigest()
assert not candidate.exists();assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>1137027640+350_000_000+1_500_000_000
C='0b788520159170a825a925a3f639b0b1d63169f5'
# Local read-only object sharing creates only a new private Git metadata root;
# checkout and package graph are privately owned, with no shared source writes.
subprocess.run(['git','clone','--shared','--no-checkout',str(repo),str(candidate)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=90)
subprocess.run(['git','-C',str(candidate),'checkout','--detach',C],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=90)
assert not (candidate/'node_modules').exists()
def inventory(root,stable=False):
 out={};observations={}
 for p in [root]+sorted(root.rglob('*')):
  assert time.monotonic()<deadline,'finite preparation deadline'
  s=p.lstat();relative='.' if p==root else p.relative_to(root).as_posix();entry={'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISDIR(s.st_mode):entry['type']='directory'
  elif stat.S_ISREG(s.st_mode):
   with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
   end=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode)==(end.st_dev,end.st_ino,end.st_size,end.st_mtime_ns,end.st_ctime_ns,end.st_mode),'file changed during read'
   entry.update(type='file',bytes=s.st_size,sha256=digest)
   if root==candidate/'node_modules':assert s.st_nlink==1,'no candidate hardlinks'
  elif stat.S_ISLNK(s.st_mode):
   target=os.readlink(p);resolved=p.resolve();assert not os.path.isabs(target) and resolved.is_relative_to(root) and resolved.exists(),'unsafe symlink'
   entry.update(type='symlink',target=target,resolvedRelative=resolved.relative_to(root).as_posix())
  else:raise RuntimeError('nonregular closure member')
  out[relative]=entry;observations[relative]={'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'mode':s.st_mode}
 return out,observations
start=time.monotonic();before,observedBefore=inventory(source)
originalPackages={n:sha((repo/n).read_bytes()) for n in ['package.json','package-lock.json']}
for name in originalPackages:assert (candidate/name).read_bytes()==subprocess.check_output(['git','-C',str(repo),'show',C+':'+name]) and sha((candidate/name).read_bytes())==originalPackages[name]
# No hardlinks/reflinks from shared bytes. Copy files and preserve exact modes;
# retain only validated relative symlinks resolving inside this module root.
dest=candidate/'node_modules';dest.mkdir(mode=before['.']['mode'])
for rel,meta in before.items():
 assert time.monotonic()<deadline,'finite copy deadline'
 if rel=='.':continue
 old=source/rel;new=dest/rel
 if meta['type']=='directory':new.mkdir(mode=meta['mode'])
 elif meta['type']=='symlink':new.symlink_to(meta['target'])
 else:shutil.copyfile(old,new,follow_symlinks=False);new.chmod(meta['mode'])
for rel,meta in before.items():
 if meta['type']=='directory':(dest if rel=='.' else dest/rel).chmod(meta['mode'])
new,newObserved=inventory(dest);after,observedAfter=inventory(source)
assert before==new==after,'byte/mode/topology mismatch';assert observedBefore==observedAfter,'source metadata changed during copy; unknown concurrent writes'
for name,digest in originalPackages.items():assert sha((repo/name).read_bytes())==digest and sha((candidate/name).read_bytes())==digest
assert subprocess.check_output(['git','-C',str(candidate),'status','--porcelain']).strip()==b''
manifest={'schema':'private-exact0b-node-actual-directory-closure-v1','sourceRoot':str(source),'candidateRoot':str(dest),'commit':C,'members':before,'boundary':'Complete byte/mode/relative-symlink closure before/copy/after equal and original metadata stable during preparation. Candidate actual directory has no hardlinks/shared external-resolved links. Snapshot equality does not claim original shared directory remains immutable in future.'}
p=owner/'evidence/node-modules-closure-manifest.json';p.write_text(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n');p.chmod(0o400)
receipt={'schema':'private-exact0b-node-topology-repair-receipt-v1','candidate':str(candidate),'commit':C,'sourceNodeModules':str(source),'copiedActualDirectory':str(dest),'files':sum(x['type']=='file' for x in before.values()),'directoriesIncludingRoot':sum(x['type']=='directory' for x in before.values()),'internalRelativeSymlinks':sum(x['type']=='symlink' for x in before.values()),'logicalBytes':sum(x.get('bytes',0) for x in before.values()),'closureManifestSHA256':sha(p.read_bytes()),'sourceMetadataUnchangedDuringPreparation':True,'sourceBeforeAfterAndCandidateBytesModesTopologyEqual':True,'candidateRegularFilesHardlinkCountOne':True,'packageFiles':originalPackages,'moduleLockSHA256':sha((source/'.package-lock.json').read_bytes()),'sourceTreeCleanExactCommit':True,'seconds':time.monotonic()-start,'operations':['local read-only shared-object clone','private detached checkout exact0b','full source closure inventory and temporal metadata observation','own actual node_modules directory copy preserving modes/relative internal symlinks without hardlinks','full candidate/source rehash and observation equality'],'boundary':'No install/network, no package/lock/source/securityguard change, no shared node_modules mutation, original failed worktree/logs preserved. Root active UI not interrupted. Shared Git objects are readonly clone prerequisites; candidate package file bytes are exclusive.'}
p=owner/'evidence/topology-repair-receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n');p.chmod(0o400);print(json.dumps({'candidate':str(candidate),'files':receipt['files'],'links':receipt['internalRelativeSymlinks'],'logicalBytes':receipt['logicalBytes'],'seconds':receipt['seconds'],'manifestSHA256':receipt['closureManifestSHA256'],'receiptSHA256':sha(p.read_bytes())}))
