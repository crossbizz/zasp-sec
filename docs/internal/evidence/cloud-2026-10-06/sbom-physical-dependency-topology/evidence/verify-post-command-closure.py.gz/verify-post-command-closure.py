from pathlib import Path
import os,stat,json,hashlib,subprocess,time
owner=Path('/workspace/.zasp-cloud-owned/sbom-0b-graph-diagnosis-pgt18jsv');manifestPath=owner/'evidence/node-modules-closure-manifest.json';manifest=json.loads(manifestPath.read_bytes());expected=manifest['members'];start=time.monotonic();deadline=start+180;checks=[]
for root in [Path(manifest['sourceRoot']),Path(manifest['candidateRoot'])]:
 actual={'.'}|{p.relative_to(root).as_posix() for p in root.rglob('*')};assert actual==set(expected),'closure roster changed'
 for rel,meta in expected.items():
  assert time.monotonic()<deadline,'finite closure recheck deadline';p=root if rel=='.' else root/rel;s=p.lstat();assert stat.S_IMODE(s.st_mode)==meta['mode']
  if meta['type']=='file':
   assert stat.S_ISREG(s.st_mode) and s.st_size==meta['bytes'];f=p.open('rb')
   with f:digest=hashlib.file_digest(f,'sha256').hexdigest()
   assert digest==meta['sha256'];end=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode)==(end.st_dev,end.st_ino,end.st_size,end.st_mtime_ns,end.st_ctime_ns,end.st_mode)
   if root==Path(manifest['candidateRoot']):assert s.st_nlink==1
  elif meta['type']=='directory':assert stat.S_ISDIR(s.st_mode) and not p.is_symlink()
  else:assert stat.S_ISLNK(s.st_mode) and os.readlink(p)==meta['target'] and p.resolve()==root/meta['resolvedRelative'] and p.resolve().exists()
 checks.append({'root':str(root),'regularFileHashesVerified':sum(x['type']=='file' for x in expected.values()),'directoryModesVerified':sum(x['type']=='directory' for x in expected.values()),'relativeLinkClosureVerified':sum(x['type']=='symlink' for x in expected.values()),'rosterEqual':True,'fileMetadataStableWhileRead':True})
candidate=owner/'candidate';C='0b788520159170a825a925a3f639b0b1d63169f5';assert subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD']).decode().strip()==C;assert subprocess.check_output(['git','-C',str(candidate),'status','--porcelain']).strip()==b''
receipt=json.loads((owner/'evidence/topology-repair-receipt.json').read_bytes())
for name,digest in receipt['packageFiles'].items():
 assert hashlib.sha256((candidate/name).read_bytes()).hexdigest()==digest and hashlib.sha256((Path('/workspace/zasp-sec')/name).read_bytes()).hexdigest()==digest
record={'schema':'private-exact0b-post-command-node-closure-v1','commit':C,'closureManifestSHA256':hashlib.sha256(manifestPath.read_bytes()).hexdigest(),'checks':checks,'sourceGuardsAndLocksUnchangedGitClean':True,'seconds':time.monotonic()-start,'boundary':'Postcommand snapshot equals original full physical byte/mode/internal-link roster on both original sharedroot and owned candidate; file metadata stable during each read. No future immutable sharedroot promise; candidate future fulltest consumption and writes require separate before/after evidence.'}
out=owner/'evidence/post-command-closure-record.json';out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'record':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'seconds':record['seconds'],'regularFilesPerRoot':102084,'result':'PASS'}))
