#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,re,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--root-authorized-commit',required=True);a=p.parse_args()
assert re.fullmatch('[0-9a-f]{40}',a.root_authorized_commit), 'Full actual root-authorized commit required'
b=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/workspace/zasp-sec');baseline=b/'baseline.gitleaksignore'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='8ab2ec6719e1642bba27fce4d3622242b77b994e23bc0a9ef39d794547e13d70'
actual=subprocess.check_output(['git','-C',str(repo),'rev-parse',a.root_authorized_commit+'^{commit}'],text=True).strip();assert actual==a.root_authorized_commit
out=b/('commit-'+actual);out.mkdir(mode=0o700)
cmd=['/tmp/zasp-cloud-tools/bin/gitleaks','git',str(repo),'--log-opts='+actual+'^..'+actual,'--no-banner','--redact=100','--report-format=json','--gitleaks-ignore-path='+str(baseline),'--report-path='+str(out/'scan-redacted.json')]
start=time.monotonic()
with (out/'scan.log').open('wb') as log:r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode in [0,1], 'Scanner error; no classification or candidate allowed'
findings=json.loads((out/'scan-redacted.json').read_text());assert all(x.get('Commit')==actual for x in findings), 'Unexpected commit finding'
record={'argv':cmd,'cwd':str(repo),'commit':actual,'exitCode':r.returncode,'seconds':time.monotonic()-start,'findingCount':len(findings),'baselineIgnoreSHA256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'reportSHA256':hashlib.sha256((out/'scan-redacted.json').read_bytes()).hexdigest(),'logSHA256':hashlib.sha256((out/'scan.log').read_bytes()).hexdigest(),'boundary':'Actual exact-commit scan only. Original FAIL retained. No exception, classification, shared write or scanner clearance.'}
(out/'scan-record.json').write_text(json.dumps(record,indent=2)+'\n')
for f in out.iterdir():f.chmod(0o400)
print(json.dumps({'output':str(out),'exitCode':r.returncode,'findingCount':len(findings),'reportSHA256':record['reportSHA256']}))
