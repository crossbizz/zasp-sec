from pathlib import Path
import subprocess,json,time,hashlib
b=Path(__file__).resolve().parent;commit='85321bb8fc72ec0748cff5e70e2fb24c253416fa';o=b/('commit-'+commit);candidate=o/'candidate.gitleaksignore';repo=Path('/workspace/zasp-sec')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def scan(target,opts,label):
 report=o/(label+'-redacted.json');log=o/(label+'.log');cmd=['/tmp/zasp-cloud-tools/bin/gitleaks','git',str(target),'--log-opts='+opts,'--no-banner','--redact=100','--report-format=json','--gitleaks-ignore-path='+str(candidate),'--report-path='+str(report)];start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,cwd=target,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode in [0,1];findings=json.loads(report.read_text());record={'argv':cmd,'cwd':str(target),'exitCode':r.returncode,'seconds':time.monotonic()-start,'findingCount':len(findings),'candidateSHA256':sha(candidate),'reportSHA256':sha(report),'logSHA256':sha(log)};(o/(label+'-record.json')).write_text(json.dumps(record,indent=2)+'\n');return r.returncode,findings
exitcode,actual=scan(repo,commit+'^..'+commit,'candidate-actual-commit');assert exitcode==0 and not actual
canary=o/'canary-repository';canary.mkdir(mode=0o700);subprocess.run(['git','init','--quiet',str(canary)],check=True)
original=json.loads((o/'scan-redacted.json').read_text());paths=sorted(set(x['File'] for x in original));fixtures=[]
for index,path in enumerate(paths):
 raw=subprocess.check_output(['git','-C',str(repo),'show',commit+':'+path])
 for mode,dest in [('same-path-new-commit',path),('new-path','canary-new-path/'+str(index)+'/'+Path(path).name)]:
  p=canary/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);fixtures.append({'mode':mode,'path':dest,'sourceCommit':commit,'sourcePath':path,'sourceSHA256':hashlib.sha256(raw).hexdigest()})
subprocess.run(['git','-C',str(canary),'add','--all'],check=True);subprocess.run(['git','-C',str(canary),'-c','user.name=Private scanner canary','-c','user.email=scanner-canary@example.invalid','commit','--quiet','--no-gpg-sign','-m','Exact immutable-coordinate detection canaries'],check=True)
newcommit=subprocess.check_output(['git','-C',str(canary),'rev-parse','HEAD'],text=True).strip();assert newcommit!=commit
exitcode,canaryfind=scan(canary,'--all','candidate-detection-canaries');assert exitcode==1 and len(canaryfind)==10
same=[x for x in canaryfind if x['File'] in paths];new=[x for x in canaryfind if x['File'].startswith('canary-new-path/')];assert len(same)==len(new)==5 and all(x['Commit']==newcommit for x in canaryfind)
proof={'schema':'immutable-fingerprint-canary-proof-v1','actualCommit':commit,'actualCandidateOutcome':'PASS0','originalScanOutcome':'FAIL5','canaryCommit':newcommit,'samePathDifferentCommitFindings':len(same),'differentPathFindings':len(new),'candidateCanaryOutcome':'FAIL10','fixtures':fixtures,'candidateSHA256':sha(candidate),'boundary':'Public verified hash fixtures only. Candidate suppresses actual historical four fingerprints, while same path in new commit and new paths remain detected. No shared write or global Git/scanner configuration.'};(o/'candidate-canary-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for p in o.iterdir():
 if p.is_file():p.chmod(0o400)
print(json.dumps({'actualCandidate':'PASS0','canaries':'FAIL10','samePathNewCommit':5,'newPath':5,'proofSHA256':sha(o/'candidate-canary-proof.json')}))
