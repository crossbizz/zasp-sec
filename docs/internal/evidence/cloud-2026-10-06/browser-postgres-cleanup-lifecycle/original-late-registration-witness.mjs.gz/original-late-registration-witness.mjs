import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import test from 'node:test';
const target='/workspace/zasp-sec/scripts/production-combined-e2e.mjs';
const source=fs.readFileSync(target,'utf8');
const cleanup=source.slice(source.indexOf('async function cleanupOwnedResources() {'),source.indexOf('\nasync function generateHarnessGitHubAppPrivateKey('));
const startup=source.slice(source.indexOf('async function startPostgres(port) {'),source.indexOf('\nasync function stopPostgres(value) {'));
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
test('owned cleanup refuses a PostgreSQL owner registered after its cleanup slot',async()=>{
 let releasePreparation, preparationStarted;
 const ready=new Promise(r=>{preparationStarted=r;});const events=[];
 const context={precisionBrowserCheckpoint:null,mountedRuntimeProofs:[],runtimePipelineChild:null,runtimeGraphDependency:null,redTeamRuntimeProof:{close:async()=>{}},runtimePipelineDependencies:{close:async()=>{}},exportBrowserProfiles:[],secondBrowserTab:null,browser:null,task4Workers:[],exportBrowserAPILifetimes:[],api:null,proxy:null,identity:null,policyHistory:null,web:null,auditExportProvider:null,postgres:undefined,children:[{kind:'preparation'}],exportBrowserEvidenceDirectory:null,automaticDiscoveryEvidenceDirectory:null,temporaryRoot:'/virtual-owned-root',attackLabMountedMode:true,securityAgentExportMode:false,automaticDiscoveryMode:false,platform:'/virtual-platform',process:{env:{}},console:{log:()=>{}},path:{join:(...s)=>s.join('/')},assert,auditBrowserEnvironment:x=>x,chmod:async()=>{},rm:async()=>{events.push('files-cleaned');},command:async(executable)=>{if(executable==='docker')return {stdout:'amd64'};preparationStarted();return new Promise(r=>{releasePreparation=()=>r({status:0});});},createOwnedBrowserPostgres:()=>{events.push('owner-registered');return {start:async()=>{events.push('container-started');},stop:async()=>{events.push('container-stopped');}};},stopPostgres:async p=>p.stop(),stopChild:async()=>{releasePreparation();await new Promise(r=>setImmediate(r));}};
 const functions=Function('context','with(context){'+cleanup+'\n'+startup+';return {cleanupOwnedResources,startPostgres};}')(context);
 const boot=functions.startPostgres(54321);await ready;await functions.cleanupOwnedResources();await boot;
 fs.writeFileSync('/tmp/zasp-cloud-evidence/browser-late-registration-source-witness.json',JSON.stringify({sourceSHA256:sha(source),cleanupSHA256:sha(cleanup),startupSHA256:sha(startup),events,scope:'Exact source-extracted cleanup/startup with controlled command completion; no Docker/Go/browser/resources. Demonstrates source gap, not original Browser3 cause.'},null,2)+'\n');
 assert.ok(events.includes('container-stopped'),'cleanup returned while its late-registered owned PostgreSQL remained un-stopped');
});
