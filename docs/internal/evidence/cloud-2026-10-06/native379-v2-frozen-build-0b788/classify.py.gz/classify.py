import pathlib,json,hashlib,collections,re
base=pathlib.Path('/workspace/.zasp-cloud-owned/frozen0b-opaque-publication-wrapper-ya7vfc6n'); src=pathlib.Path('/workspace/zasp-sec/docs/internal/evidence/cloud-2026-10-06/native379-v2-frozen-build-0b788'); h=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((src/'required-scan-supplement/original-metadata-report.json').read_text()); cls=json.loads((src/'required-scan-supplement/public-digest-classification.json').read_text()); add=json.loads((src/'required-scan-supplement/truncated-literal-classification-addendum.json').read_text()); new=json.loads((base/'private-current-folder-literal-resolution.json').read_text()); root=json.loads(pathlib.Path('/tmp/zasp-cloud-evidence/new-proof-working-scan-20261006/native379-v2-frozen-build-0b788.json').read_text())
# Require ordinary tool redaction to reproduce ROOT's exact findings, including coordinates.
def norm(x,redact=False):
 x=dict(x)
 if redact:x['Match']=x['Match'].replace(x['Secret'],'REDACTED');x['Secret']='REDACTED'
 return json.dumps(x,sort_keys=True)
assert collections.Counter(norm(x,True) for x in new)==collections.Counter(norm(x) for x in root)
bylit={}; full={}; cached={}
def actual(path):
 if path not in cached:
  p=pathlib.Path(path);assert p.is_file();cached[path]=h(p.read_bytes())
 return cached[path]
addby={x['flaggedLiteralSHA256']:x for x in add['findings']}
oldby=collections.defaultdict(list)
for x in old:oldby[h(x['Secret'].encode())].append(x)
for x in cls['findings']:
 sha=x['flaggedLiteralSHA256']; records=oldby[sha]; assert records
 y=addby.get(sha,x); witnesses=y.get('witnesses',[]);assert witnesses
 for w in witnesses:
  path=w.get('path',w.get('actualFile'));digest=actual(path)
  if 'fullPublicSHA256' in w:assert digest==w['fullPublicSHA256']
  for r in records:
   token=r['Secret'];assert token in digest
   if 'literalOffset' in w: assert digest[w['literalOffset']:w['literalOffset']+w['literalLength']]==token
   bylit.setdefault(token,[]).append({'actualFile':path,'fullPublicSHA256':digest,'kind':w.get('kind','actual-file-SHA256-substring')})
  full.setdefault(digest,[]).append({'actualFile':path,'fullPublicSHA256':digest,'kind':w.get('kind','actual-file-SHA256-substring')})
findings=[];unknown=[]
for x in new:
 p=pathlib.Path(x['File']);rel=p.relative_to(src).as_posix();lines=p.read_text().splitlines();segment='\n'.join(lines[x['StartLine']-1:x['EndLine']]);token=x['Secret'];assert token in x['Match'];assert x['Match'] in segment
 ws=bylit.get(token,[])
 if not ws:
  # Link a truncated scanner match to a fully rehashed digest actually present on the same source line.
  for digest,v in full.items():
   if token in digest and digest in segment:ws+=v
 assert ws, (rel,x['StartLine'],len(token))
 uniq={json.dumps(w,sort_keys=True):w for w in ws}
 findings.append({'file':rel,'line':x['StartLine'],'endLine':x['EndLine'],'rule':x['RuleID'],'flaggedLiteralSHA256':h(token.encode()),'flaggedLiteralLength':len(token),'classification':'verified-public-actual-file-SHA256-or-exact-substring','witnesses':list(uniq.values()),'matchBoundToActualSourceBytes':True})
proof={'version':1,'status':'PUBLIC-DIGEST-IDENTITY-ONLY','originalCurrentFolderScan':'FAIL','findingCount':len(new),'originalExpandedScan':'FAIL','originalExpandedFindingCount':len(old),'unresolved':0,'originalRootRedactedReportSHA256':h(pathlib.Path('/tmp/zasp-cloud-evidence/new-proof-working-scan-20261006/native379-v2-frozen-build-0b788.json').read_bytes()),'privateLiteralResolutionReportSHA256':h((base/'private-current-folder-literal-resolution.json').read_bytes()),'standardRedactionExactFindingMultiset':True,'actualRegularFileIdentitiesRehashed':len(cached),'classificationInputSHA256':h((src/'required-scan-supplement/public-digest-classification.json').read_bytes()),'addendumInputSHA256':h((src/'required-scan-supplement/truncated-literal-classification-addendum.json').read_bytes()),'boundaries':['No ignore/config changes.','Both original failed scans remain failed.','Compression is encoding and does not establish scanner clearance.','No native acceptance or production-readiness promotion.'],'findings':findings}
(base/'public-digest-identity-proof.json').write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps({'findings':len(new),'oldFindings':len(old),'actualFiles':len(cached),'proofSHA256':h((base/'public-digest-identity-proof.json').read_bytes()),'unknown':0}))
