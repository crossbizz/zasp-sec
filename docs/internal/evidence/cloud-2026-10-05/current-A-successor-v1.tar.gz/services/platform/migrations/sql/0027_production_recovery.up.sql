DO $release_guard$
BEGIN
 IF NOT public.zasp_attack_lab_execution_readiness(
   (SELECT checksum FROM public.zasp_schema_versions WHERE version=26 AND name='attack_lab_execution'),
   (SELECT value FROM public.zasp_schema_metadata WHERE key='attack_lab_execution_fingerprint'))
   OR EXISTS(SELECT 1 FROM public.zasp_schema_versions WHERE version>26) THEN
  RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='production recovery prerequisite rejected';
 END IF;
END
$release_guard$;

DO $roles$
DECLARE role_name text;role_row record;
BEGIN
 FOREACH role_name IN ARRAY ARRAY['zasp_recovery_worker','zasp_recovery_outbox_worker'] LOOP
  IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname=role_name) THEN EXECUTE format('CREATE ROLE %I NOLOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS',role_name);END IF;
  SELECT * INTO STRICT role_row FROM pg_roles WHERE rolname=role_name;
  IF role_row.rolcanlogin OR role_row.rolinherit OR role_row.rolsuper OR role_row.rolcreatedb OR role_row.rolcreaterole OR role_row.rolreplication OR role_row.rolbypassrls
    OR EXISTS(SELECT 1 FROM pg_auth_members membership WHERE membership.member=role_row.oid OR membership.roleid=role_row.oid) THEN
   RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='production recovery role rejected';
  END IF;
 END LOOP;
 GRANT zasp_recovery_worker,zasp_recovery_outbox_worker TO zasp_discovery_authority WITH ADMIN OPTION;
END
$roles$;

CREATE FUNCTION public.zasp_policy_id_array_valid(value jsonb) RETURNS boolean LANGUAGE sql IMMUTABLE SET search_path TO pg_catalog, public AS $policy_ids$
 SELECT jsonb_typeof(value)='array' AND jsonb_array_length(value)<=512 AND NOT EXISTS(
  SELECT 1 FROM (
   SELECT policy_id,ordinality,lag(policy_id) OVER(ORDER BY ordinality) prior_id
   FROM jsonb_array_elements_text(value) WITH ORDINALITY AS item(policy_id,ordinality)
  ) ordered
  WHERE policy_id!~'^[a-z][a-z0-9._:-]{0,127}$' OR ordinality>1 AND prior_id>=policy_id
 )
$policy_ids$;

ALTER TABLE public.zasp_runtime_gateway_events ADD COLUMN policy_ids jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.zasp_runtime_gateway_events ADD CONSTRAINT zasp_runtime_gateway_events_policy_ids_v27_ck CHECK(public.zasp_policy_id_array_valid(policy_ids));
CREATE INDEX zasp_runtime_gateway_events_policy_ids_v27_idx ON public.zasp_runtime_gateway_events USING gin (policy_ids);
CREATE INDEX zasp_runtime_gateway_events_policy_history_v27_idx ON public.zasp_runtime_gateway_events(organization_id,workspace_id,environment_id,occurred_at DESC,event_id ASC);

CREATE FUNCTION public.zasp_runtime_gateway_record_event_v27(credential_value text,event_value text,expected_floor_value bigint,next_floor_value bigint,request_digest_value bytea,policy_version_value bigint,decision_value text,action_kind_value text,classification_value jsonb,policy_ids_value jsonb,occurred_value timestamptz) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $record$
DECLARE authority_value jsonb;organization_value text;workspace_value text;environment_value text;device_value text;existing_value zasp_runtime_gateway_events%ROWTYPE;canonical_digest bytea;result_value jsonb;
BEGIN
 IF NOT zasp_valid_product_id(event_value) OR expected_floor_value<0 OR next_floor_value<=expected_floor_value OR octet_length(request_digest_value)<>32 OR policy_version_value<1 OR decision_value NOT IN('allow','monitor','block') OR action_kind_value NOT IN('http','mcp') OR jsonb_typeof(classification_value)<>'object' OR NOT zasp_policy_id_array_valid(policy_ids_value)
  OR NOT classification_value ?& ARRAY['category','route_class','resource_class','outcome'] OR classification_value-ARRAY['category','route_class','resource_class','outcome','session_id','agent_id','target_id','capability_category','capability_outcome']<>'{}'::jsonb
  OR octet_length(convert_to(classification_value::text,'UTF8'))>16384 OR EXISTS(SELECT 1 FROM jsonb_each_text(classification_value) item WHERE length(item.value) NOT BETWEEN 1 AND 128 OR item.value<>btrim(item.value) OR item.value!~'^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$')
  OR classification_value ? 'session_id' AND NOT zasp_valid_product_id(classification_value->>'session_id')
  OR classification_value ?| ARRAY['agent_id','target_id','capability_category','capability_outcome'] AND (decision_value<>'block' OR NOT classification_value ?& ARRAY['agent_id','target_id','capability_category','capability_outcome'] OR NOT zasp_valid_product_id(classification_value->>'agent_id') OR NOT zasp_valid_product_id(classification_value->>'target_id') OR (classification_value->>'capability_category',classification_value->>'capability_outcome') NOT IN(('data_read','read'),('data_write','write'),('action_execute','execute'),('identity_assume','assume'),('network_egress','connect'),('administration','administer')))
  OR occurred_value IS NULL OR occurred_value>transaction_timestamp()+interval '30 seconds' THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='gateway event rejected';END IF;
 authority_value:=zasp_runtime_gateway_credential_authority(credential_value,'runtime-gateway');organization_value:=authority_value->>'organization_id';workspace_value:=authority_value->>'workspace_id';environment_value:=authority_value->>'environment_id';device_value:=authority_value->>'device_id';
 canonical_digest:=digest(convert_to(jsonb_build_object('credential_id',credential_value,'device_id',device_value,'event_id',event_value,'expected_floor',expected_floor_value,'next_floor',next_floor_value,'policy_version',policy_version_value,'decision',decision_value,'action_kind',action_kind_value,'classification',classification_value,'policy_ids',policy_ids_value,'occurred_at',to_char(occurred_value AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'))::text,'UTF8'),'sha256');
 IF canonical_digest<>request_digest_value THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='gateway event rejected';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(concat_ws(chr(31),organization_value,workspace_value,environment_value,device_value),0));
 SELECT * INTO existing_value FROM zasp_runtime_gateway_events event_row WHERE (event_row.organization_id,event_row.workspace_id,event_row.environment_id,event_row.event_id)=(organization_value,workspace_value,environment_value,event_value);
 IF FOUND THEN
  IF (existing_value.device_id,existing_value.credential_id,existing_value.sequence,existing_value.request_digest,existing_value.policy_version,existing_value.decision,existing_value.action_kind,existing_value.classification,existing_value.policy_ids,existing_value.occurred_at) IS DISTINCT FROM (device_value,credential_value,next_floor_value,request_digest_value,policy_version_value,decision_value,action_kind_value,classification_value,policy_ids_value,occurred_value) THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='gateway event rejected';END IF;
  UPDATE zasp_runtime_gateway_reconciliation_state SET used_at=COALESCE(used_at,transaction_timestamp()) WHERE singleton;RETURN jsonb_build_object('event_id',event_value,'device_id',device_value,'sequence',next_floor_value,'recorded_at',existing_value.recorded_at,'replayed',true);
 END IF;
 IF occurred_value<transaction_timestamp()-interval '24 hours' THEN UPDATE zasp_runtime_gateway_reconciliation_state SET used_at=COALESCE(used_at,transaction_timestamp()) WHERE singleton;RETURN jsonb_build_object('event_id',event_value,'outcome','record_window_expired');END IF;
 IF classification_value ? 'agent_id' THEN PERFORM zasp_inventory_record_capability_evidence(organization_value,workspace_value,environment_value,classification_value->>'agent_id',classification_value->>'target_id',classification_value->>'capability_category',classification_value->>'capability_outcome','runtime_policy',event_value,occurred_value);END IF;
 PERFORM zasp_runtime_gateway_advance_replay(credential_value,expected_floor_value,next_floor_value,request_digest_value);
 INSERT INTO zasp_runtime_gateway_events(organization_id,workspace_id,environment_id,device_id,credential_id,event_id,sequence,request_digest,policy_version,decision,action_kind,classification,policy_ids,occurred_at) VALUES(organization_value,workspace_value,environment_value,device_value,credential_value,event_value,next_floor_value,request_digest_value,policy_version_value,decision_value,action_kind_value,classification_value,policy_ids_value,occurred_value) RETURNING jsonb_build_object('event_id',event_id,'device_id',device_id,'sequence',sequence,'recorded_at',recorded_at,'replayed',false) INTO result_value;
 UPDATE zasp_runtime_gateway_reconciliation_state SET used_at=COALESCE(used_at,transaction_timestamp()) WHERE singleton;RETURN result_value;
END
$record$;

CREATE FUNCTION public.zasp_policy_list_runtime_decisions(organization_value text,workspace_value text,environment_value text,policy_value text,limit_value integer) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $decisions$
DECLARE result_value jsonb;
BEGIN
 IF NOT zasp_discovery_principal_ready('zasp_discovery_api') OR NOT zasp_valid_product_id(organization_value) OR NOT zasp_valid_product_id(workspace_value) OR NOT zasp_valid_product_id(environment_value) OR policy_value!~'^policy-[a-z0-9][a-z0-9-]{0,120}$' OR limit_value NOT BETWEEN 1 AND 100 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='policy decision history rejected';END IF;
 SELECT jsonb_build_object('items',COALESCE(jsonb_agg(jsonb_build_object('id',event.event_id,'policy_id',policy_value,'environment_id',event.environment_id,'result',event.decision,'correlation_id',event.event_id,'at',to_char(event.occurred_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) ORDER BY event.occurred_at DESC,event.event_id ASC),'[]'::jsonb)) INTO result_value
 FROM (SELECT event.* FROM zasp_runtime_gateway_events event WHERE (event.organization_id,event.workspace_id,event.environment_id)=(organization_value,workspace_value,environment_value) AND event.policy_ids ? policy_value ORDER BY event.occurred_at DESC,event.event_id ASC LIMIT limit_value) event;
 RETURN result_value;
END
$decisions$;

ALTER FUNCTION public.zasp_policy_id_array_valid(jsonb) OWNER TO zasp_discovery_authority;
ALTER FUNCTION public.zasp_runtime_gateway_record_event_v27(text,text,bigint,bigint,bytea,bigint,text,text,jsonb,jsonb,timestamptz) OWNER TO zasp_discovery_authority;
ALTER FUNCTION public.zasp_policy_list_runtime_decisions(text,text,text,text,integer) OWNER TO zasp_discovery_authority;
REVOKE ALL ON FUNCTION public.zasp_policy_id_array_valid(jsonb),public.zasp_runtime_gateway_record_event_v27(text,text,bigint,bigint,bytea,bigint,text,text,jsonb,jsonb,timestamptz),public.zasp_policy_list_runtime_decisions(text,text,text,text,integer) FROM PUBLIC,zasp_discovery_api,zasp_gateway_control;
GRANT EXECUTE ON FUNCTION public.zasp_runtime_gateway_record_event_v27(text,text,bigint,bigint,bytea,bigint,text,text,jsonb,jsonb,timestamptz) TO zasp_gateway_control;
GRANT EXECUTE ON FUNCTION public.zasp_policy_list_runtime_decisions(text,text,text,text,integer) TO zasp_discovery_api;

CREATE TABLE public.zasp_recovery_principal_bindings(
 principal_name text PRIMARY KEY CHECK(principal_name~'^[a-z][a-z0-9_]{2,62}$'),
 authority_role text NOT NULL UNIQUE CHECK(authority_role IN('zasp_recovery_worker','zasp_recovery_outbox_worker')),
 registered_at timestamptz NOT NULL DEFAULT transaction_timestamp()
);

CREATE TABLE public.zasp_recovery_backups(
 organization_id text NOT NULL,workspace_id text NOT NULL,environment_id text NOT NULL,backup_id text NOT NULL,
 version bigint NOT NULL DEFAULT 1 CHECK(version BETWEEN 1 AND 1000000),state text NOT NULL DEFAULT 'queued' CHECK(state IN('queued','draining','capturing','publishing','succeeded','retryable','failed')),
 retention_days integer NOT NULL CHECK(retention_days BETWEEN 7 AND 90),actor_id text NOT NULL,idempotency_key text NOT NULL,request_digest bytea NOT NULL,
 hold_epoch bigint,attempt integer NOT NULL DEFAULT 0 CHECK(attempt BETWEEN 0 AND 100),worker_id text,lease_token bytea,lease_expires_at timestamptz,available_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 manifest jsonb,manifest_digest bytea,error_code text,created_at timestamptz NOT NULL DEFAULT transaction_timestamp(),started_at timestamptz,completed_at timestamptz,updated_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(organization_id,workspace_id,environment_id,backup_id),UNIQUE(organization_id,workspace_id,environment_id,actor_id,idempotency_key),
 FOREIGN KEY(organization_id,workspace_id,environment_id) REFERENCES public.zasp_environments(organization_id,workspace_id,id),
 CHECK(zasp_valid_product_id(backup_id) AND zasp_valid_product_id(actor_id)),CHECK(length(idempotency_key) BETWEEN 16 AND 128),CHECK(octet_length(request_digest)=32),
 CHECK(hold_epoch IS NULL OR hold_epoch BETWEEN 1 AND 9223372036854775807),CHECK(worker_id IS NULL OR worker_id~'^[a-z][a-z0-9.-]{2,127}$'),CHECK(lease_token IS NULL OR octet_length(lease_token)=32),
 CHECK((state IN('draining','capturing','publishing'))=(worker_id IS NOT NULL AND lease_token IS NOT NULL AND lease_expires_at IS NOT NULL)),
 CHECK(manifest IS NULL OR jsonb_typeof(manifest)='object'),CHECK(manifest_digest IS NULL OR octet_length(manifest_digest)=32),CHECK(error_code IS NULL OR error_code~'^[a-z][a-z0-9_]{0,63}$'),
 CHECK((state='succeeded')=(manifest IS NOT NULL AND manifest_digest IS NOT NULL AND completed_at IS NOT NULL)),CHECK(state NOT IN('failed') OR completed_at IS NOT NULL)
);

CREATE TABLE public.zasp_recovery_restores(
 organization_id text NOT NULL,workspace_id text NOT NULL,environment_id text NOT NULL,restore_id text NOT NULL,
 version bigint NOT NULL DEFAULT 1 CHECK(version BETWEEN 1 AND 1000000),state text NOT NULL DEFAULT 'queued' CHECK(state IN('queued','verifying','provisioning','validating','rebuilding','cleanup_required','cleaning','succeeded','retryable','failed','failed_cleanup')),
 actor_id text NOT NULL,idempotency_key text NOT NULL,request_digest bytea NOT NULL,target_environment text NOT NULL CHECK(target_environment~'^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$' AND target_environment<>'production'),manifest jsonb NOT NULL,manifest_digest bytea NOT NULL,
 attempt integer NOT NULL DEFAULT 0 CHECK(attempt BETWEEN 0 AND 100),worker_id text,lease_token bytea,lease_expires_at timestamptz,available_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 observed_counts jsonb,validation_evidence jsonb,cleanup_evidence jsonb,error_code text,created_at timestamptz NOT NULL DEFAULT transaction_timestamp(),started_at timestamptz,completed_at timestamptz,updated_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(organization_id,workspace_id,environment_id,restore_id),UNIQUE(organization_id,workspace_id,environment_id,actor_id,idempotency_key),
 FOREIGN KEY(organization_id,workspace_id,environment_id) REFERENCES public.zasp_environments(organization_id,workspace_id,id),
 CHECK(zasp_valid_product_id(restore_id) AND zasp_valid_product_id(actor_id)),CHECK(length(idempotency_key) BETWEEN 16 AND 128),CHECK(octet_length(request_digest)=32),CHECK(octet_length(manifest_digest)=32),CHECK(jsonb_typeof(manifest)='object'),
 CHECK(worker_id IS NULL OR worker_id~'^[a-z][a-z0-9.-]{2,127}$'),CHECK(lease_token IS NULL OR octet_length(lease_token)=32),
 CHECK((state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning'))=(worker_id IS NOT NULL AND lease_token IS NOT NULL AND lease_expires_at IS NOT NULL)),
 CHECK(observed_counts IS NULL OR jsonb_typeof(observed_counts)='object'),CHECK(validation_evidence IS NULL OR jsonb_typeof(validation_evidence)='object'),CHECK(cleanup_evidence IS NULL OR jsonb_typeof(cleanup_evidence)='object'),
 CHECK(error_code IS NULL OR error_code~'^[a-z][a-z0-9_]{0,63}$'),CHECK((state IN('succeeded','failed','failed_cleanup'))=(completed_at IS NOT NULL))
);

CREATE TABLE public.zasp_recovery_holds(
 organization_id text NOT NULL,workspace_id text NOT NULL,environment_id text NOT NULL,epoch bigint NOT NULL CHECK(epoch BETWEEN 1 AND 9223372036854775807),operation_id text NOT NULL,
 state text NOT NULL CHECK(state IN('requested','draining','held','released')),requested_at timestamptz NOT NULL DEFAULT transaction_timestamp(),held_at timestamptz,released_at timestamptz,
 PRIMARY KEY(organization_id,workspace_id,environment_id),FOREIGN KEY(organization_id,workspace_id,environment_id) REFERENCES public.zasp_environments(organization_id,workspace_id,id),
 CHECK(zasp_valid_product_id(operation_id)),CHECK((state='held')=(held_at IS NOT NULL AND released_at IS NULL) OR state<>'held'),CHECK(state<>'released' OR released_at IS NOT NULL)
);

CREATE TABLE public.zasp_recovery_outbox(
 organization_id text NOT NULL,workspace_id text NOT NULL,environment_id text NOT NULL,outbox_id text NOT NULL,
 topic text NOT NULL CHECK(topic IN('recovery-backup-jobs','recovery-restore-jobs')),deterministic_key text NOT NULL,payload jsonb NOT NULL,payload_digest bytea NOT NULL,
 state text NOT NULL DEFAULT 'pending' CHECK(state IN('pending','leased','published','retryable','exhausted')),attempt integer NOT NULL DEFAULT 0 CHECK(attempt BETWEEN 0 AND 100),available_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 worker_id text,lease_token bytea,lease_expires_at timestamptz,provider_ack text,published_at timestamptz,error_code text,created_at timestamptz NOT NULL DEFAULT transaction_timestamp(),updated_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(organization_id,workspace_id,environment_id,outbox_id),UNIQUE(topic,deterministic_key),FOREIGN KEY(organization_id,workspace_id,environment_id) REFERENCES public.zasp_environments(organization_id,workspace_id,id),
 CHECK(zasp_valid_product_id(outbox_id)),CHECK(length(deterministic_key) BETWEEN 16 AND 256),CHECK(jsonb_typeof(payload)='object'),CHECK(octet_length(payload_digest)=32),
 CHECK(worker_id IS NULL OR worker_id~'^[a-z][a-z0-9.-]{2,127}$'),CHECK(lease_token IS NULL OR octet_length(lease_token)=32),CHECK((state='leased')=(worker_id IS NOT NULL AND lease_token IS NOT NULL AND lease_expires_at IS NOT NULL)),
 CHECK(provider_ack IS NULL OR provider_ack~'^sha256:[a-f0-9]{64}$'),CHECK(error_code IS NULL OR error_code IN('queue_publish_unknown','lease_lost'))
);

CREATE TABLE public.zasp_recovery_fairness(
 topic text PRIMARY KEY CHECK(topic IN('recovery-backup-jobs','recovery-restore-jobs','recovery-operations')),
 last_organization_id text CHECK(last_organization_id IS NULL OR zasp_valid_product_id(last_organization_id)),updated_at timestamptz NOT NULL DEFAULT transaction_timestamp()
);
INSERT INTO public.zasp_recovery_fairness(topic) VALUES('recovery-backup-jobs'),('recovery-restore-jobs'),('recovery-operations');

CREATE TABLE public.zasp_recovery_request_receipts(
 organization_id text NOT NULL,workspace_id text NOT NULL,environment_id text NOT NULL,actor_id text NOT NULL,operation text NOT NULL,idempotency_key text NOT NULL,
 resource_id text NOT NULL,request_digest bytea NOT NULL,result jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT transaction_timestamp(),expires_at timestamptz NOT NULL DEFAULT transaction_timestamp()+interval '24 hours',
 PRIMARY KEY(organization_id,workspace_id,environment_id,actor_id,operation,idempotency_key),
 CHECK(zasp_valid_product_id(actor_id) AND zasp_valid_product_id(resource_id)),CHECK(operation IN('startRecoveryBackup','startRecoveryRestore')),CHECK(length(idempotency_key) BETWEEN 16 AND 128),CHECK(octet_length(request_digest)=32),CHECK(jsonb_typeof(result)='object')
);

CREATE TABLE public.zasp_recovery_audit(
 organization_id text NOT NULL,workspace_id text NOT NULL,environment_id text NOT NULL,audit_id text NOT NULL,correlation_id text NOT NULL,receipt_id text NOT NULL,actor_id text NOT NULL,
 event_kind text NOT NULL CHECK(event_kind IN('recovery_backup_requested','recovery_restore_requested')),resource_id text NOT NULL,event_digest bytea NOT NULL,body jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(organization_id,audit_id),UNIQUE(organization_id,receipt_id),CHECK(zasp_valid_product_id(audit_id) AND zasp_valid_product_id(correlation_id) AND zasp_valid_product_id(receipt_id) AND zasp_valid_product_id(actor_id) AND zasp_valid_product_id(resource_id)),
 CHECK(octet_length(event_digest)=32),CHECK(jsonb_typeof(body)='object')
);

CREATE INDEX zasp_recovery_backups_claim_idx ON public.zasp_recovery_backups(available_at,created_at) WHERE state IN('queued','retryable','draining','capturing','publishing');
CREATE INDEX zasp_recovery_restores_claim_idx ON public.zasp_recovery_restores(available_at,created_at) WHERE state IN('queued','retryable','verifying','provisioning','validating','rebuilding','cleanup_required','cleaning');
CREATE INDEX zasp_recovery_outbox_claim_idx ON public.zasp_recovery_outbox(topic,available_at,created_at) WHERE state IN('pending','retryable','leased');
CREATE INDEX zasp_recovery_receipts_expiry_idx ON public.zasp_recovery_request_receipts(expires_at);

DO $tables$
DECLARE table_name text;
BEGIN
 FOREACH table_name IN ARRAY ARRAY['zasp_recovery_principal_bindings','zasp_recovery_backups','zasp_recovery_restores','zasp_recovery_holds','zasp_recovery_outbox','zasp_recovery_fairness','zasp_recovery_request_receipts','zasp_recovery_audit'] LOOP
  EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',table_name);EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY',table_name);EXECUTE format('ALTER TABLE public.%I OWNER TO zasp_discovery_authority',table_name);
  EXECUTE format('CREATE POLICY %I ON public.%I TO zasp_discovery_authority USING(true) WITH CHECK(true)',table_name||'_authority',table_name);
  EXECUTE format('REVOKE ALL ON public.%I FROM PUBLIC,zasp_discovery_api,zasp_recovery_worker,zasp_recovery_outbox_worker',table_name);EXECUTE format('GRANT SELECT,INSERT,UPDATE,DELETE ON public.%I TO zasp_discovery_authority',table_name);
 END LOOP;
END
$tables$;

CREATE FUNCTION public.zasp_recovery_register_principals(migration_principal text,worker_principal text,outbox_principal text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $register$
DECLARE principals text[]:=ARRAY[worker_principal,outbox_principal];authorities text[]:=ARRAY['zasp_recovery_worker','zasp_recovery_outbox_worker'];index_value integer;role_value record;
BEGIN
 IF migration_principal<>session_user OR cardinality(ARRAY(SELECT DISTINCT unnest(ARRAY[migration_principal,worker_principal,outbox_principal])))<>3 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery principals rejected';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended('zasp-recovery-principal-registration',0));
 FOR index_value IN 1..2 LOOP
  SELECT role_row.oid,role_row.rolcanlogin,role_row.rolsuper,role_row.rolcreatedb,role_row.rolcreaterole,role_row.rolreplication,role_row.rolinherit,role_row.rolbypassrls INTO STRICT role_value FROM pg_roles role_row WHERE role_row.rolname=principals[index_value];
  IF NOT role_value.rolcanlogin OR NOT role_value.rolinherit OR role_value.rolsuper OR role_value.rolcreatedb OR role_value.rolcreaterole OR role_value.rolreplication OR role_value.rolbypassrls OR EXISTS(SELECT 1 FROM pg_auth_members membership JOIN pg_roles granted ON granted.oid=membership.roleid WHERE membership.member=role_value.oid AND granted.rolname LIKE 'zasp_%' AND granted.rolname<>authorities[index_value]) THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='recovery principal rejected';END IF;
  EXECUTE format('GRANT %I TO %I',authorities[index_value],principals[index_value]);
  INSERT INTO zasp_recovery_principal_bindings(principal_name,authority_role) VALUES(principals[index_value],authorities[index_value]) ON CONFLICT(principal_name) DO UPDATE SET authority_role=excluded.authority_role WHERE zasp_recovery_principal_bindings.authority_role=excluded.authority_role;
  IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='23505',MESSAGE='recovery principal conflict';END IF;
 END LOOP;
 RETURN true;
END
$register$;

CREATE FUNCTION public.zasp_recovery_principal_ready(expected_authority text) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $principal$
 SELECT expected_authority IN('zasp_recovery_worker','zasp_recovery_outbox_worker')
 AND EXISTS(SELECT 1 FROM zasp_recovery_principal_bindings binding JOIN pg_roles principal ON principal.rolname=binding.principal_name WHERE binding.principal_name=session_user AND binding.authority_role=expected_authority AND principal.rolcanlogin AND principal.rolinherit AND NOT principal.rolsuper AND NOT principal.rolcreatedb AND NOT principal.rolcreaterole AND NOT principal.rolreplication AND NOT principal.rolbypassrls)
 AND pg_has_role(session_user,expected_authority,'MEMBER') AND NOT pg_has_role(session_user,'zasp_discovery_authority','MEMBER')
$principal$;

CREATE FUNCTION public.zasp_recovery_principals_ready() RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $principals$
 SELECT (SELECT count(*) FROM zasp_recovery_principal_bindings)=2
 AND NOT EXISTS(SELECT 1 FROM zasp_recovery_principal_bindings binding LEFT JOIN pg_roles principal ON principal.rolname=binding.principal_name WHERE principal.oid IS NULL OR NOT principal.rolcanlogin OR NOT principal.rolinherit OR principal.rolsuper OR principal.rolcreatedb OR principal.rolcreaterole OR principal.rolreplication OR principal.rolbypassrls OR NOT pg_has_role(principal.rolname,binding.authority_role,'MEMBER'))
$principals$;

CREATE FUNCTION public.zasp_recovery_scope_mutable(organization_value text,workspace_value text,environment_value text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $mutable$
BEGIN
 IF NOT zasp_valid_product_id(organization_value) OR NOT zasp_valid_product_id(workspace_value) OR NOT zasp_valid_product_id(environment_value) THEN RETURN false;END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(concat_ws(chr(31),'zasp-recovery-hold',organization_value,workspace_value,environment_value),0));
 RETURN NOT EXISTS(SELECT 1 FROM zasp_recovery_holds WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value) AND state IN('requested','draining','held'));
END
$mutable$;

CREATE FUNCTION public.zasp_recovery_cleanup_evidence_valid(organization_value text,workspace_value text,environment_value text,cleanup_value jsonb) RETURNS boolean LANGUAGE sql IMMUTABLE SET search_path TO pg_catalog, public AS $cleanup_valid$
 SELECT CASE WHEN jsonb_typeof(cleanup_value)<>'object' OR octet_length(cleanup_value::text)>8192 THEN false ELSE
  (SELECT count(*)=2 FROM jsonb_object_keys(cleanup_value)) AND cleanup_value->>'state' IN('deleted','failed')
  AND CASE WHEN jsonb_typeof(cleanup_value->'evidence')<>'object' THEN false ELSE
   (SELECT count(*)=6 FROM jsonb_object_keys(cleanup_value->'evidence'))
   AND zasp_discovery_s3_object_reference(cleanup_value->'evidence'->>'reference')
   AND substring(cleanup_value->'evidence'->>'reference' FROM '^s3://[a-z0-9][a-z0-9.-]{2,62}/(.+)$') IS NOT DISTINCT FROM 'organizations/'||organization_value||'/workspaces/'||workspace_value||'/environments/'||environment_value||'/artifacts/'||substring(cleanup_value->'evidence'->>'reference' FROM '/artifacts/([^/]+)$')
   AND zasp_valid_product_id(substring(cleanup_value->'evidence'->>'reference' FROM '/artifacts/([^/]+)$'))
   AND length(cleanup_value->'evidence'->>'version_id') BETWEEN 1 AND 1024 AND cleanup_value->'evidence'->>'version_id'=btrim(cleanup_value->'evidence'->>'version_id') AND cleanup_value->'evidence'->>'version_id'!~'[[:space:][:cntrl:]]'
   AND cleanup_value->'evidence'->>'sha256'~'^[a-f0-9]{64}$' AND cleanup_value->'evidence'->>'sha256'<>repeat('0',64)
   AND CASE WHEN jsonb_typeof(cleanup_value->'evidence'->'size_bytes')='number' AND cleanup_value->'evidence'->>'size_bytes'~'^[0-9]+$' THEN (cleanup_value->'evidence'->>'size_bytes')::bigint BETWEEN 1 AND 67108864 ELSE false END
   AND cleanup_value->'evidence'->>'media_type'='application/json' AND cleanup_value->'evidence'->>'schema'='recovery_cleanup_v1'
  END
 END
$cleanup_valid$;

CREATE FUNCTION public.zasp_recovery_guard_scope_mutation() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $guard$
BEGIN
 IF TG_OP IN('UPDATE','DELETE') AND NOT zasp_recovery_scope_mutable(OLD.organization_id,OLD.workspace_id,OLD.environment_id) THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='tenant recovery hold active';END IF;
 IF TG_OP IN('INSERT','UPDATE') AND NOT zasp_recovery_scope_mutable(NEW.organization_id,NEW.workspace_id,NEW.environment_id) THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='tenant recovery hold active';END IF;
 IF TG_OP='DELETE' THEN RETURN OLD;END IF;RETURN NEW;
END
$guard$;

DO $guards$
DECLARE table_name text;
BEGIN
 FOR table_name IN
  SELECT class.relname
  FROM pg_class class JOIN pg_namespace namespace ON namespace.oid=class.relnamespace
  WHERE namespace.nspname='public' AND class.relkind='r' AND class.relname LIKE 'zasp_%' AND class.relname NOT LIKE 'zasp_recovery_%'
    AND EXISTS(SELECT 1 FROM pg_attribute attribute WHERE attribute.attrelid=class.oid AND attribute.attname='organization_id' AND attribute.attnum>0 AND NOT attribute.attisdropped)
    AND EXISTS(SELECT 1 FROM pg_attribute attribute WHERE attribute.attrelid=class.oid AND attribute.attname='workspace_id' AND attribute.attnum>0 AND NOT attribute.attisdropped)
    AND EXISTS(SELECT 1 FROM pg_attribute attribute WHERE attribute.attrelid=class.oid AND attribute.attname='environment_id' AND attribute.attnum>0 AND NOT attribute.attisdropped)
  ORDER BY class.relname
 LOOP
  EXECUTE format('CREATE TRIGGER %I BEFORE INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.zasp_recovery_guard_scope_mutation()',table_name||'_recovery_hold',table_name);
 END LOOP;
END
$guards$;

CREATE FUNCTION public.zasp_recovery_create_backup(organization_value text,workspace_value text,environment_value text,actor_value text,idempotency_value text,backup_value text,correlation_value text,retention_value integer,audit_value text,receipt_value text,request_digest_value bytea) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $create$
DECLARE receipt_row zasp_recovery_request_receipts%ROWTYPE;result_value jsonb;outbox_value text;payload_value jsonb;
BEGIN
 IF NOT zasp_discovery_principal_ready('zasp_discovery_api') OR NOT zasp_valid_product_id(organization_value) OR NOT zasp_valid_product_id(workspace_value) OR NOT zasp_valid_product_id(environment_value) OR NOT zasp_valid_product_id(actor_value) OR NOT zasp_valid_product_id(backup_value) OR NOT zasp_valid_product_id(correlation_value) OR NOT zasp_valid_product_id(audit_value) OR NOT zasp_valid_product_id(receipt_value) OR retention_value NOT BETWEEN 7 AND 90 OR length(idempotency_value) NOT BETWEEN 16 AND 128 OR octet_length(request_digest_value)<>32 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery backup request rejected';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(concat_ws(chr(31),organization_value,workspace_value,environment_value,actor_value,'startRecoveryBackup',idempotency_value),0));
 SELECT * INTO receipt_row FROM zasp_recovery_request_receipts WHERE (organization_id,workspace_id,environment_id,actor_id,operation,idempotency_key)=(organization_value,workspace_value,environment_value,actor_value,'startRecoveryBackup',idempotency_value);
 IF FOUND THEN IF receipt_row.resource_id<>backup_value OR receipt_row.request_digest<>request_digest_value OR receipt_row.expires_at<=transaction_timestamp() THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery backup replay rejected';END IF;RETURN receipt_row.result||jsonb_build_object('replayed',true);END IF;
 IF NOT zasp_recovery_scope_mutable(organization_value,workspace_value,environment_value) THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery backup request rejected';END IF;
 INSERT INTO zasp_recovery_backups(organization_id,workspace_id,environment_id,backup_id,retention_days,actor_id,idempotency_key,request_digest) VALUES(organization_value,workspace_value,environment_value,backup_value,retention_value,actor_value,idempotency_value,request_digest_value);
 outbox_value:=zasp_discovery_canonical_id(organization_value,workspace_value,environment_value,'recovery_backup_outbox',backup_value);payload_value:=jsonb_build_object('backup_id',backup_value,'environment_id',environment_value,'organization_id',organization_value,'workspace_id',workspace_value);
 INSERT INTO zasp_recovery_outbox(organization_id,workspace_id,environment_id,outbox_id,topic,deterministic_key,payload,payload_digest) VALUES(organization_value,workspace_value,environment_value,outbox_value,'recovery-backup-jobs','backup:'||backup_value,payload_value,digest(convert_to(payload_value::text,'UTF8'),'sha256'));
 result_value:=jsonb_build_object('audit_id',audit_value,'body',jsonb_build_object('id',backup_value,'version',1,'state','queued','retention_days',retention_value,'attempt',0,'created_at',to_char(transaction_timestamp() AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')),'correlation_id',correlation_value,'receipt_id',receipt_value,'replayed',false);
 INSERT INTO zasp_recovery_audit(organization_id,workspace_id,environment_id,audit_id,correlation_id,receipt_id,actor_id,event_kind,resource_id,event_digest,body) VALUES(organization_value,workspace_value,environment_value,audit_value,correlation_value,receipt_value,actor_value,'recovery_backup_requested',backup_value,request_digest_value,result_value->'body');
 INSERT INTO zasp_recovery_request_receipts(organization_id,workspace_id,environment_id,actor_id,operation,idempotency_key,resource_id,request_digest,result) VALUES(organization_value,workspace_value,environment_value,actor_value,'startRecoveryBackup',idempotency_value,backup_value,request_digest_value,result_value);
 RETURN result_value;
END
$create$;

CREATE FUNCTION public.zasp_recovery_create_restore(organization_value text,workspace_value text,environment_value text,actor_value text,idempotency_value text,restore_value text,target_value text,correlation_value text,audit_value text,receipt_value text,request_digest_value bytea,manifest_value jsonb,manifest_digest_value bytea) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $create$
DECLARE receipt_row zasp_recovery_request_receipts%ROWTYPE;result_value jsonb;outbox_value text;payload_value jsonb;
BEGIN
 IF NOT zasp_discovery_principal_ready('zasp_discovery_api') OR NOT zasp_valid_product_id(organization_value) OR NOT zasp_valid_product_id(workspace_value) OR NOT zasp_valid_product_id(environment_value) OR NOT zasp_valid_product_id(actor_value) OR NOT zasp_valid_product_id(restore_value) OR NOT zasp_valid_product_id(correlation_value) OR NOT zasp_valid_product_id(audit_value) OR NOT zasp_valid_product_id(receipt_value) OR target_value!~'^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$' OR target_value='production' OR target_value=environment_value OR length(idempotency_value) NOT BETWEEN 16 AND 128 OR octet_length(request_digest_value)<>32 OR octet_length(manifest_digest_value)<>32 OR jsonb_typeof(manifest_value)<>'object' OR octet_length(manifest_value::text)>8192
  OR (SELECT count(*) FROM jsonb_object_keys(manifest_value))<>8 OR NOT zasp_discovery_s3_object_reference(manifest_value->>'reference') OR substring(manifest_value->>'reference' FROM '^s3://[a-z0-9][a-z0-9.-]{2,62}/(.+)$') IS DISTINCT FROM 'organizations/'||organization_value||'/workspaces/'||workspace_value||'/environments/'||environment_value||'/artifacts/'||substring(manifest_value->>'reference' FROM '/artifacts/([^/]+)$') OR NOT zasp_valid_product_id(substring(manifest_value->>'reference' FROM '/artifacts/([^/]+)$')) OR length(manifest_value->>'version_id') NOT BETWEEN 1 AND 1024 OR manifest_value->>'version_id'<>btrim(manifest_value->>'version_id') OR manifest_value->>'version_id'~'[[:space:][:cntrl:]]'
  OR NOT (CASE WHEN manifest_value->>'sha256'~'^[a-f0-9]{64}$' THEN decode(manifest_value->>'sha256','hex')=manifest_digest_value ELSE false END) OR NOT (CASE WHEN jsonb_typeof(manifest_value->'size_bytes')='number' AND manifest_value->>'size_bytes'~'^[0-9]+$' THEN (manifest_value->>'size_bytes')::bigint BETWEEN 1 AND 67108864 ELSE false END)
  OR manifest_value->>'media_type'<>'application/vnd.zasp.recovery-manifest+json' OR manifest_value->>'schema'<>'recovery_signed_manifest_v1' OR manifest_value->>'signing_key_id'!~'^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  OR jsonb_typeof(manifest_value->'signature')<>'string' OR length(manifest_value->>'signature') NOT BETWEEN 43 AND 684 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery restore request rejected';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(concat_ws(chr(31),organization_value,workspace_value,environment_value,actor_value,'startRecoveryRestore',idempotency_value),0));
 SELECT * INTO receipt_row FROM zasp_recovery_request_receipts WHERE (organization_id,workspace_id,environment_id,actor_id,operation,idempotency_key)=(organization_value,workspace_value,environment_value,actor_value,'startRecoveryRestore',idempotency_value);
 IF FOUND THEN IF receipt_row.resource_id<>restore_value OR receipt_row.request_digest<>request_digest_value OR receipt_row.expires_at<=transaction_timestamp() THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery restore replay rejected';END IF;RETURN receipt_row.result||jsonb_build_object('replayed',true);END IF;
 IF NOT zasp_recovery_scope_mutable(organization_value,workspace_value,environment_value) THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery restore request rejected';END IF;
 INSERT INTO zasp_recovery_restores(organization_id,workspace_id,environment_id,restore_id,actor_id,idempotency_key,request_digest,target_environment,manifest,manifest_digest) VALUES(organization_value,workspace_value,environment_value,restore_value,actor_value,idempotency_value,request_digest_value,target_value,manifest_value,manifest_digest_value);
 outbox_value:=zasp_discovery_canonical_id(organization_value,workspace_value,environment_value,'recovery_restore_outbox',restore_value);payload_value:=jsonb_build_object('environment_id',environment_value,'organization_id',organization_value,'restore_id',restore_value,'target_environment',target_value,'workspace_id',workspace_value);
 INSERT INTO zasp_recovery_outbox(organization_id,workspace_id,environment_id,outbox_id,topic,deterministic_key,payload,payload_digest) VALUES(organization_value,workspace_value,environment_value,outbox_value,'recovery-restore-jobs','restore:'||restore_value,payload_value,digest(convert_to(payload_value::text,'UTF8'),'sha256'));
 result_value:=jsonb_build_object('audit_id',audit_value,'body',jsonb_build_object('id',restore_value,'version',1,'state','queued','target_environment',target_value,'attempt',0,'manifest',manifest_value,'created_at',to_char(transaction_timestamp() AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')),'correlation_id',correlation_value,'receipt_id',receipt_value,'replayed',false);
 INSERT INTO zasp_recovery_audit(organization_id,workspace_id,environment_id,audit_id,correlation_id,receipt_id,actor_id,event_kind,resource_id,event_digest,body) VALUES(organization_value,workspace_value,environment_value,audit_value,correlation_value,receipt_value,actor_value,'recovery_restore_requested',restore_value,request_digest_value,result_value->'body');
 INSERT INTO zasp_recovery_request_receipts(organization_id,workspace_id,environment_id,actor_id,operation,idempotency_key,resource_id,request_digest,result) VALUES(organization_value,workspace_value,environment_value,actor_value,'startRecoveryRestore',idempotency_value,restore_value,request_digest_value,result_value);
 RETURN result_value;
END
$create$;

CREATE FUNCTION public.zasp_recovery_get_backup(organization_value text,workspace_value text,environment_value text,backup_value text) RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $get$
 SELECT jsonb_strip_nulls(jsonb_build_object('id',backup_id,'version',version,'state',state,'retention_days',retention_days,'attempt',attempt,'manifest',manifest,'error_code',error_code,'created_at',to_char(created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'started_at',CASE WHEN started_at IS NULL THEN NULL ELSE to_char(started_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') END,'completed_at',CASE WHEN completed_at IS NULL THEN NULL ELSE to_char(completed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') END)) FROM zasp_recovery_backups WHERE zasp_discovery_principal_ready('zasp_discovery_api') AND (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,backup_value)
$get$;

CREATE FUNCTION public.zasp_recovery_get_restore(organization_value text,workspace_value text,environment_value text,restore_value text) RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $get$
 SELECT jsonb_strip_nulls(jsonb_build_object('id',restore_id,'version',version,'state',state,'target_environment',target_environment,'attempt',attempt,'manifest',manifest,'observed_counts',observed_counts,'validation_evidence',validation_evidence,'cleanup_evidence',cleanup_evidence,'error_code',error_code,'created_at',to_char(created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'started_at',CASE WHEN started_at IS NULL THEN NULL ELSE to_char(started_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') END,'completed_at',CASE WHEN completed_at IS NULL THEN NULL ELSE to_char(completed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') END)) FROM zasp_recovery_restores WHERE zasp_discovery_principal_ready('zasp_discovery_api') AND (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,restore_value)
$get$;

CREATE FUNCTION public.zasp_recovery_claim_outbox(topic_value text,worker_value text,token_value bytea,lease_seconds integer,limit_value integer) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $claim$
DECLARE last_value text;items_value jsonb;new_last text;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_outbox_worker') OR topic_value NOT IN('recovery-backup-jobs','recovery-restore-jobs') OR worker_value!~'^[a-z][a-z0-9.-]{2,127}$' OR octet_length(token_value)<>32 OR lease_seconds NOT BETWEEN 5 AND 900 OR limit_value NOT BETWEEN 1 AND 25 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery outbox claim rejected';END IF;
 WITH exhausted AS (
  UPDATE zasp_recovery_outbox SET state='exhausted',error_code='queue_publish_unknown',worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE topic=topic_value AND state IN('pending','retryable','leased') AND attempt>=100 AND available_at<=transaction_timestamp() AND (state<>'leased' OR lease_expires_at<=transaction_timestamp()) RETURNING organization_id,workspace_id,environment_id,topic,payload
 ),failed_backups AS (
  UPDATE zasp_recovery_backups operation SET state='failed',version=version+1,error_code='exhausted',completed_at=transaction_timestamp(),updated_at=transaction_timestamp() FROM exhausted WHERE exhausted.topic='recovery-backup-jobs' AND operation.state='queued' AND operation.attempt=0 AND (operation.organization_id,operation.workspace_id,operation.environment_id,operation.backup_id)=(exhausted.organization_id,exhausted.workspace_id,exhausted.environment_id,exhausted.payload->>'backup_id') RETURNING operation.backup_id
 )
 UPDATE zasp_recovery_restores operation SET state='failed',version=version+1,error_code='exhausted',completed_at=transaction_timestamp(),updated_at=transaction_timestamp() FROM exhausted WHERE exhausted.topic='recovery-restore-jobs' AND operation.state='queued' AND operation.attempt=0 AND (operation.organization_id,operation.workspace_id,operation.environment_id,operation.restore_id)=(exhausted.organization_id,exhausted.workspace_id,exhausted.environment_id,exhausted.payload->>'restore_id');
 SELECT last_organization_id INTO last_value FROM zasp_recovery_fairness WHERE topic=topic_value FOR UPDATE;
 WITH ranked AS (SELECT outbox.*,row_number() OVER(PARTITION BY organization_id ORDER BY available_at,created_at,outbox_id) AS organization_rank FROM zasp_recovery_outbox outbox WHERE topic=topic_value AND state IN('pending','retryable','leased') AND attempt<100 AND available_at<=transaction_timestamp() AND (state<>'leased' OR lease_expires_at<=transaction_timestamp()) AND NOT EXISTS(SELECT 1 FROM zasp_recovery_outbox live WHERE live.organization_id=outbox.organization_id AND live.topic=topic_value AND live.state='leased' AND live.lease_expires_at>transaction_timestamp())),
 candidates AS (SELECT organization_id,workspace_id,environment_id,outbox_id FROM ranked WHERE organization_rank=1 ORDER BY (organization_id>COALESCE(last_value,'')) DESC,organization_id,available_at,created_at,outbox_id LIMIT limit_value FOR UPDATE SKIP LOCKED),
 claimed AS (UPDATE zasp_recovery_outbox target SET state='leased',attempt=attempt+1,worker_id=worker_value,lease_token=token_value,lease_expires_at=transaction_timestamp()+make_interval(secs=>lease_seconds),updated_at=transaction_timestamp() FROM candidates WHERE (target.organization_id,target.workspace_id,target.environment_id,target.outbox_id)=(candidates.organization_id,candidates.workspace_id,candidates.environment_id,candidates.outbox_id) RETURNING target.*)
 SELECT COALESCE(jsonb_agg(jsonb_build_object('organization_id',organization_id,'workspace_id',workspace_id,'environment_id',environment_id,'outbox_id',outbox_id,'topic',topic,'payload',payload,'payload_digest',payload_digest,'attempt',attempt,'lease_expires_at',to_char(lease_expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) ORDER BY organization_id),'[]'::jsonb),max(organization_id) INTO items_value,new_last FROM claimed;
 IF new_last IS NOT NULL THEN UPDATE zasp_recovery_fairness SET last_organization_id=new_last,updated_at=transaction_timestamp() WHERE topic=topic_value;END IF;
 RETURN jsonb_build_object('items',items_value);
END
$claim$;

CREATE FUNCTION public.zasp_recovery_heartbeat_outbox(topic_value text,worker_value text,token_value bytea,lease_seconds integer,expected_count integer) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $heartbeat$
DECLARE renewed integer;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_outbox_worker') OR topic_value NOT IN('recovery-backup-jobs','recovery-restore-jobs') OR worker_value!~'^[a-z][a-z0-9.-]{2,127}$' OR octet_length(token_value)<>32 OR lease_seconds NOT BETWEEN 5 AND 900 OR expected_count NOT BETWEEN 1 AND 25 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery outbox heartbeat rejected';END IF;
 UPDATE zasp_recovery_outbox SET lease_expires_at=transaction_timestamp()+make_interval(secs=>lease_seconds),updated_at=transaction_timestamp() WHERE topic=topic_value AND state='leased' AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp();GET DIAGNOSTICS renewed=ROW_COUNT;
 IF renewed<>expected_count THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery outbox lease lost';END IF;RETURN jsonb_build_object('lease_expires_at',to_char((transaction_timestamp()+make_interval(secs=>lease_seconds)) AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'renewed',renewed);
END
$heartbeat$;

CREATE FUNCTION public.zasp_recovery_ack_outbox(organization_value text,workspace_value text,environment_value text,outbox_value text,worker_value text,token_value bytea,ack_value text) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $ack$
DECLARE row_value zasp_recovery_outbox%ROWTYPE;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_outbox_worker') OR ack_value!~'^sha256:[a-f0-9]{64}$' THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery outbox ack rejected';END IF;
 SELECT * INTO STRICT row_value FROM zasp_recovery_outbox WHERE (organization_id,workspace_id,environment_id,outbox_id)=(organization_value,workspace_value,environment_value,outbox_value) FOR UPDATE;
 IF row_value.state='published' THEN IF row_value.provider_ack<>ack_value THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery outbox ack conflict';END IF;RETURN jsonb_build_object('replayed',true);END IF;
 IF row_value.state<>'leased' OR row_value.worker_id<>worker_value OR row_value.lease_token<>token_value OR row_value.lease_expires_at<=transaction_timestamp() THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery outbox lease lost';END IF;
 UPDATE zasp_recovery_outbox SET state='published',provider_ack=ack_value,published_at=transaction_timestamp(),worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,outbox_id)=(organization_value,workspace_value,environment_value,outbox_value);RETURN jsonb_build_object('replayed',false);
END
$ack$;

CREATE FUNCTION public.zasp_recovery_retry_outbox(organization_value text,workspace_value text,environment_value text,outbox_value text,worker_value text,token_value bytea,retry_seconds integer,error_value text) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $retry$
DECLARE row_value zasp_recovery_outbox%ROWTYPE;next_state text;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_outbox_worker') OR retry_seconds NOT BETWEEN 1 AND 86400 OR error_value<>'queue_publish_unknown' THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery outbox retry rejected';END IF;
 SELECT * INTO STRICT row_value FROM zasp_recovery_outbox WHERE (organization_id,workspace_id,environment_id,outbox_id)=(organization_value,workspace_value,environment_value,outbox_value) FOR UPDATE;
 IF row_value.state<>'leased' OR row_value.worker_id<>worker_value OR row_value.lease_token<>token_value OR row_value.lease_expires_at<=transaction_timestamp() THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery outbox lease lost';END IF;
 next_state:=CASE WHEN row_value.attempt>=100 THEN 'exhausted' ELSE 'retryable' END;UPDATE zasp_recovery_outbox SET state=next_state,available_at=transaction_timestamp()+make_interval(secs=>retry_seconds),error_code=error_value,worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,outbox_id)=(organization_value,workspace_value,environment_value,outbox_value);
 IF next_state='exhausted' AND row_value.topic='recovery-backup-jobs' THEN UPDATE zasp_recovery_backups SET state='failed',version=version+1,error_code='exhausted',completed_at=transaction_timestamp(),updated_at=transaction_timestamp() WHERE state='queued' AND attempt=0 AND (organization_id,workspace_id,environment_id,backup_id)=(row_value.organization_id,row_value.workspace_id,row_value.environment_id,row_value.payload->>'backup_id');
 ELSIF next_state='exhausted' AND row_value.topic='recovery-restore-jobs' THEN UPDATE zasp_recovery_restores SET state='failed',version=version+1,error_code='exhausted',completed_at=transaction_timestamp(),updated_at=transaction_timestamp() WHERE state='queued' AND attempt=0 AND (organization_id,workspace_id,environment_id,restore_id)=(row_value.organization_id,row_value.workspace_id,row_value.environment_id,row_value.payload->>'restore_id');END IF;
 RETURN jsonb_build_object('state',next_state);
END
$retry$;

CREATE FUNCTION public.zasp_recovery_claim_operation(kind_value text,worker_value text,token_value bytea,lease_seconds integer,limit_value integer) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $claim$
DECLARE last_value text;items_value jsonb;new_last text;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR kind_value NOT IN('backup','restore') OR worker_value!~'^[a-z][a-z0-9.-]{2,127}$' OR octet_length(token_value)<>32 OR lease_seconds NOT BETWEEN 5 AND 900 OR limit_value NOT BETWEEN 1 AND 25 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery operation claim rejected';END IF;
 UPDATE zasp_recovery_backups SET state='failed',error_code='exhausted',completed_at=transaction_timestamp(),worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE kind_value='backup' AND state IN('queued','retryable','draining','capturing','publishing') AND attempt>=100 AND available_at<=transaction_timestamp() AND (state NOT IN('draining','capturing','publishing') OR lease_expires_at<=transaction_timestamp());
 UPDATE zasp_recovery_holds hold SET state='released',released_at=transaction_timestamp() FROM zasp_recovery_backups backup WHERE kind_value='backup' AND (hold.organization_id,hold.workspace_id,hold.environment_id,hold.operation_id,hold.state)=(backup.organization_id,backup.workspace_id,backup.environment_id,backup.backup_id,'held') AND backup.state='failed' AND backup.error_code='exhausted';
 UPDATE zasp_recovery_restores SET state='failed',error_code='exhausted',completed_at=transaction_timestamp(),worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE kind_value='restore' AND state IN('queued','retryable','verifying') AND attempt>=100 AND available_at<=transaction_timestamp() AND (state<>'verifying' OR lease_expires_at<=transaction_timestamp());
 SELECT last_organization_id INTO last_value FROM zasp_recovery_fairness WHERE topic='recovery-operations' FOR UPDATE;
 IF kind_value='backup' THEN
  WITH ranked AS (SELECT operation.*,row_number() OVER(PARTITION BY organization_id ORDER BY available_at,created_at,backup_id) AS organization_rank FROM zasp_recovery_backups operation WHERE state IN('queued','retryable','draining','capturing','publishing') AND attempt<100 AND available_at<=transaction_timestamp() AND (state NOT IN('draining','capturing','publishing') OR lease_expires_at<=transaction_timestamp()) AND NOT EXISTS(SELECT 1 FROM zasp_recovery_backups live WHERE live.organization_id=operation.organization_id AND live.state IN('draining','capturing','publishing') AND live.lease_expires_at>transaction_timestamp()) AND NOT EXISTS(SELECT 1 FROM zasp_recovery_restores live WHERE live.organization_id=operation.organization_id AND live.state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND live.lease_expires_at>transaction_timestamp())),
  candidates AS (SELECT organization_id,workspace_id,environment_id,backup_id FROM ranked WHERE organization_rank=1 ORDER BY (organization_id>COALESCE(last_value,'')) DESC,organization_id,available_at,created_at,backup_id LIMIT limit_value FOR UPDATE SKIP LOCKED),
  claimed AS (UPDATE zasp_recovery_backups target SET state='draining',attempt=attempt+1,error_code=NULL,completed_at=NULL,worker_id=worker_value,lease_token=token_value,lease_expires_at=transaction_timestamp()+make_interval(secs=>lease_seconds),started_at=COALESCE(started_at,transaction_timestamp()),updated_at=transaction_timestamp() FROM candidates WHERE (target.organization_id,target.workspace_id,target.environment_id,target.backup_id)=(candidates.organization_id,candidates.workspace_id,candidates.environment_id,candidates.backup_id) RETURNING target.*)
  SELECT COALESCE(jsonb_agg(jsonb_build_object('attempt',attempt,'backup_id',backup_id,'cleanup_only',false,'environment_id',environment_id,'lease_expires_at',to_char(lease_expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'organization_id',organization_id,'request_digest',request_digest,'retention_days',retention_days,'workspace_id',workspace_id) ORDER BY organization_id),'[]'::jsonb),max(organization_id) INTO items_value,new_last FROM claimed;
 ELSE
  WITH ranked AS (SELECT operation.*,row_number() OVER(PARTITION BY organization_id ORDER BY available_at,created_at,restore_id) AS organization_rank FROM zasp_recovery_restores operation WHERE state IN('queued','retryable','verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND (attempt<100 OR attempt=100 AND state IN('provisioning','validating','rebuilding','cleanup_required','cleaning')) AND available_at<=transaction_timestamp() AND (state NOT IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') OR lease_expires_at<=transaction_timestamp()) AND NOT EXISTS(SELECT 1 FROM zasp_recovery_backups live WHERE live.organization_id=operation.organization_id AND live.state IN('draining','capturing','publishing') AND live.lease_expires_at>transaction_timestamp()) AND NOT EXISTS(SELECT 1 FROM zasp_recovery_restores live WHERE live.organization_id=operation.organization_id AND live.state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND live.lease_expires_at>transaction_timestamp())),
  candidates AS (SELECT organization_id,workspace_id,environment_id,restore_id FROM ranked WHERE organization_rank=1 ORDER BY (organization_id>COALESCE(last_value,'')) DESC,organization_id,available_at,created_at,restore_id LIMIT limit_value FOR UPDATE SKIP LOCKED),
  claimed AS (UPDATE zasp_recovery_restores target SET state=CASE WHEN target.attempt>=100 THEN target.state ELSE 'verifying' END,attempt=CASE WHEN target.attempt>=100 THEN target.attempt ELSE target.attempt+1 END,observed_counts=CASE WHEN target.attempt>=100 THEN target.observed_counts ELSE NULL END,validation_evidence=CASE WHEN target.attempt>=100 THEN target.validation_evidence ELSE NULL END,cleanup_evidence=NULL,error_code=NULL,completed_at=NULL,worker_id=worker_value,lease_token=token_value,lease_expires_at=transaction_timestamp()+make_interval(secs=>lease_seconds),started_at=COALESCE(started_at,transaction_timestamp()),updated_at=transaction_timestamp() FROM candidates WHERE (target.organization_id,target.workspace_id,target.environment_id,target.restore_id)=(candidates.organization_id,candidates.workspace_id,candidates.environment_id,candidates.restore_id) RETURNING target.*)
  SELECT COALESCE(jsonb_agg(jsonb_build_object('attempt',attempt,'cleanup_only',attempt=100 AND state<>'verifying','environment_id',environment_id,'lease_expires_at',to_char(lease_expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'manifest',manifest,'manifest_digest',manifest_digest,'organization_id',organization_id,'request_digest',request_digest,'restore_id',restore_id,'target_environment',target_environment,'workspace_id',workspace_id) ORDER BY organization_id),'[]'::jsonb),max(organization_id) INTO items_value,new_last FROM claimed;
 END IF;
 IF new_last IS NOT NULL THEN UPDATE zasp_recovery_fairness SET last_organization_id=new_last,updated_at=transaction_timestamp() WHERE topic='recovery-operations';END IF;RETURN jsonb_build_object('items',items_value);
END
$claim$;

CREATE FUNCTION public.zasp_recovery_claim_delivery(kind_value text,organization_value text,workspace_value text,environment_value text,operation_value text,worker_value text,token_value bytea,lease_seconds integer) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $delivery$
DECLARE backup_value zasp_recovery_backups%ROWTYPE;restore_value zasp_recovery_restores%ROWTYPE;operation_json jsonb;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR kind_value NOT IN('backup','restore') OR NOT zasp_valid_product_id(organization_value) OR NOT zasp_valid_product_id(workspace_value) OR NOT zasp_valid_product_id(environment_value) OR NOT zasp_valid_product_id(operation_value) OR worker_value!~'^[a-z][a-z0-9.-]{2,127}$' OR octet_length(token_value)<>32 OR lease_seconds NOT BETWEEN 5 AND 900 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery delivery claim rejected';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(concat_ws(chr(31),'zasp-recovery-operation',organization_value),0));
 IF kind_value='backup' THEN
  SELECT * INTO backup_value FROM zasp_recovery_backups WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,operation_value) FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('disposition','retry_later');END IF;
  IF backup_value.state IN('succeeded','failed') THEN RETURN jsonb_build_object('disposition','ack_terminal');END IF;
  IF backup_value.state IN('draining','capturing','publishing') AND backup_value.lease_expires_at>transaction_timestamp() OR backup_value.available_at>transaction_timestamp() THEN RETURN jsonb_build_object('disposition','retry_later');END IF;
  IF backup_value.attempt>=100 THEN
   UPDATE zasp_recovery_backups SET state='failed',error_code='exhausted',completed_at=transaction_timestamp(),worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,operation_value);
   UPDATE zasp_recovery_holds SET state='released',released_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,operation_id,state)=(organization_value,workspace_value,environment_value,operation_value,'held');
   RETURN jsonb_build_object('disposition','exhausted');
  END IF;
  IF EXISTS(SELECT 1 FROM zasp_recovery_backups live WHERE live.organization_id=organization_value AND (live.workspace_id,live.environment_id,live.backup_id)<>(workspace_value,environment_value,operation_value) AND live.state IN('draining','capturing','publishing') AND live.lease_expires_at>transaction_timestamp()) OR EXISTS(SELECT 1 FROM zasp_recovery_restores live WHERE live.organization_id=organization_value AND live.state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND live.lease_expires_at>transaction_timestamp()) THEN RETURN jsonb_build_object('disposition','retry_later');END IF;
  UPDATE zasp_recovery_backups SET state='draining',attempt=attempt+1,error_code=NULL,completed_at=NULL,worker_id=worker_value,lease_token=token_value,lease_expires_at=transaction_timestamp()+make_interval(secs=>lease_seconds),started_at=COALESCE(started_at,transaction_timestamp()),updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,operation_value) RETURNING jsonb_build_object('attempt',attempt,'backup_id',backup_id,'cleanup_only',false,'created_at',to_char(created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'environment_id',environment_id,'lease_expires_at',to_char(lease_expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'organization_id',organization_id,'request_digest',request_digest,'retention_days',retention_days,'workspace_id',workspace_id) INTO STRICT operation_json;
 ELSE
  SELECT * INTO restore_value FROM zasp_recovery_restores WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value) FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('disposition','retry_later');END IF;
  IF restore_value.state IN('succeeded','failed','failed_cleanup') THEN RETURN jsonb_build_object('disposition','ack_terminal');END IF;
  IF restore_value.state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND restore_value.lease_expires_at>transaction_timestamp() OR restore_value.available_at>transaction_timestamp() THEN RETURN jsonb_build_object('disposition','retry_later');END IF;
  IF restore_value.attempt>=100 THEN
   IF restore_value.state IN('provisioning','validating','rebuilding','cleanup_required','cleaning') THEN
    IF EXISTS(SELECT 1 FROM zasp_recovery_backups live WHERE live.organization_id=organization_value AND live.state IN('draining','capturing','publishing') AND live.lease_expires_at>transaction_timestamp()) OR EXISTS(SELECT 1 FROM zasp_recovery_restores live WHERE live.organization_id=organization_value AND (live.workspace_id,live.environment_id,live.restore_id)<>(workspace_value,environment_value,operation_value) AND live.state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND live.lease_expires_at>transaction_timestamp()) THEN RETURN jsonb_build_object('disposition','retry_later');END IF;
    UPDATE zasp_recovery_restores SET cleanup_evidence=NULL,error_code=NULL,completed_at=NULL,worker_id=worker_value,lease_token=token_value,lease_expires_at=transaction_timestamp()+make_interval(secs=>lease_seconds),updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value) RETURNING jsonb_build_object('attempt',attempt,'cleanup_only',true,'created_at',to_char(created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'environment_id',environment_id,'lease_expires_at',to_char(lease_expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'manifest',manifest,'manifest_digest',manifest_digest,'organization_id',organization_id,'request_digest',request_digest,'restore_id',restore_id,'target_environment',target_environment,'workspace_id',workspace_id) INTO STRICT operation_json;
    RETURN jsonb_build_object('disposition','claimed','operation',operation_json);
   END IF;
   UPDATE zasp_recovery_restores SET state='failed',error_code='exhausted',completed_at=transaction_timestamp(),worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value);
   RETURN jsonb_build_object('disposition','exhausted');
  END IF;
  IF EXISTS(SELECT 1 FROM zasp_recovery_backups live WHERE live.organization_id=organization_value AND live.state IN('draining','capturing','publishing') AND live.lease_expires_at>transaction_timestamp()) OR EXISTS(SELECT 1 FROM zasp_recovery_restores live WHERE live.organization_id=organization_value AND (live.workspace_id,live.environment_id,live.restore_id)<>(workspace_value,environment_value,operation_value) AND live.state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND live.lease_expires_at>transaction_timestamp()) THEN RETURN jsonb_build_object('disposition','retry_later');END IF;
  UPDATE zasp_recovery_restores SET state='verifying',attempt=attempt+1,observed_counts=NULL,validation_evidence=NULL,cleanup_evidence=NULL,error_code=NULL,completed_at=NULL,worker_id=worker_value,lease_token=token_value,lease_expires_at=transaction_timestamp()+make_interval(secs=>lease_seconds),started_at=COALESCE(started_at,transaction_timestamp()),updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value) RETURNING jsonb_build_object('attempt',attempt,'cleanup_only',false,'created_at',to_char(created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'environment_id',environment_id,'lease_expires_at',to_char(lease_expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'manifest',manifest,'manifest_digest',manifest_digest,'organization_id',organization_id,'request_digest',request_digest,'restore_id',restore_id,'target_environment',target_environment,'workspace_id',workspace_id) INTO STRICT operation_json;
 END IF;
 RETURN jsonb_build_object('disposition','claimed','operation',operation_json);
END
$delivery$;

CREATE FUNCTION public.zasp_recovery_heartbeat_operation(kind_value text,organization_value text,workspace_value text,environment_value text,operation_value text,worker_value text,token_value bytea,lease_seconds integer) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $heartbeat$
DECLARE expires_value timestamptz:=transaction_timestamp()+make_interval(secs=>lease_seconds);updated integer;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR kind_value NOT IN('backup','restore') OR lease_seconds NOT BETWEEN 5 AND 900 OR octet_length(token_value)<>32 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery heartbeat rejected';END IF;
 IF kind_value='backup' THEN UPDATE zasp_recovery_backups SET lease_expires_at=expires_value,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,operation_value) AND state IN('draining','capturing','publishing') AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp();
 ELSE UPDATE zasp_recovery_restores SET lease_expires_at=expires_value,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value) AND state IN('verifying','provisioning','validating','rebuilding','cleanup_required','cleaning') AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp();END IF;
 GET DIAGNOSTICS updated=ROW_COUNT;IF updated<>1 THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery operation lease lost';END IF;RETURN jsonb_build_object('lease_expires_at',to_char(expires_value AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'));
END
$heartbeat$;

CREATE FUNCTION public.zasp_recovery_begin_hold(organization_value text,workspace_value text,environment_value text,backup_value text,worker_value text,token_value bytea) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $hold$
DECLARE row_value zasp_recovery_backups%ROWTYPE;epoch_value bigint;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR octet_length(token_value)<>32 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery hold rejected';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(concat_ws(chr(31),'zasp-recovery-hold',organization_value,workspace_value,environment_value),0));
 SELECT * INTO STRICT row_value FROM zasp_recovery_backups WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,backup_value) FOR UPDATE;
 IF row_value.state<>'draining' OR row_value.worker_id<>worker_value OR row_value.lease_token<>token_value OR row_value.lease_expires_at<=transaction_timestamp() THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery hold lease lost';END IF;
 epoch_value:=COALESCE((SELECT epoch+1 FROM zasp_recovery_holds WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)),1);
 INSERT INTO zasp_recovery_holds(organization_id,workspace_id,environment_id,epoch,operation_id,state,requested_at,held_at) VALUES(organization_value,workspace_value,environment_value,epoch_value,backup_value,'held',transaction_timestamp(),transaction_timestamp()) ON CONFLICT(organization_id,workspace_id,environment_id) DO UPDATE SET epoch=excluded.epoch,operation_id=excluded.operation_id,state='held',requested_at=excluded.requested_at,held_at=excluded.held_at,released_at=NULL;
 UPDATE zasp_recovery_backups SET state='capturing',hold_epoch=epoch_value,version=version+1,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,backup_value);RETURN jsonb_build_object('epoch',epoch_value,'state','held');
END
$hold$;

CREATE FUNCTION public.zasp_recovery_release_hold(organization_value text,workspace_value text,environment_value text,backup_value text,worker_value text,token_value bytea) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $release$
DECLARE updated integer;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR octet_length(token_value)<>32 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery hold release rejected';END IF;
 PERFORM 1 FROM zasp_recovery_backups WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,backup_value) AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery hold lease lost';END IF;
 UPDATE zasp_recovery_holds SET state='released',released_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,operation_id,state)=(organization_value,workspace_value,environment_value,backup_value,'held');GET DIAGNOSTICS updated=ROW_COUNT;RETURN jsonb_build_object('released',updated=1);
END
$release$;

CREATE FUNCTION public.zasp_recovery_capture_page(organization_value text,workspace_value text,environment_value text,backup_value text,worker_value text,token_value bytea,section_value text,after_value text,limit_value integer) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $capture$
DECLARE items_value jsonb;next_value text;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR octet_length(token_value)<>32 OR section_value NOT IN('configuration','projection','evidence','counts') OR limit_value NOT BETWEEN 1 AND 100
  OR section_value='configuration' AND after_value IS NOT NULL AND after_value!~'^(integration|security_agent):pid_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  OR section_value IN('projection','evidence') AND after_value IS NOT NULL AND NOT zasp_valid_product_id(after_value)
  OR section_value='counts' AND (after_value IS NOT NULL OR limit_value<>1)
  OR NOT EXISTS(SELECT 1 FROM zasp_recovery_backups WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,backup_value) AND state='capturing' AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp()) THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery capture rejected';END IF;
 IF section_value='configuration' THEN
  WITH entries AS (
   SELECT 'integration:'||integration.id cursor_value,jsonb_build_object(
    'configuration',integration.configuration,'connections',COALESCE((SELECT jsonb_agg(jsonb_build_object('connection_reference',connection.connection_reference,'id',connection.id,'provider',connection.provider,'state',connection.state,'version',connection.version) ORDER BY connection.id) FROM zasp_integration_connections connection WHERE (connection.organization_id,connection.workspace_id,connection.environment_id,connection.integration_id)=(integration.organization_id,integration.workspace_id,integration.environment_id,integration.id)),'[]'::jsonb),
    'connector_version',integration.connector_version,'display_name',integration.display_name,'id',integration.id,'kind',integration.kind,
    'resource_kind','integration','schedule',(SELECT jsonb_build_object('cadence_seconds',schedule.cadence_seconds,'id',schedule.id,'state',schedule.state,'time_zone',schedule.time_zone,'version',schedule.version) FROM zasp_discovery_schedules schedule WHERE (schedule.organization_id,schedule.workspace_id,schedule.environment_id,schedule.integration_id)=(integration.organization_id,integration.workspace_id,integration.environment_id,integration.id)),'state',integration.state,'version',integration.version) item
   FROM zasp_integrations integration WHERE (integration.organization_id,integration.workspace_id,integration.environment_id)=(organization_value,workspace_value,environment_value)
   UNION ALL
   SELECT 'security_agent:'||definition.definition_id,jsonb_build_object('activation',definition.activation,'body',definition.body,'definition_version',definition.definition_version,'id',definition.definition_id,'plan_catalog_version',definition.plan_catalog_version,'resource_kind','security_agent','version',definition.version)
   FROM zasp_security_agent_definitions definition WHERE (definition.organization_id,definition.workspace_id,definition.environment_id)=(organization_value,workspace_value,environment_value) AND definition.deleted_at IS NULL
  ),page AS (SELECT cursor_value,item FROM entries WHERE cursor_value>COALESCE(after_value,'') ORDER BY cursor_value LIMIT limit_value)
  SELECT COALESCE(jsonb_agg(item ORDER BY cursor_value),'[]'::jsonb),CASE WHEN count(*)=limit_value THEN max(cursor_value) END INTO items_value,next_value FROM page;
 ELSIF section_value='projection' THEN
  IF EXISTS(
   SELECT 1 FROM zasp_discovery_projection_cursors cursor
   WHERE (cursor.organization_id,cursor.workspace_id,cursor.environment_id)=(organization_value,workspace_value,environment_value)
    AND NOT EXISTS(SELECT 1 FROM zasp_discovery_projection_receipts receipt WHERE (receipt.organization_id,receipt.workspace_id,receipt.environment_id,receipt.integration_id,receipt.source,receipt.kind,receipt.snapshot_id,receipt.generation,receipt.input_digest)=(cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id,cursor.source,cursor.kind,cursor.snapshot_id,cursor.generation,cursor.input_digest))
  ) THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='recovery projection receipt missing';END IF;
  WITH integration_ids AS (
   SELECT integration_id FROM zasp_discovery_cursors WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)
   UNION SELECT integration_id FROM zasp_discovery_snapshot_inputs WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)
   UNION SELECT integration_id FROM zasp_discovery_projection_cursors WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)
  ),page AS (SELECT integration_id id,jsonb_build_object(
   'collection_cursors',COALESCE((SELECT jsonb_agg(jsonb_build_object('committed_at',to_char(cursor.committed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'cursor_value',cursor.cursor_value,'provider',cursor.provider,'snapshot_id',cursor.snapshot_id) ORDER BY cursor.provider) FROM zasp_discovery_cursors cursor WHERE (cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id)=(organization_value,workspace_value,environment_value,integration_ids.integration_id)),'[]'::jsonb),
   'integration_id',integration_id,
   'projection_cursors',COALESCE((SELECT jsonb_agg(jsonb_build_object('driver_digest',(SELECT encode(receipt.driver_digest,'hex') FROM zasp_discovery_projection_receipts receipt WHERE (receipt.organization_id,receipt.workspace_id,receipt.environment_id,receipt.integration_id,receipt.source,receipt.kind,receipt.snapshot_id,receipt.generation,receipt.input_digest)=(cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id,cursor.source,cursor.kind,cursor.snapshot_id,cursor.generation,cursor.input_digest) ORDER BY receipt.completed_at DESC,receipt.version DESC LIMIT 1),'generation',cursor.generation,'input_digest',encode(cursor.input_digest,'hex'),'kind',cursor.kind,'snapshot_id',cursor.snapshot_id,'source',cursor.source,'updated_at',to_char(cursor.updated_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) ORDER BY cursor.source,cursor.kind) FROM zasp_discovery_projection_cursors cursor WHERE (cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id)=(organization_value,workspace_value,environment_value,integration_ids.integration_id)),'[]'::jsonb),
   'snapshot_inputs',COALESCE((SELECT jsonb_agg(jsonb_build_object('candidate_digest',encode(input.candidate_digest,'hex'),'generation',input.generation,'manifest_checksum',encode(input.manifest_checksum,'hex'),'manifest_key',input.manifest_key,'manifest_media_type',input.manifest_media_type,'manifest_reference',input.manifest_reference,'manifest_schema_version',input.manifest_schema_version,'manifest_size_bytes',input.manifest_size_bytes,'manifest_version_id',input.manifest_version_id,'parser_version',input.parser_version,'snapshot_id',input.snapshot_id,'source',input.source,'tool_version',input.tool_version) ORDER BY input.source,input.generation) FROM zasp_discovery_snapshot_inputs input WHERE (input.organization_id,input.workspace_id,input.environment_id,input.integration_id)=(organization_value,workspace_value,environment_value,integration_ids.integration_id)),'[]'::jsonb)) item
   FROM integration_ids WHERE integration_id>COALESCE(after_value,'') ORDER BY integration_id LIMIT limit_value)
  SELECT COALESCE(jsonb_agg(item ORDER BY id),'[]'::jsonb),CASE WHEN count(*)=limit_value THEN max(id) END INTO items_value,next_value FROM page;
 ELSIF section_value='evidence' THEN
  WITH page AS (SELECT id,jsonb_build_object('artifact_key',artifact_key,'artifact_reference',artifact_reference,'artifact_version_id',artifact_version_id,'checksum',encode(checksum,'hex'),'collected_at',to_char(collected_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'id',id,'media_type',media_type,'object_reference',object_reference,'schema_version',schema_version,'size_bytes',size_bytes) item FROM zasp_inventory_evidence WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value) AND id>COALESCE(after_value,'') ORDER BY id LIMIT limit_value)
  SELECT COALESCE(jsonb_agg(item ORDER BY id),'[]'::jsonb),CASE WHEN count(*)=limit_value THEN max(id) END INTO items_value,next_value FROM page;
 ELSE
  SELECT jsonb_build_array(jsonb_build_object(
   'assets',(SELECT count(*) FROM zasp_inventory_entities WHERE (organization_id,workspace_id,environment_id,state)=(organization_value,workspace_value,environment_value,'active')),
   'findings',(SELECT count(*) FROM zasp_risk_findings WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)),
   'policies',COALESCE((SELECT sum(jsonb_array_length(bundle.policies)) FROM zasp_runtime_gateway_policy_bundles bundle WHERE (bundle.organization_id,bundle.workspace_id,bundle.environment_id)=(organization_value,workspace_value,environment_value) AND NOT EXISTS(SELECT 1 FROM zasp_runtime_gateway_policy_bundles later WHERE (later.organization_id,later.workspace_id,later.environment_id,later.device_id)=(bundle.organization_id,bundle.workspace_id,bundle.environment_id,bundle.device_id) AND later.sequence>bundle.sequence)),0))) INTO items_value;next_value:=NULL;
 END IF;
 RETURN jsonb_build_object('items',items_value,'next_cursor',next_value,'section',section_value);
END
$capture$;

CREATE FUNCTION public.zasp_recovery_validate_scope(organization_value text,workspace_value text,environment_value text) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $validate$
DECLARE counts_value jsonb;evidence_samples_value jsonb;projection_value jsonb;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR NOT zasp_valid_product_id(organization_value) OR NOT zasp_valid_product_id(workspace_value) OR NOT zasp_valid_product_id(environment_value) OR NOT EXISTS(SELECT 1 FROM zasp_environments WHERE (organization_id,workspace_id,id)=(organization_value,workspace_value,environment_value)) THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery scope validation rejected';END IF;
 IF EXISTS(
  SELECT 1 FROM zasp_discovery_projection_cursors cursor
  WHERE (cursor.organization_id,cursor.workspace_id,cursor.environment_id)=(organization_value,workspace_value,environment_value)
   AND NOT EXISTS(SELECT 1 FROM zasp_discovery_projection_receipts receipt WHERE (receipt.organization_id,receipt.workspace_id,receipt.environment_id,receipt.integration_id,receipt.source,receipt.kind,receipt.snapshot_id,receipt.generation,receipt.input_digest)=(cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id,cursor.source,cursor.kind,cursor.snapshot_id,cursor.generation,cursor.input_digest))
 ) THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='recovery projection receipt missing';END IF;
 SELECT jsonb_build_object(
  'assets',(SELECT count(*) FROM zasp_inventory_entities WHERE (organization_id,workspace_id,environment_id,state)=(organization_value,workspace_value,environment_value,'active')),
  'findings',(SELECT count(*) FROM zasp_risk_findings WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)),
  'policies',COALESCE((SELECT sum(jsonb_array_length(bundle.policies)) FROM zasp_runtime_gateway_policy_bundles bundle WHERE (bundle.organization_id,bundle.workspace_id,bundle.environment_id)=(organization_value,workspace_value,environment_value) AND NOT EXISTS(SELECT 1 FROM zasp_runtime_gateway_policy_bundles later WHERE (later.organization_id,later.workspace_id,later.environment_id,later.device_id)=(bundle.organization_id,bundle.workspace_id,bundle.environment_id,bundle.device_id) AND later.sequence>bundle.sequence)),0)) INTO counts_value;
 SELECT COALESCE(jsonb_agg(sample.item ORDER BY sample.id),'[]'::jsonb) INTO evidence_samples_value FROM (
  SELECT evidence.id,jsonb_build_object('artifact_key',evidence.artifact_key,'artifact_reference',evidence.artifact_reference,'artifact_version_id',evidence.artifact_version_id,'checksum',encode(evidence.checksum,'hex'),'collected_at',to_char(evidence.collected_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'id',evidence.id,'media_type',evidence.media_type,'object_reference',evidence.object_reference,'schema_version',evidence.schema_version,'size_bytes',evidence.size_bytes) item
  FROM zasp_inventory_evidence evidence WHERE (evidence.organization_id,evidence.workspace_id,evidence.environment_id)=(organization_value,workspace_value,environment_value) ORDER BY evidence.id LIMIT 32
 ) sample;
 WITH integration_ids AS (
  SELECT integration_id FROM zasp_discovery_cursors WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)
  UNION SELECT integration_id FROM zasp_discovery_snapshot_inputs WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)
  UNION SELECT integration_id FROM zasp_discovery_projection_cursors WHERE (organization_id,workspace_id,environment_id)=(organization_value,workspace_value,environment_value)
 ),descriptors AS (SELECT integration_id id,jsonb_build_object(
  'collection_cursors',COALESCE((SELECT jsonb_agg(jsonb_build_object('committed_at',to_char(cursor.committed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'cursor_value',cursor.cursor_value,'provider',cursor.provider,'snapshot_id',cursor.snapshot_id) ORDER BY cursor.provider) FROM zasp_discovery_cursors cursor WHERE (cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id)=(organization_value,workspace_value,environment_value,integration_ids.integration_id)),'[]'::jsonb),
  'integration_id',integration_id,
  'projection_cursors',COALESCE((SELECT jsonb_agg(jsonb_build_object('driver_digest',(SELECT encode(receipt.driver_digest,'hex') FROM zasp_discovery_projection_receipts receipt WHERE (receipt.organization_id,receipt.workspace_id,receipt.environment_id,receipt.integration_id,receipt.source,receipt.kind,receipt.snapshot_id,receipt.generation,receipt.input_digest)=(cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id,cursor.source,cursor.kind,cursor.snapshot_id,cursor.generation,cursor.input_digest) ORDER BY receipt.completed_at DESC,receipt.version DESC LIMIT 1),'generation',cursor.generation,'input_digest',encode(cursor.input_digest,'hex'),'kind',cursor.kind,'snapshot_id',cursor.snapshot_id,'source',cursor.source,'updated_at',to_char(cursor.updated_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) ORDER BY cursor.source,cursor.kind) FROM zasp_discovery_projection_cursors cursor WHERE (cursor.organization_id,cursor.workspace_id,cursor.environment_id,cursor.integration_id)=(organization_value,workspace_value,environment_value,integration_ids.integration_id)),'[]'::jsonb),
  'snapshot_inputs',COALESCE((SELECT jsonb_agg(jsonb_build_object('candidate_digest',encode(input.candidate_digest,'hex'),'generation',input.generation,'manifest_checksum',encode(input.manifest_checksum,'hex'),'manifest_key',input.manifest_key,'manifest_media_type',input.manifest_media_type,'manifest_reference',input.manifest_reference,'manifest_schema_version',input.manifest_schema_version,'manifest_size_bytes',input.manifest_size_bytes,'manifest_version_id',input.manifest_version_id,'parser_version',input.parser_version,'snapshot_id',input.snapshot_id,'source',input.source,'tool_version',input.tool_version) ORDER BY input.source,input.generation) FROM zasp_discovery_snapshot_inputs input WHERE (input.organization_id,input.workspace_id,input.environment_id,input.integration_id)=(organization_value,workspace_value,environment_value,integration_ids.integration_id)),'[]'::jsonb)) item FROM integration_ids)
 SELECT COALESCE(jsonb_agg(item ORDER BY id),'[]'::jsonb) INTO projection_value FROM descriptors;
 RETURN jsonb_build_object('counts',counts_value,'evidence_samples',evidence_samples_value,'projection',projection_value);
END
$validate$;

CREATE FUNCTION public.zasp_recovery_projection_page(organization_value text,workspace_value text,environment_value text,snapshot_value text,section_value text,after_id text,page_limit integer) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $projection_page$
DECLARE input_row zasp_discovery_snapshot_inputs%ROWTYPE;response jsonb;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR section_value NOT IN('entities','relationships','evidence') OR page_limit NOT BETWEEN 1 AND 500 OR after_id IS NOT NULL AND NOT zasp_valid_product_id(after_id) THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery projection page rejected';END IF;
 SELECT * INTO input_row FROM zasp_discovery_snapshot_inputs WHERE (organization_id,workspace_id,environment_id,snapshot_id)=(organization_value,workspace_value,environment_value,snapshot_value);
 IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='P0002',MESSAGE='recovery snapshot input missing';END IF;
 WITH source AS (
  SELECT item_id,payload FROM zasp_discovery_snapshot_projection_items
  WHERE (organization_id,workspace_id,environment_id,snapshot_id,section)=(organization_value,workspace_value,environment_value,snapshot_value,section_value) AND (after_id IS NULL OR item_id>after_id)
  ORDER BY item_id LIMIT page_limit+1
 ),visible AS (SELECT item_id,payload FROM source ORDER BY item_id LIMIT page_limit)
 SELECT jsonb_build_object('snapshot_id',snapshot_value,'integration_id',input_row.integration_id,'source',input_row.source,'generation',input_row.generation,'candidate_digest',encode(input_row.candidate_digest,'hex'),'manifest_reference',input_row.manifest_reference,'manifest_key',input_row.manifest_key,'manifest_version_id',input_row.manifest_version_id,'manifest_checksum',encode(input_row.manifest_checksum,'hex'),'manifest_size_bytes',input_row.manifest_size_bytes,'manifest_media_type',input_row.manifest_media_type,'manifest_schema_version',input_row.manifest_schema_version,'parser_version',input_row.parser_version,'tool_version',input_row.tool_version,'section',section_value,'items',COALESCE(jsonb_agg(payload ORDER BY item_id),'[]'::jsonb),'next_id',CASE WHEN (SELECT count(*) FROM source)>page_limit THEN (SELECT item_id FROM visible ORDER BY item_id DESC LIMIT 1) ELSE NULL END) INTO response FROM visible;
 RETURN response;
END
$projection_page$;

CREATE FUNCTION public.zasp_recovery_finish_backup(organization_value text,workspace_value text,environment_value text,backup_value text,worker_value text,token_value bytea,manifest_value jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $finish$
DECLARE row_value zasp_recovery_backups%ROWTYPE;requested_value bytea;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR jsonb_typeof(manifest_value)<>'object' OR octet_length(manifest_value::text)>8192 OR octet_length(token_value)<>32
  OR (SELECT count(*) FROM jsonb_object_keys(manifest_value))<>8 OR NOT zasp_discovery_s3_object_reference(manifest_value->>'reference') OR substring(manifest_value->>'reference' FROM '^s3://[a-z0-9][a-z0-9.-]{2,62}/(.+)$') IS DISTINCT FROM 'organizations/'||organization_value||'/workspaces/'||workspace_value||'/environments/'||environment_value||'/artifacts/'||substring(manifest_value->>'reference' FROM '/artifacts/([^/]+)$') OR NOT zasp_valid_product_id(substring(manifest_value->>'reference' FROM '/artifacts/([^/]+)$')) OR length(manifest_value->>'version_id') NOT BETWEEN 1 AND 1024 OR manifest_value->>'version_id'<>btrim(manifest_value->>'version_id') OR manifest_value->>'version_id'~'[[:space:][:cntrl:]]'
  OR manifest_value->>'sha256'!~'^[a-f0-9]{64}$' OR NOT (CASE WHEN jsonb_typeof(manifest_value->'size_bytes')='number' AND manifest_value->>'size_bytes'~'^[0-9]+$' THEN (manifest_value->>'size_bytes')::bigint BETWEEN 1 AND 67108864 ELSE false END)
  OR manifest_value->>'media_type'<>'application/vnd.zasp.recovery-manifest+json' OR manifest_value->>'schema'<>'recovery_signed_manifest_v1' OR manifest_value->>'signing_key_id'!~'^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  OR jsonb_typeof(manifest_value->'signature')<>'string' OR length(manifest_value->>'signature') NOT BETWEEN 43 AND 684 THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery backup finish rejected';END IF;requested_value:=decode(manifest_value->>'sha256','hex');
 SELECT * INTO STRICT row_value FROM zasp_recovery_backups WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,backup_value) FOR UPDATE;
 IF row_value.state='succeeded' THEN IF row_value.manifest_digest<>requested_value THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery backup finish conflict';END IF;RETURN jsonb_build_object('manifest_digest',row_value.manifest_digest,'replayed',true,'state','succeeded');END IF;
 IF row_value.state NOT IN('capturing','publishing') OR row_value.worker_id<>worker_value OR row_value.lease_token<>token_value OR row_value.lease_expires_at<=transaction_timestamp() THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery operation lease lost';END IF;
 UPDATE zasp_recovery_holds SET state='released',released_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,operation_id,state)=(organization_value,workspace_value,environment_value,backup_value,'held');
 UPDATE zasp_recovery_backups SET state='succeeded',version=version+1,manifest=manifest_value,manifest_digest=requested_value,error_code=NULL,completed_at=transaction_timestamp(),worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,backup_value);RETURN jsonb_build_object('manifest_digest',requested_value,'replayed',false,'state','succeeded');
END
$finish$;

CREATE FUNCTION public.zasp_recovery_checkpoint_restore(organization_value text,workspace_value text,environment_value text,restore_value text,worker_value text,token_value bytea,expected_state text,next_state text,evidence_value jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $checkpoint$
DECLARE updated integer;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR octet_length(token_value)<>32 OR jsonb_typeof(evidence_value)<>'object' OR (expected_state,next_state) NOT IN(('verifying','provisioning'),('provisioning','validating'),('validating','rebuilding'),('rebuilding','cleanup_required'),('cleanup_required','cleaning')) THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery restore checkpoint rejected';END IF;
 UPDATE zasp_recovery_restores SET state=next_state,version=version+1,validation_evidence=CASE WHEN next_state='rebuilding' THEN evidence_value ELSE validation_evidence END,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,restore_value) AND state=expected_state AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp();GET DIAGNOSTICS updated=ROW_COUNT;
 IF updated<>1 THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery operation lease lost';END IF;RETURN jsonb_build_object('state',next_state);
END
$checkpoint$;

CREATE FUNCTION public.zasp_recovery_finish_restore(organization_value text,workspace_value text,environment_value text,restore_value text,worker_value text,token_value bytea,observed_value jsonb,validation_value jsonb,cleanup_value jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $finish$
DECLARE row_value zasp_recovery_restores%ROWTYPE;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR octet_length(token_value)<>32 OR jsonb_typeof(observed_value)<>'object' OR jsonb_typeof(validation_value)<>'object' OR jsonb_typeof(cleanup_value)<>'object'
  OR (SELECT count(*) FROM jsonb_object_keys(observed_value))<>3 OR NOT observed_value ?& ARRAY['assets','findings','policies'] OR EXISTS(SELECT 1 FROM jsonb_each(observed_value) item WHERE jsonb_typeof(item.value)<>'number' OR item.value::text!~'^[0-9]+$' OR (item.value::text)::numeric>1000000000)
  OR (SELECT count(*) FROM jsonb_object_keys(validation_value))<>4 OR validation_value->>'state'<>'validated' OR validation_value->'expected_counts'<>observed_value OR validation_value->'observed_counts'<>observed_value OR jsonb_typeof(validation_value->'evidence')<>'object'
  OR NOT zasp_recovery_cleanup_evidence_valid(organization_value,workspace_value,environment_value,cleanup_value) OR cleanup_value->>'state'<>'deleted' THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery restore finish rejected';END IF;
 SELECT * INTO STRICT row_value FROM zasp_recovery_restores WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,restore_value) FOR UPDATE;
 IF row_value.state='succeeded' THEN IF row_value.observed_counts<>observed_value OR row_value.validation_evidence<>validation_value OR row_value.cleanup_evidence<>cleanup_value THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery restore finish conflict';END IF;RETURN jsonb_build_object('replayed',true,'state','succeeded');END IF;
 IF row_value.state<>'cleaning' OR row_value.worker_id<>worker_value OR row_value.lease_token<>token_value OR row_value.lease_expires_at<=transaction_timestamp() THEN RAISE EXCEPTION USING ERRCODE='40001',MESSAGE='recovery operation lease lost';END IF;
 UPDATE zasp_recovery_restores SET state='succeeded',version=version+1,observed_counts=observed_value,validation_evidence=validation_value,cleanup_evidence=cleanup_value,error_code=NULL,completed_at=transaction_timestamp(),worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,restore_value);RETURN jsonb_build_object('replayed',false,'state','succeeded');
END
$finish$;

CREATE FUNCTION public.zasp_recovery_fail_operation(kind_value text,organization_value text,workspace_value text,environment_value text,operation_value text,worker_value text,token_value bytea,error_value text,retry_seconds integer,cleanup_value jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO pg_catalog, public AS $fail$
DECLARE attempt_value integer;next_state text;restore_row zasp_recovery_restores%ROWTYPE;
BEGIN
 IF NOT zasp_recovery_principal_ready('zasp_recovery_worker') OR kind_value NOT IN('backup','restore') OR octet_length(token_value)<>32 OR error_value!~'^[a-z][a-z0-9_]{0,63}$' OR retry_seconds NOT BETWEEN 0 AND 86400 OR cleanup_value IS NOT NULL AND NOT zasp_recovery_cleanup_evidence_valid(organization_value,workspace_value,environment_value,cleanup_value) THEN RAISE EXCEPTION USING ERRCODE='22023',MESSAGE='recovery operation failure rejected';END IF;
 IF kind_value='backup' THEN SELECT attempt INTO STRICT attempt_value FROM zasp_recovery_backups WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,operation_value) AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp() FOR UPDATE;next_state:=CASE WHEN attempt_value>=100 OR retry_seconds=0 THEN 'failed' ELSE 'retryable' END;UPDATE zasp_recovery_holds SET state='released',released_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,operation_id,state)=(organization_value,workspace_value,environment_value,operation_value,'held');UPDATE zasp_recovery_backups SET state=next_state,error_code=error_value,available_at=transaction_timestamp()+make_interval(secs=>retry_seconds),completed_at=CASE WHEN next_state='failed' THEN transaction_timestamp() END,worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,backup_id)=(organization_value,workspace_value,environment_value,operation_value);
 ELSE
  SELECT * INTO STRICT restore_row FROM zasp_recovery_restores WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value) AND worker_id=worker_value AND lease_token=token_value AND lease_expires_at>transaction_timestamp() FOR UPDATE;attempt_value:=restore_row.attempt;
  IF cleanup_value IS NULL AND restore_row.state IN('provisioning','validating','rebuilding','cleanup_required','cleaning') AND attempt_value>=100 THEN
   UPDATE zasp_recovery_restores SET cleanup_evidence=NULL,error_code=NULL,available_at=transaction_timestamp()+make_interval(secs=>GREATEST(retry_seconds,1)),completed_at=NULL,lease_expires_at=transaction_timestamp(),updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value);RETURN jsonb_build_object('state','cleanup_pending');
  END IF;
  next_state:=CASE WHEN cleanup_value IS NOT NULL AND cleanup_value->>'state'='failed' THEN 'failed_cleanup' WHEN attempt_value>=100 OR retry_seconds=0 THEN 'failed' ELSE 'retryable' END;
  UPDATE zasp_recovery_restores SET state=next_state,error_code=error_value,cleanup_evidence=cleanup_value,available_at=transaction_timestamp()+make_interval(secs=>retry_seconds),completed_at=CASE WHEN next_state IN('failed','failed_cleanup') THEN transaction_timestamp() END,worker_id=NULL,lease_token=NULL,lease_expires_at=NULL,updated_at=transaction_timestamp() WHERE (organization_id,workspace_id,environment_id,restore_id)=(organization_value,workspace_value,environment_value,operation_value);
 END IF;
 RETURN jsonb_build_object('state',next_state);
END
$fail$;

DO $function_authority$
DECLARE function_value regprocedure;
BEGIN
 FOREACH function_value IN ARRAY ARRAY[
  'public.zasp_recovery_register_principals(text,text,text)'::regprocedure,'public.zasp_recovery_principal_ready(text)'::regprocedure,'public.zasp_recovery_principals_ready()'::regprocedure,'public.zasp_recovery_scope_mutable(text,text,text)'::regprocedure,'public.zasp_recovery_cleanup_evidence_valid(text,text,text,jsonb)'::regprocedure,'public.zasp_recovery_guard_scope_mutation()'::regprocedure,
  'public.zasp_recovery_create_backup(text,text,text,text,text,text,text,integer,text,text,bytea)'::regprocedure,'public.zasp_recovery_create_restore(text,text,text,text,text,text,text,text,text,text,bytea,jsonb,bytea)'::regprocedure,'public.zasp_recovery_get_backup(text,text,text,text)'::regprocedure,'public.zasp_recovery_get_restore(text,text,text,text)'::regprocedure,
  'public.zasp_recovery_claim_outbox(text,text,bytea,integer,integer)'::regprocedure,'public.zasp_recovery_heartbeat_outbox(text,text,bytea,integer,integer)'::regprocedure,'public.zasp_recovery_ack_outbox(text,text,text,text,text,bytea,text)'::regprocedure,'public.zasp_recovery_retry_outbox(text,text,text,text,text,bytea,integer,text)'::regprocedure,
  'public.zasp_recovery_claim_operation(text,text,bytea,integer,integer)'::regprocedure,'public.zasp_recovery_claim_delivery(text,text,text,text,text,text,bytea,integer)'::regprocedure,'public.zasp_recovery_heartbeat_operation(text,text,text,text,text,text,bytea,integer)'::regprocedure,'public.zasp_recovery_begin_hold(text,text,text,text,text,bytea)'::regprocedure,'public.zasp_recovery_release_hold(text,text,text,text,text,bytea)'::regprocedure,'public.zasp_recovery_capture_page(text,text,text,text,text,bytea,text,text,integer)'::regprocedure,'public.zasp_recovery_validate_scope(text,text,text)'::regprocedure,'public.zasp_recovery_projection_page(text,text,text,text,text,text,integer)'::regprocedure,
  'public.zasp_recovery_finish_backup(text,text,text,text,text,bytea,jsonb)'::regprocedure,'public.zasp_recovery_checkpoint_restore(text,text,text,text,text,bytea,text,text,jsonb)'::regprocedure,'public.zasp_recovery_finish_restore(text,text,text,text,text,bytea,jsonb,jsonb,jsonb)'::regprocedure,'public.zasp_recovery_fail_operation(text,text,text,text,text,text,bytea,text,integer,jsonb)'::regprocedure
 ] LOOP EXECUTE format('ALTER FUNCTION %s OWNER TO zasp_discovery_authority',function_value);END LOOP;
END
$function_authority$;

REVOKE ALL ON FUNCTION public.zasp_recovery_register_principals(text,text,text),public.zasp_recovery_principal_ready(text),public.zasp_recovery_principals_ready(),public.zasp_recovery_scope_mutable(text,text,text),public.zasp_recovery_cleanup_evidence_valid(text,text,text,jsonb),public.zasp_recovery_guard_scope_mutation(),public.zasp_recovery_create_backup(text,text,text,text,text,text,text,integer,text,text,bytea),public.zasp_recovery_create_restore(text,text,text,text,text,text,text,text,text,text,bytea,jsonb,bytea),public.zasp_recovery_get_backup(text,text,text,text),public.zasp_recovery_get_restore(text,text,text,text),public.zasp_recovery_claim_outbox(text,text,bytea,integer,integer),public.zasp_recovery_heartbeat_outbox(text,text,bytea,integer,integer),public.zasp_recovery_ack_outbox(text,text,text,text,text,bytea,text),public.zasp_recovery_retry_outbox(text,text,text,text,text,bytea,integer,text),public.zasp_recovery_claim_operation(text,text,bytea,integer,integer),public.zasp_recovery_claim_delivery(text,text,text,text,text,text,bytea,integer),public.zasp_recovery_heartbeat_operation(text,text,text,text,text,text,bytea,integer),public.zasp_recovery_begin_hold(text,text,text,text,text,bytea),public.zasp_recovery_release_hold(text,text,text,text,text,bytea),public.zasp_recovery_capture_page(text,text,text,text,text,bytea,text,text,integer),public.zasp_recovery_validate_scope(text,text,text),public.zasp_recovery_projection_page(text,text,text,text,text,text,integer),public.zasp_recovery_finish_backup(text,text,text,text,text,bytea,jsonb),public.zasp_recovery_checkpoint_restore(text,text,text,text,text,bytea,text,text,jsonb),public.zasp_recovery_finish_restore(text,text,text,text,text,bytea,jsonb,jsonb,jsonb),public.zasp_recovery_fail_operation(text,text,text,text,text,text,bytea,text,integer,jsonb) FROM PUBLIC,zasp_discovery_api,zasp_recovery_worker,zasp_recovery_outbox_worker;
GRANT EXECUTE ON FUNCTION public.zasp_recovery_create_backup(text,text,text,text,text,text,text,integer,text,text,bytea),public.zasp_recovery_create_restore(text,text,text,text,text,text,text,text,text,text,bytea,jsonb,bytea),public.zasp_recovery_get_backup(text,text,text,text),public.zasp_recovery_get_restore(text,text,text,text) TO zasp_discovery_api;
GRANT EXECUTE ON FUNCTION public.zasp_recovery_principal_ready(text),public.zasp_recovery_claim_operation(text,text,bytea,integer,integer),public.zasp_recovery_claim_delivery(text,text,text,text,text,text,bytea,integer),public.zasp_recovery_heartbeat_operation(text,text,text,text,text,text,bytea,integer),public.zasp_recovery_begin_hold(text,text,text,text,text,bytea),public.zasp_recovery_release_hold(text,text,text,text,text,bytea),public.zasp_recovery_capture_page(text,text,text,text,text,bytea,text,text,integer),public.zasp_recovery_validate_scope(text,text,text),public.zasp_recovery_projection_page(text,text,text,text,text,text,integer),public.zasp_recovery_finish_backup(text,text,text,text,text,bytea,jsonb),public.zasp_recovery_checkpoint_restore(text,text,text,text,text,bytea,text,text,jsonb),public.zasp_recovery_finish_restore(text,text,text,text,text,bytea,jsonb,jsonb,jsonb),public.zasp_recovery_fail_operation(text,text,text,text,text,text,bytea,text,integer,jsonb) TO zasp_recovery_worker;
GRANT EXECUTE ON FUNCTION public.zasp_recovery_principal_ready(text),public.zasp_recovery_claim_outbox(text,text,bytea,integer,integer),public.zasp_recovery_heartbeat_outbox(text,text,bytea,integer,integer),public.zasp_recovery_ack_outbox(text,text,text,text,text,bytea,text),public.zasp_recovery_retry_outbox(text,text,text,text,text,bytea,integer,text) TO zasp_recovery_outbox_worker;

CREATE FUNCTION public.zasp_recovery_execution_security_ready() RETURNS boolean LANGUAGE sql STABLE SET search_path TO pg_catalog, public AS $security$
 SELECT zasp_attack_lab_execution_security_ready() AND (SELECT count(*) FROM pg_roles WHERE rolname IN('zasp_recovery_worker','zasp_recovery_outbox_worker'))=2
 AND NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname IN('zasp_recovery_worker','zasp_recovery_outbox_worker') AND (rolsuper OR rolinherit OR rolcanlogin OR rolcreaterole OR rolcreatedb OR rolreplication OR rolbypassrls))
 AND (SELECT count(*) FROM pg_auth_members membership JOIN pg_roles granted ON granted.oid=membership.roleid JOIN pg_roles member ON member.oid=membership.member WHERE granted.rolname IN('zasp_recovery_worker','zasp_recovery_outbox_worker') AND member.rolname='zasp_discovery_authority' AND membership.admin_option)=2
 AND NOT has_table_privilege('zasp_discovery_api','public.zasp_recovery_backups','SELECT') AND NOT has_table_privilege('zasp_recovery_worker','public.zasp_recovery_backups','SELECT') AND NOT has_table_privilege('zasp_recovery_outbox_worker','public.zasp_recovery_outbox','SELECT')
 AND NOT has_function_privilege('zasp_discovery_api','public.zasp_recovery_cleanup_evidence_valid(text,text,text,jsonb)','EXECUTE') AND NOT has_function_privilege('zasp_recovery_worker','public.zasp_recovery_cleanup_evidence_valid(text,text,text,jsonb)','EXECUTE')
 AND has_function_privilege('zasp_discovery_api','public.zasp_recovery_create_backup(text,text,text,text,text,text,text,integer,text,text,bytea)','EXECUTE')
 AND has_function_privilege('zasp_discovery_api','public.zasp_recovery_create_restore(text,text,text,text,text,text,text,text,text,text,bytea,jsonb,bytea)','EXECUTE')
 AND has_function_privilege('zasp_recovery_worker','public.zasp_recovery_claim_operation(text,text,bytea,integer,integer)','EXECUTE')
 AND has_function_privilege('zasp_recovery_worker','public.zasp_recovery_claim_delivery(text,text,text,text,text,text,bytea,integer)','EXECUTE')
 AND has_function_privilege('zasp_recovery_worker','public.zasp_recovery_validate_scope(text,text,text)','EXECUTE')
 AND has_function_privilege('zasp_recovery_worker','public.zasp_recovery_projection_page(text,text,text,text,text,text,integer)','EXECUTE')
 AND NOT has_function_privilege('zasp_discovery_api','public.zasp_recovery_validate_scope(text,text,text)','EXECUTE')
 AND NOT has_function_privilege('zasp_discovery_api','public.zasp_recovery_projection_page(text,text,text,text,text,text,integer)','EXECUTE')
 AND has_function_privilege('zasp_recovery_outbox_worker','public.zasp_recovery_claim_outbox(text,text,bytea,integer,integer)','EXECUTE')
	AND has_function_privilege('zasp_discovery_api','public.zasp_policy_list_runtime_decisions(text,text,text,text,integer)','EXECUTE') AND NOT has_function_privilege('zasp_gateway_control','public.zasp_policy_list_runtime_decisions(text,text,text,text,integer)','EXECUTE')
	AND has_function_privilege('zasp_gateway_control','public.zasp_runtime_gateway_record_event_v27(text,text,bigint,bigint,bytea,bigint,text,text,jsonb,jsonb,timestamptz)','EXECUTE') AND NOT has_function_privilege('zasp_discovery_api','public.zasp_runtime_gateway_record_event_v27(text,text,bigint,bigint,bytea,bigint,text,text,jsonb,jsonb,timestamptz)','EXECUTE')
	AND NOT has_function_privilege('zasp_discovery_api','public.zasp_policy_id_array_valid(jsonb)','EXECUTE') AND NOT has_function_privilege('zasp_gateway_control','public.zasp_policy_id_array_valid(jsonb)','EXECUTE')
	AND (SELECT count(*) FROM pg_index index_value JOIN pg_class index_class ON index_class.oid=index_value.indexrelid JOIN pg_roles owner ON owner.oid=index_class.relowner WHERE index_value.indrelid='public.zasp_runtime_gateway_events'::regclass AND index_class.relname IN('zasp_runtime_gateway_events_policy_ids_v27_idx','zasp_runtime_gateway_events_policy_history_v27_idx') AND index_value.indisvalid AND index_value.indisready AND NOT index_value.indisunique AND NOT index_value.indisprimary AND owner.rolname='zasp_discovery_authority')=2
	AND (SELECT count(*) FROM pg_roles WHERE rolname IN('zasp_discovery_api','zasp_discovery_worker','zasp_security_agent_api','zasp_security_agent_worker','zasp_security_agent_action_worker','zasp_runtime_ingest','zasp_runtime_worker','zasp_outbox_worker','zasp_runtime_gateway','zasp_discovery_scheduler','zasp_projection_risk_worker','zasp_projection_graph_worker','zasp_projection_search_worker','zasp_runtime_coordinator','zasp_runtime_archive_worker','zasp_runtime_index_worker','zasp_runtime_correlation_worker','zasp_runtime_projection_worker','zasp_gateway_control','zasp_red_team_worker','zasp_red_team_outbox_worker','zasp_red_team_adapter','zasp_attack_lab_controller','zasp_attack_lab_outbox_worker','zasp_attack_lab_proxy','zasp_recovery_worker','zasp_recovery_outbox_worker') AND has_function_privilege(rolname,'public.zasp_recovery_execution_readiness(text,text)','EXECUTE'))=27
$security$;

CREATE FUNCTION public.zasp_recovery_execution_live_fingerprint() RETURNS text LANGUAGE sql STABLE SET search_path TO pg_catalog, public AS $fingerprint$
 WITH identities(value) AS (
  SELECT concat_ws('|','prior',zasp_attack_lab_execution_live_fingerprint())
  UNION ALL SELECT concat_ws('|','role',rolname,rolsuper,rolinherit,rolcreaterole,rolcreatedb,rolcanlogin,rolreplication,rolbypassrls) FROM pg_roles WHERE rolname IN('zasp_recovery_worker','zasp_recovery_outbox_worker')
  UNION ALL SELECT concat_ws('|','membership',granted.rolname,member.rolname,membership.admin_option) FROM pg_auth_members membership JOIN pg_roles granted ON granted.oid=membership.roleid JOIN pg_roles member ON member.oid=membership.member WHERE granted.rolname IN('zasp_recovery_worker','zasp_recovery_outbox_worker') AND member.rolname='zasp_discovery_authority'
  UNION ALL SELECT concat_ws('|','table',class.relname,owner.rolname,class.relrowsecurity,class.relforcerowsecurity,COALESCE(class.relacl::text,'')) FROM pg_class class JOIN pg_namespace namespace ON namespace.oid=class.relnamespace JOIN pg_roles owner ON owner.oid=class.relowner WHERE namespace.nspname='public' AND class.relname LIKE 'zasp_recovery_%' AND class.relkind IN('r','i')
  UNION ALL SELECT concat_ws('|','index',class.relname,pg_get_indexdef(class.oid)) FROM pg_class class JOIN pg_namespace namespace ON namespace.oid=class.relnamespace WHERE namespace.nspname='public' AND class.relname LIKE 'zasp_recovery_%' AND class.relkind='i'
  UNION ALL SELECT concat_ws('|','column',class.relname,attribute.attname,attribute.atttypid::regtype::text,attribute.attnotnull,COALESCE(pg_get_expr(default_value.adbin,default_value.adrelid),'')) FROM pg_attribute attribute JOIN pg_class class ON class.oid=attribute.attrelid JOIN pg_namespace namespace ON namespace.oid=class.relnamespace LEFT JOIN pg_attrdef default_value ON default_value.adrelid=attribute.attrelid AND default_value.adnum=attribute.attnum WHERE namespace.nspname='public' AND class.relname LIKE 'zasp_recovery_%' AND attribute.attnum>0 AND NOT attribute.attisdropped
  UNION ALL SELECT concat_ws('|','constraint',class.relname,constraint_value.conname,constraint_value.contype,constraint_value.convalidated,pg_get_constraintdef(constraint_value.oid,true)) FROM pg_constraint constraint_value JOIN pg_class class ON class.oid=constraint_value.conrelid WHERE class.relname LIKE 'zasp_recovery_%'
	UNION ALL SELECT concat_ws('|','runtime_gateway_column',class.relname,attribute.attname,attribute.atttypid::regtype::text,attribute.attnotnull,COALESCE(pg_get_expr(default_value.adbin,default_value.adrelid),'')) FROM pg_attribute attribute JOIN pg_class class ON class.oid=attribute.attrelid JOIN pg_namespace namespace ON namespace.oid=class.relnamespace LEFT JOIN pg_attrdef default_value ON default_value.adrelid=attribute.attrelid AND default_value.adnum=attribute.attnum WHERE namespace.nspname='public' AND class.relname='zasp_runtime_gateway_events' AND attribute.attname='policy_ids' AND NOT attribute.attisdropped
	UNION ALL SELECT concat_ws('|','runtime_gateway_constraint',class.relname,constraint_value.conname,constraint_value.contype,constraint_value.convalidated,pg_get_constraintdef(constraint_value.oid,true)) FROM pg_constraint constraint_value JOIN pg_class class ON class.oid=constraint_value.conrelid WHERE class.relname='zasp_runtime_gateway_events' AND constraint_value.conname='zasp_runtime_gateway_events_policy_ids_v27_ck'
	UNION ALL SELECT concat_ws('|','runtime_gateway_index',index_class.relname,owner.rolname,index_value.indisvalid,index_value.indisready,index_value.indisunique,index_value.indisprimary,pg_get_indexdef(index_value.indexrelid)) FROM pg_index index_value JOIN pg_class index_class ON index_class.oid=index_value.indexrelid JOIN pg_roles owner ON owner.oid=index_class.relowner WHERE index_value.indrelid='public.zasp_runtime_gateway_events'::regclass AND index_class.relname IN('zasp_runtime_gateway_events_policy_ids_v27_idx','zasp_runtime_gateway_events_policy_history_v27_idx')
  UNION ALL SELECT concat_ws('|','policy',class.relname,policy.polname,policy.polpermissive,pg_get_expr(policy.polqual,policy.polrelid),pg_get_expr(policy.polwithcheck,policy.polrelid)) FROM pg_policy policy JOIN pg_class class ON class.oid=policy.polrelid WHERE class.relname LIKE 'zasp_recovery_%'
  UNION ALL SELECT concat_ws('|','trigger',class.relname,trigger.tgname,pg_get_triggerdef(trigger.oid,true)) FROM pg_trigger trigger JOIN pg_class class ON class.oid=trigger.tgrelid JOIN pg_namespace namespace ON namespace.oid=class.relnamespace WHERE namespace.nspname='public' AND trigger.tgname LIKE '%_recovery_hold' AND NOT trigger.tgisinternal
  UNION ALL SELECT concat_ws('|','function',procedure.proname,pg_get_function_identity_arguments(procedure.oid),owner.rolname,procedure.prosecdef,COALESCE(procedure.proconfig::text,''),COALESCE(procedure.proacl::text,''),pg_get_functiondef(procedure.oid)) FROM pg_proc procedure JOIN pg_namespace namespace ON namespace.oid=procedure.pronamespace JOIN pg_roles owner ON owner.oid=procedure.proowner WHERE namespace.nspname='public' AND (procedure.proname LIKE 'zasp_recovery_%' OR procedure.proname IN('zasp_policy_id_array_valid','zasp_runtime_gateway_record_event_v27','zasp_policy_list_runtime_decisions'))
 ) SELECT encode(digest(convert_to(string_agg(value,E'\n' ORDER BY value),'UTF8'),'sha256'),'hex') FROM identities
$fingerprint$;

CREATE FUNCTION public.zasp_recovery_execution_readiness(expected_checksum text,expected_fingerprint text) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO pg_catalog, public AS $readiness$
 SELECT length(expected_checksum)=64 AND expected_checksum~'^[a-f0-9]{64}$' AND length(expected_fingerprint)=64 AND expected_fingerprint~'^[a-f0-9]{64}$'
 AND EXISTS(SELECT 1 FROM zasp_schema_versions WHERE version=27 AND name='production_recovery' AND checksum=expected_checksum)
 AND EXISTS(SELECT 1 FROM zasp_schema_metadata WHERE key='production_core_schema' AND value='production-recovery-v1') AND NOT EXISTS(SELECT 1 FROM zasp_schema_versions WHERE version>27)
 AND zasp_recovery_execution_security_ready() AND zasp_recovery_execution_live_fingerprint()=expected_fingerprint
$readiness$;

ALTER FUNCTION public.zasp_recovery_execution_security_ready() OWNER TO zasp_discovery_authority;ALTER FUNCTION public.zasp_recovery_execution_live_fingerprint() OWNER TO zasp_discovery_authority;ALTER FUNCTION public.zasp_recovery_execution_readiness(text,text) OWNER TO zasp_discovery_authority;
REVOKE ALL ON FUNCTION public.zasp_recovery_execution_security_ready(),public.zasp_recovery_execution_live_fingerprint(),public.zasp_recovery_execution_readiness(text,text) FROM PUBLIC,zasp_discovery_api,zasp_discovery_worker,zasp_security_agent_api,zasp_security_agent_worker,zasp_security_agent_action_worker,zasp_runtime_ingest,zasp_runtime_worker,zasp_outbox_worker,zasp_runtime_gateway,zasp_discovery_scheduler,zasp_projection_risk_worker,zasp_projection_graph_worker,zasp_projection_search_worker,zasp_runtime_coordinator,zasp_runtime_archive_worker,zasp_runtime_index_worker,zasp_runtime_correlation_worker,zasp_runtime_projection_worker,zasp_gateway_control,zasp_red_team_worker,zasp_red_team_outbox_worker,zasp_red_team_adapter,zasp_attack_lab_controller,zasp_attack_lab_outbox_worker,zasp_attack_lab_proxy,zasp_recovery_worker,zasp_recovery_outbox_worker;
GRANT EXECUTE ON FUNCTION public.zasp_recovery_execution_readiness(text,text) TO zasp_discovery_api,zasp_security_agent_api,zasp_recovery_worker,zasp_recovery_outbox_worker,zasp_discovery_worker,zasp_security_agent_worker,zasp_security_agent_action_worker,zasp_runtime_ingest,zasp_runtime_worker,zasp_outbox_worker,zasp_runtime_gateway,zasp_discovery_scheduler,zasp_projection_risk_worker,zasp_projection_graph_worker,zasp_projection_search_worker,zasp_runtime_coordinator,zasp_runtime_archive_worker,zasp_runtime_index_worker,zasp_runtime_correlation_worker,zasp_runtime_projection_worker,zasp_gateway_control,zasp_red_team_worker,zasp_red_team_outbox_worker,zasp_red_team_adapter,zasp_attack_lab_controller,zasp_attack_lab_outbox_worker,zasp_attack_lab_proxy;

DO $product_release_evolution$
DECLARE definition text;original_definition text;
BEGIN
 SELECT pg_get_functiondef('public.zasp_workflow_mutate(text,text,text,text,text,text,text,text,text,bigint,jsonb,jsonb,text,text,text)'::regprocedure) INTO STRICT definition;original_definition:=definition;definition:=replace(definition,'attack-lab-execution-v1','production-recovery-v1');definition:=replace(definition,'release."version" = 26','release."version" = 27');definition:=replace(definition,'release."name" = ''attack_lab_execution''','release."name" = ''production_recovery''');definition:=replace(definition,'later_release."version" > 26','later_release."version" > 27');IF definition=original_definition OR position('production-recovery-v1' IN definition)=0 THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='workflow v27 compatibility evolution failed';END IF;EXECUTE definition;
 SELECT pg_get_functiondef('public.zasp_risk_mutate(text,text,text,text,text,text,text,bigint,text,text,text,text,text)'::regprocedure) INTO STRICT definition;original_definition:=definition;definition:=replace(definition,'attack-lab-execution-v1','production-recovery-v1');definition:=replace(replace(definition,'release."version"=26','release."version"=27'),'release."version" = 26','release."version" = 27');definition:=replace(replace(definition,'release."name"=''attack_lab_execution''','release."name"=''production_recovery'''),'release."name" = ''attack_lab_execution''','release."name" = ''production_recovery''');definition:=replace(replace(definition,'later."version">26','later."version">27'),'later."version" > 26','later."version" > 27');IF definition=original_definition OR position('production-recovery-v1' IN definition)=0 THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='risk v27 compatibility evolution failed';END IF;EXECUTE definition;
END
$product_release_evolution$;

UPDATE public.zasp_schema_metadata SET value='production-recovery-v1',applied_at=transaction_timestamp() WHERE key='production_core_schema' AND value='attack-lab-execution-v1';
INSERT INTO public.zasp_schema_metadata(key,value) VALUES('production_recovery_fingerprint', '12487d82d24fd4de68fc595e57306a085cc237218597c039f90477ce1ba7f364') ON CONFLICT(key) DO UPDATE SET value=excluded.value;
