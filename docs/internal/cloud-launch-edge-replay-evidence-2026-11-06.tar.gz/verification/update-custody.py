from pathlib import Path
import json,hashlib,re,subprocess
root=Path('/workspace/zasp-sec');work=Path('/tmp/nov06-launch');manifest=root/'.github/connector-native-compile-source-pins.json';old=manifest.read_bytes();data=json.loads(old);assert len(data['sources'])==927
sources=['deploy/staging/product/templates/edge.yaml','services/platform/apiserver/retention_native_postgres_test.go','scripts/implementation-status-check.mjs','scripts/implementation-status-check.test.mjs'];runners=['scripts/hosted-connected-connector-acceptance.mjs','scripts/hosted-connector-authenticated-enqueue.mjs']
def sha(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
(work/'source-pins-before.json').write_bytes(old)
for p in runners:
 text=(root/p).read_text();(work/(Path(p).name+'.before')).write_text(text);m=re.search(r'const pins = (\{.*?\n\});',text,re.S);pins=json.loads(m[1])
 for name in sources:assert name in pins;pins[name]=sha(name)
 (root/p).write_text(text[:m.start(1)]+json.dumps(pins,indent=2)+text[m.end(1):])
changed=[]
for item in data['sources']:
 p=item['path']
 if sha(p)!=item['sha256']:
  assert p in sources+runners,p
  changed.append({'path':p,'beforeSHA256':item['sha256'],'afterSHA256':sha(p)});item['sha256']=sha(p);item['bytes']=(root/p).stat().st_size
assert len(changed)==6,len(changed)
data['edgeScopeReplaySourceAssociationBase']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();data['edgeScopeReplayPredecessorManifestSHA256']=hashlib.sha256(old).hexdigest();manifest.write_text(json.dumps(data,indent=2)+'\n')
prior=json.loads(old);assert [x['path'] for x in prior['sources']]==[x['path'] for x in data['sources']]
for a,b in zip(prior['sources'],data['sources']):assert all(a[k]==b[k] for k in a if k not in ['sha256','bytes'])
for x in data['sources']:assert sha(x['path'])==x['sha256'] and (root/x['path']).stat().st_size==x['bytes']
pattern=re.compile(r'''["']([^"'\n]+)["']\s*:\s*["']([0-9a-f]{64})["']''');count=0
for p in (root/'scripts').rglob('*'):
 if p.suffix not in ['.mjs','.json'] or not p.is_file():continue
 for path,pin in pattern.findall(p.read_text()):
  if (root/path).is_file():assert sha(path)==pin,(str(p),path);count+=1
assert count==1826,count
(work/'custody-verification.json').write_text(json.dumps({'bindings':927,'all_hashes_bytes_match':True,'paths_order_preimage_fields_preserved':True,'all_current_script_associations_match':True,'current_script_associations':count,'changed':changed},indent=2)+'\n');print('927manifest and1826script associations verified')
