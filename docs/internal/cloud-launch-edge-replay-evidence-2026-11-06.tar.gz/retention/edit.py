from pathlib import Path
p=Path('services/platform/apiserver/retention_native_postgres_test.go')
s=p.read_text();s=s.replace('\t"fmt"\n','\t"fmt"\n\t"net/http"\n\t"net/http/httptest"\n\t"net/url"\n',1)
anchor='\tdeployment := authorization.IdentityDeployment{PublicOrigin: "https://console.example", ProviderBaseURL: "https://test.stytch.com", ProjectID: "project-test-retention-native", ConfiguredOrganization: "organization-retention-native", Mode: "saas"}'
replacement='''	// The later freshness-required policy mutation uses the actual verified
	// provider/native issue path. This owned server is not deployed Stytch proof.
	providerServer := httptest.NewServer(http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
		response.Header().Set("Content-Type", "application/json")
		project, secret, ok := request.BasicAuth()
		var input map[string]any
		if !ok || project != "project-test-retention-native" || secret != "secret-fixture-only" || json.NewDecoder(request.Body).Decode(&input) != nil {
			response.WriteHeader(http.StatusUnauthorized)
			return
		}
		switch request.URL.Path {
		case "/v1/b2b/oauth/authenticate":
			if input["oauth_token"] != "retention-reauth" {
				response.WriteHeader(http.StatusUnauthorized)
				return
			}
			_ = json.NewEncoder(response).Encode(map[string]any{"status_code": 200, "session_jwt": "header.retention.signature"})
		case "/v1/b2b/sessions/authenticate":
			if input["session_jwt"] != "header.retention.signature" {
				response.WriteHeader(http.StatusUnauthorized)
				return
			}
			now := time.Now().UTC().Truncate(time.Second)
			_ = json.NewEncoder(response).Encode(map[string]any{"status_code": 200, "member_session": map[string]any{"member_session_id": "member-session-retention-native", "member_id": "member-retention-native", "organization_id": "organization-retention-native", "started_at": now.Format(time.RFC3339), "last_accessed_at": now.Format(time.RFC3339), "expires_at": now.Add(time.Hour).Format(time.RFC3339)}, "member": map[string]any{"member_id": "member-retention-native", "organization_id": "organization-retention-native"}})
		default:
			response.WriteHeader(http.StatusNotFound)
		}
	}))
	t.Cleanup(providerServer.Close)
	deployment := authorization.IdentityDeployment{PublicOrigin: "https://console.example", ProviderBaseURL: providerServer.URL, ProjectID: "project-test-retention-native", ConfiguredOrganization: "organization-retention-native", Mode: "saas"}'''
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
anchor='\tconst otherEnv = "pid_98000001-0000-4000-8000-000000000001"'
replacement=anchor+'''
	otherEnvironment, err := domain.ParseProductID(otherEnv)
	if err != nil {
		t.Fatal(err)
	}
	otherScope, err := domain.NewScope(scope.OrganizationID(), scope.WorkspaceID(), otherEnvironment)
	if err != nil {
		t.Fatal(err)
	}
	sessionToken := "retention-native-session-credential-v1"'''
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
anchor="\texec(`INSERT INTO zasp_authorized_scopes(principal_id,organization_id,workspace_id,environment_id,label,permissions,is_default) VALUES($1,$2,$3,$4,'A','[]',true)`, actor, o, w, e)"
replacement="\texec(`INSERT INTO zasp_authorized_scopes(principal_id,organization_id,workspace_id,environment_id,label,permissions,is_default) VALUES($1,$2,$3,$4,'A','[]',true),($1,$2,$3,$5,'B','[]',false)`, actor, o, w, e, otherEnv)"
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
anchor="VALUES(digest('retention-native-session','sha256'),'session-retention-native',$1,$2,$3,$4,'[]',repeat('x',32),clock_timestamp(),clock_timestamp()+interval '1 hour')`, actor, o, w, e)"
assert s.count(anchor)==1;s=s.replace(anchor,"VALUES(digest($5,'sha256'),'session-retention-native',$1,$2,$3,$4,'[]',repeat('x',32),clock_timestamp(),clock_timestamp()+interval '1 hour')`, actor, o, w, e, sessionToken)")
s=s.replace('Value: "retention-native-session"','Value: sessionToken')
anchor='\tpoolCfg, err := pgxpool.ParseConfig(cfg.ConnString())'
replacement='''	auth, err := NewStytchOAuthAuthenticator(providerServer.URL, deployment.ProjectID, "secret-fixture-only", time.Second, func() time.Time { return time.Now().UTC().Truncate(time.Millisecond) })
	if err != nil {
		t.Fatal(err)
	}
	provider, err := NewRepositoryIdentityProviderWithStart(auth, repo, repo, providerServer.URL+"/v1/b2b/public/oauth/google/start", "public-token-fixture", deployment.ConfiguredOrganization, deployment.PublicOrigin+"/auth/callback")
	if err != nil || provider.RequireNativeIdentity(seed, deployment) != nil {
		t.Fatal("owned native identity provider refused")
	}
	switchScope := func(t *testing.T, target domain.Scope) {
		t.Helper()
		previous := identity
		updated, err := repo.SwitchScope(ctx, previous, sessionToken, target)
		if err != nil || updated.Scope != target || updated.PrincipalID != previous.PrincipalID || updated.CSRFToken != previous.CSRFToken || updated.CredentialKind != CredentialBrowserSession || len(updated.Permissions) != 0 {
			t.Fatal("checked retention session scope switch refused")
		}
		identity = updated
	}
	reauthenticate := func(t *testing.T) {
		t.Helper()
		target, err := provider.Start(ctx, "/discovery/assets")
		if err != nil {
			t.Fatal("owned native reauthentication start refused")
		}
		start, parseErr := url.Parse(target)
		if parseErr != nil {
			t.Fatal("owned native identity start malformed")
		}
		callback, parseErr := url.Parse(start.Query().Get("login_redirect_url"))
		if parseErr != nil {
			t.Fatal("owned native identity callback malformed")
		}
		grant, err := provider.Complete(ctx, "retention-reauth", callback.Query().Get("state"))
		if err != nil {
			t.Fatal("owned verified reauthentication refused")
		}
		freshToken, err := repo.CreateSession(ctx, grant)
		if err != nil {
			t.Fatal("owned native fresh session issue refused")
		}
		fresh, err := repo.Authenticate(ctx, Credential{Kind: CredentialBrowserSession, Value: freshToken})
		if err != nil || fresh.Scope != scope || fresh.PrincipalID != identity.PrincipalID || !fresh.FreshAuthenticated || !fresh.FreshAuthExpiresAt.After(time.Now()) || len(fresh.Permissions) != 0 {
			t.Fatal("owned native fresh session authentication refused")
		}
		identity, sessionToken = fresh, freshToken
	}
'''+anchor
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
anchor="\t\texec(`UPDATE zasp_product_sessions SET environment_id=$1 WHERE session_id='session-retention-native'`, otherEnv)"
assert s.count(anchor)==1;s=s.replace(anchor,'\t\tswitchScope(t, otherScope)')
anchor="\t\texec(`UPDATE zasp_product_sessions SET environment_id=$1,authenticated_at=clock_timestamp() WHERE session_id='session-retention-native'`, e)"
assert s.count(anchor)==1;s=s.replace(anchor,'\t\tswitchScope(t, scope)')
anchor='\tt.Run("audited_policy_expiry_and_idempotent_cycle", func(t *testing.T) {\n\t\treconcile()'
assert s.count(anchor)==1;s=s.replace(anchor,'\tt.Run("audited_policy_expiry_and_idempotent_cycle", func(t *testing.T) {\n\t\treauthenticate(t)\n\t\treconcile()')
p.write_text(s)
