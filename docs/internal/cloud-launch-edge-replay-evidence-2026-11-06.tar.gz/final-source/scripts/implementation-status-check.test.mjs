import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import { validateLedger } from "./implementation-status-check.mjs";

const repositoryRoot = path.resolve(import.meta.dirname, "..");
const sourcePlanPath = path.join(
  repositoryRoot,
  "docs/internal/agent_security_platform_Technical_Implementation_Plan_v1.5.md",
);
const canonicalLedgerPath = path.join(
  repositoryRoot,
  "docs/internal/implementation_production_availability_v1.5.tsv",
);
const canonicalStatusPath = path.join(
  repositoryRoot,
  "docs/internal/implementation_status_v1.5.md",
);

test("M7A-16 full policy contract cannot gain production credit from Block-only history", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const row = ledger.split("\n").find((line) => line.startsWith("M7A\tM7A-16\t"))?.split("\t");
  assert.equal(row?.[2], "Complete", "preserve the historical execution record");
  assert.equal(row?.[3], "component-only", "original typed Monitor/Block contract is not fully implemented");
  await withLedger((value) => value.replace("M7A\tM7A-16\tComplete\tcomponent-only\t", "M7A\tM7A-16\tComplete\tproduction-available\t"), async (ledgerPath) => {
    await assert.rejects(() => validateLedger({ ledgerPath, sourcePlanPath }), /production class production-available does not match audited component-only for M7A-16/);
  });
});

test("M7A-25 full finding contract cannot gain production credit from status-only history", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const row = ledger.split("\n").find((line) => line.startsWith("M7A\tM7A-25\t"))?.split("\t");
  assert.equal(row?.[2], "Complete", "preserve the historical execution record");
  assert.equal(row?.[3], "component-only", "full assignment/status-note review and deployed proof remain open");
  await withLedger((value) => value.replace("M7A\tM7A-25\tComplete\tcomponent-only\t", "M7A\tM7A-25\tComplete\tproduction-available\t"), async (ledgerPath) => {
    await assert.rejects(() => validateLedger({ ledgerPath, sourcePlanPath }), /production class production-available does not match audited component-only for M7A-25/);
  });
});

test("M2-46b environment class selection cannot gain production credit from name-only onboarding", async () => {
  await withLedger((ledger) => ledger.replace(
    /M2\tM2-46b\tComplete\t(?:component-only|production-available)\t/,
    "M2\tM2-46b\tComplete\tproduction-available\t",
  ), async (ledgerPath) => {
    await assert.rejects(
      () => validateLedger({ ledgerPath, sourcePlanPath }),
      /production class production-available does not match audited component-only for M2-46b/,
    );
  });
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const row = ledger.split("\n").find((line) => line.startsWith("M2\tM2-46b\t"))?.split("\t");
  assert.equal(row?.[2], "Complete", "preserve the historical execution record");
  assert.equal(row?.[3], "component-only", "name-only requests do not save the selected environment class");
  assert.equal(row?.[4], "T11-identity-admin");
});

async function withLedger(mutator, assertion) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "zasp-ledger-"));
  const ledgerPath = path.join(directory, "ledger.tsv");

  try {
    const canonicalLedger = await readFile(canonicalLedgerPath, "utf8");
    await writeFile(ledgerPath, mutator(canonicalLedger), "utf8");
    await assertion(ledgerPath);
  } finally {
    await rm(directory, { force: true, recursive: true });
  }
}

async function withLedgerAndStatus(ledgerMutator, statusMutator, assertion) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "zasp-ledger-"));
  const ledgerPath = path.join(directory, "ledger.tsv");
  const statusPath = path.join(directory, "status.md");

  try {
    const [canonicalLedger, canonicalStatus] = await Promise.all([
      readFile(canonicalLedgerPath, "utf8"),
      readFile(canonicalStatusPath, "utf8"),
    ]);
    await Promise.all([
      writeFile(ledgerPath, ledgerMutator(canonicalLedger), "utf8"),
      writeFile(statusPath, statusMutator(canonicalStatus), "utf8"),
    ]);
    await assertion({ ledgerPath, statusPath });
  } finally {
    await rm(directory, { force: true, recursive: true });
  }
}

function rows(ledger) {
  return ledger.trimEnd().split("\n");
}

test("canonical ledger, owner map and documentation satisfy every audited count", async () => {
  await validateLedger({ ledgerPath: canonicalLedgerPath, sourcePlanPath, statusPath: canonicalStatusPath });
});

test("group mapping update cannot regain production credit while its mounted acceptance is open", async () => {
  await withLedger(
    (ledger) => ledger.replace(
      "M2\tM2-33\tComplete\tcomponent-only\t",
      "M2\tM2-33\tComplete\tproduction-available\t",
    ),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /production class production-available does not match audited component-only for M2-33/,
      );
    },
  );
});

test("seed-backed compliance assembly and read routes remain component-only until current sources are mounted", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  for (const id of ["M7-09", "M7-10", "M7-11"]) {
    const row = rows(ledger).map((line) => line.split("\t")).find((columns) => columns[1] === id);
    assert.ok(row, `${id} must remain tracked`);
    assert.equal(row[3], "component-only", `${id} lacks mounted current-source authority`);
    assert.equal(row[4], "T14-data-workflows");
  }
});

test("both-framework mapping and control list remain component-only while HIPAA mappings are unmounted", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  for (const id of ["M7-08", "M7-15a"]) {
    const row = rows(ledger).map((line) => line.split("\t")).find((columns) => columns[1] === id);
    assert.ok(row, `${id} must remain tracked`);
    assert.equal(row[3], "component-only", `${id} requires both SOC 2 Security and HIPAA mappings`);
    assert.equal(row[4], "T14-data-workflows");
  }
});

test("M1-33 cannot regain production credit before original queue proof and publication", async () => {
  await withLedger((ledger) => {
    const expected = "M1\tM1-33\tComplete\tcomponent-only\tT04-discovery-worker\t";
    assert.ok(ledger.includes(expected), "preserve the audited M1-33 class, owner and historical state");
    return ledger.replace(expected, "M1\tM1-33\tComplete\tproduction-available\tT04-discovery-worker\t");
  }, async (ledgerPath) => {
    await assert.rejects(
      () => validateLedger({ ledgerPath, sourcePlanPath }),
      /production class production-available does not match audited component-only for M1-33/,
    );
  });
});

test("Audit Log original gates keep M7-36 component-only despite historical Complete", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const row = rows(ledger).find((value) => value.startsWith("M7\tM7-36\t"))?.split("\t");
  assert.equal(row?.[2], "Complete", "preserve the historical execution ledger");
  assert.equal(row?.[3], "component-only", "filters, export action and actual SSO/config/policy/test mutation E2E remain required");
});

test("M8-47 keeps historical completion but requires real scanner evidence for production credit", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const row = rows(ledger).find((value) => value.startsWith("M8\tM8-47\t"))?.split("\t");
  assert.equal(row?.[2], "Complete", "preserve the historical policy-fixture record");
  assert.equal(row?.[3], "component-only", "offline zero counters do not prove advisory lookup or release blocking");
  assert.equal(row?.[4], "T15-deployment", "the actual release boundary owns scanner remediation");
});

test("M7A-49 cannot regain production credit from in-memory budget fixtures", async () => {
  await withLedger((ledger) => rows(ledger).map((line) => {
    const fields = line.split("\t");
    if (fields[1] === "M7A-49") fields[3] = "production-available";
    return fields.join("\t");
  }).join("\n") + "\n", async (ledgerPath) => {
    await assert.rejects(
      () => validateLedger({ ledgerPath, sourcePlanPath }),
      /production class production-available does not match audited component-only for M7A-49/,
    );
  });
});

test("M8-47 cannot regain production credit from offline-zero or policy fixtures", async () => {
  await withLedger((ledger) => rows(ledger).map((row) => {
    const fields = row.split("\t");
    if (fields[1] === "M8-47") fields[3] = "production-available";
    return fields.join("\t");
  }).join("\n") + "\n", async (ledgerPath) => {
    await assert.rejects(
      () => validateLedger({ ledgerPath, sourcePlanPath }),
      /production class production-available does not match audited component-only for M8-47/,
    );
  });
});

test("Audit Log cannot regain production credit from partial API or component evidence", async () => {
  await withLedger((ledger) => rows(ledger).map((row) => {
    const fields = row.split("\t");
    if (fields[1] === "M7-36") fields[3] = "production-available";
    return fields.join("\t");
  }).join("\n") + "\n", async (ledgerPath) => {
    await assert.rejects(
      () => validateLedger({ ledgerPath, sourcePlanPath }),
      /production class production-available does not match audited component-only for M7-36/,
    );
  });
});

test("mixed runtime session acceptance records its verified release evidence", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const row = rows(ledger).find((value) => value.startsWith("M7\tM7-07\t"));
  assert.ok(row?.includes("\tproduction-available\tT14-data-workflows\t"));
  for (const evidence of ["PR47", "c6aec68d", "34634275277", "2026-09-11-worker-mixed-evidence.md"]) assert.ok(row.includes(evidence), evidence);
});

test("lineage and ambiguity acceptance records controlled fixtures and verified main publication", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  for (const id of ["M3-46", "M3-47"]) {
    const row = rows(ledger).find((value) => value.startsWith(`M3\t${id}\t`));
    assert.ok(row?.includes("\tproduction-available\tT04-discovery-worker\t"), id + " requires its reviewed original criterion");
    for (const evidence of ["PR49", "fda8ae99921be468b3d95f2369f54112a725e046", "34687750130", "controlled", "2026-09-11-precision-provider-evidence.md", "not live deployment"]) assert.ok(row.includes(evidence), id + ": " + evidence);
    assert.ok(row.includes(id === "M3-46" ? "Strong, not Exact" : "Probable/Unattributed, never Exact"));
  }
});

test("verified runtime lineage and ambiguity acceptance cannot silently lose production credit", async () => {
  for (const id of ["M3-46", "M3-47"]) {
    await withLedger((ledger) => {
      const expected = `M3\t${id}\tComplete\tproduction-available\t`;
      assert.ok(ledger.includes(expected), `${id} acceptance was not recorded`);
      return ledger.replace(expected, `M3\t${id}\tComplete\tcomponent-only\t`);
    }, async (ledgerPath) => {
      await assert.rejects(() => validateLedger({ ledgerPath, sourcePlanPath }), new RegExp(`audited production-available for ${id}`));
    });
  }
});

test("shipped runtime session acceptance cannot silently lose production credit", async () => {
  for (const id of ["M7-01", "M7-02", "M7-03", "M7-04", "M7-05", "M7-06", "M7-07a", "M7-07b", "M7-07c", "M7-07"]) {
    await withLedger((ledger) => {
      const expected = `M7\t${id}\tComplete\tproduction-available\t`;
      assert.ok(ledger.includes(expected), `${id} acceptance was not recorded`);
      return ledger.replace(expected, `M7\t${id}\tComplete\tcomponent-only\t`);
    }, async (ledgerPath) => {
      await assert.rejects(() => validateLedger({ ledgerPath, sourcePlanPath }), /audited production-available/);
    });
  }
});

test("rejects a ledger missing a source-plan task", async () => {
  await withLedger(
    (ledger) => rows(ledger).filter((_, index) => index !== 1).join("\n") + "\n",
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /missing source-plan IDs: M0-01/,
      );
    },
  );
});

test("rejects a duplicated source-plan task", async () => {
  await withLedger(
    (ledger) => {
      const ledgerRows = rows(ledger);
      return `${ledgerRows.join("\n")}\n${ledgerRows[1]}\n`;
    },
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /duplicate IDs: M0-01/,
      );
    },
  );
});

test("rejects an unknown source-plan task", async () => {
  await withLedger(
    (ledger) => ledger.replace("\tM0-01\t", "\tM0-999\t"),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /unknown IDs: M0-999/,
      );
    },
  );
});

test("rejects an invalid production class", async () => {
  await withLedger(
    (ledger) => ledger.replace("\tcomponent-only\t", "\tready\t"),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /invalid production class "ready"/,
      );
    },
  );
});

test("rejects a production class paired with the wrong historical state", async () => {
  await withLedger(
    (ledger) => ledger.replace("M1\tM1-01d\tComplete\tproduction-available", "M1\tM1-01d\tBlocked\tproduction-available"),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /production-available requires Complete historical status for M1-01d/,
      );
    },
  );
});

test("rejects a grouped production owner for component-only work", async () => {
  await withLedger(
    (ledger) => ledger.replace(
      "M1\tM1-01c\tComplete\tcomponent-only\tT10-product-ui",
      "M1\tM1-01c\tComplete\tcomponent-only\tTasks 2-9 production promotion",
    ),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /component-only requires one concrete owner task ID for M1-01c/,
      );
    },
  );
});

test("rejects an external row without an approved typed gate ID", async () => {
  await withLedger(
    (ledger) => ledger.replace("EXT-live-aws", "EXT-live-aws-other"),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /blocked\/external requires an approved typed gate ID for M0-09/,
      );
    },
  );
});

test("rejects an approved but wrong production owner for a source ID", async () => {
  await withLedger(
    (ledger) => ledger.replace("M2\tM2-20\tComplete\tproduction-available\tT11-identity-admin", "M2\tM2-20\tComplete\tproduction-available\tT02-discovery-authority"),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /owner T02-discovery-authority does not match expected owner T11-identity-admin for M2-20/,
      );
    },
  );
});

test("rejects audited production-class count drift", async () => {
  await withLedger(
    (ledger) => {
      const mutated = ledger.replace("\tproduction-available\t", "\tcomponent-only\t");
      assert.notEqual(mutated, ledger, "count-drift fixture must change a current production row");
      return mutated;
    },
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /production-available count is 502; expected 503/,
      );
    },
  );
});

test("artifact, outcome and Fargate-create acceptance cannot silently lose production credit", async () => {
  for (const id of ["M5-02", "M5-14", "M5-18", "M5-16", "M5-17", "M5-19", "M5-20", "M5-21", "M5-22"]) {
    await withLedger((ledger) => {
      const expected = `M5\t${id}\tComplete\tproduction-available\t`;
      assert.ok(ledger.includes(expected), `${id} acceptance was not recorded`);
      return ledger.replace(expected, `M5\t${id}\tComplete\tcomponent-only\t`);
    }, async (ledgerPath) => {
      await assert.rejects(() => validateLedger({ ledgerPath, sourcePlanPath }), new RegExp(`production-available.*${id}|${id}.*production-available`));
    });
  }
});

test("rejects a cross-milestone class swap that preserves global totals", async () => {
  await withLedger(
    (ledger) => ledger
      .replace(
        "M1\tM1-01c\tComplete\tcomponent-only\tT10-product-ui",
        "M1\tM1-01c\tComplete\tproduction-available\tT10-product-ui",
      )
      .replace(
        "M2\tM2-01\tComplete\tproduction-available\tPROD-current-composition",
        "M2\tM2-01\tComplete\tcomponent-only\tT11-identity-admin",
      ),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /M1 production-available count is 58; expected 57/,
      );
    },
  );
});

test("rejects a same-owner same-milestone audited class swap", async () => {
  await withLedger(
    (ledger) => ledger
      .replace(
        "M1\tM1-01e\tComplete\tproduction-available\tT04-discovery-worker",
        "M1\tM1-01e\tComplete\tcomponent-only\tT04-discovery-worker",
      )
      .replace(
        "M1\tM1-01b\tComplete\tcomponent-only\tT04-discovery-worker",
        "M1\tM1-01b\tComplete\tproduction-available\tT04-discovery-worker",
      ),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /production class component-only does not match audited production-available for M1-01e/,
      );
    },
  );
});

test("rejects demotion of the shipped finding ticket and final M4 gate", async () => {
  for (const id of ["M4-38", "M4-39", "M4-59"]) {
    await withLedger(
      (ledger) => ledger.replace(
        new RegExp(`(M4\\t${id}\\tComplete\\t)production-available`),
        "$1component-only",
      ),
      async (ledgerPath) => {
        await assert.rejects(
          () => validateLedger({ ledgerPath, sourcePlanPath }),
          new RegExp(`production class component-only does not match audited production-available for ${id}`),
        );
      },
    );
  }
});

test("rejects demotion of audited shipped identity administration tasks", async () => {
  for (const id of [
    "M2-20", "M2-21", "M2-22", "M2-23", "M2-24",
    "M2-25", "M2-26", "M2-27", "M2-28", "M2-29", "M2-30",
    "M2-31", "M2-32", "M2-43c", "M2-43d", "M2-43e",
    "M2-47a", "M2-47b",
  ]) {
    await withLedger(
      (ledger) => ledger.replace(
        new RegExp(`(M2\\t${id}\\tComplete\\t)production-available`),
        "$1component-only",
      ),
      async (ledgerPath) => {
        await assert.rejects(
          () => validateLedger({ ledgerPath, sourcePlanPath }),
          new RegExp(`production class component-only does not match audited production-available for ${id}`),
        );
      },
    );
  }
});

test("rejects demotion of audited shipped deployment tasks", async () => {
  for (const id of [
    "M8-09a", "M8-09b", "M8-09c", "M8-09", "M8-11", "M8-12", "M8-13", ]) {
    await withLedger(
      (ledger) => ledger.replace(
        new RegExp(`(M8\\t${id}\\tComplete\\t)production-available`),
        "$1missing",
      ),
      async (ledgerPath) => {
        await assert.rejects(
          () => validateLedger({ ledgerPath, sourcePlanPath }),
          new RegExp(`production class missing does not match audited production-available for ${id}`),
        );
      },
    );
  }
});

test("rejects demotion of audited shipped recovery tasks", async () => {
  for (const id of [
    "M8-20a", "M8-20b", "M8-20c", "M8-20",
    "M8-21a", "M8-21b", "M8-21c", "M8-21d", "M8-21e", "M8-21",
  ]) {
    await withLedger(
      (ledger) => ledger.replace(
        new RegExp(`(M8\\t${id}\\tComplete\\t)production-available`),
        "$1component-only",
      ),
      async (ledgerPath) => {
        await assert.rejects(
          () => validateLedger({ ledgerPath, sourcePlanPath }),
          new RegExp(`production class component-only does not match audited production-available for ${id}`),
        );
      },
    );
  }
});

test("rejects demotion of audited durable gateway tasks", async () => {
  for (const [milestone, id] of [["M1", "M1-01a"], ["M6", "M6-31e"]]) {
    await withLedger(
      (ledger) => ledger.replace(
        new RegExp(`(${milestone}\\t${id}\\tComplete\\t)production-available`),
        "$1component-only",
      ),
      async (ledgerPath) => {
        await assert.rejects(
          () => validateLedger({ ledgerPath, sourcePlanPath }),
          new RegExp(`production class component-only does not match audited production-available for ${id}`),
        );
      },
    );
  }
});

test("rejects demotion of production-composed policy history operations", async () => {
  for (const id of ["M6-13", "M6-16", "M6-17"]) {
    await withLedger(
      (ledger) => ledger.replace(
        new RegExp(`(M6\\t${id}\\tComplete\\t)production-available`),
        "$1component-only",
      ),
      async (ledgerPath) => {
        await assert.rejects(
          () => validateLedger({ ledgerPath, sourcePlanPath }),
          new RegExp(`production class component-only does not match audited production-available for ${id}`),
        );
      },
    );
  }
});

test("rejects demotion of the production signed webhook setup task", async () => {
  await withLedger(
    (ledger) => ledger.replace("M3\tM3-48h\tComplete\tproduction-available", "M3\tM3-48h\tComplete\tcomponent-only"),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /production class component-only does not match audited production-available for M3-48h/,
      );
    },
  );
});

test("rejects demotion of the verified runtime queue/archive/index task", async () => {
  await withLedger(
    (ledger) => ledger.replace("M3\tM3-52d\tComplete\tproduction-available", "M3\tM3-52d\tComplete\tcomponent-only"),
    async (ledgerPath) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath }),
        /production class component-only does not match audited production-available for M3-52d/,
      );
    },
  );
});

test("rejects demotion of individually accepted Red Team domain, APIs, worker and UI",async()=>{
  for(const id of ["M5-01","M5-03","M5-04","M5-05","M5-06","M5-07","M5-08","M5-09","M5-10","M5-11","M5-12","M5-13","M5-15"]){
    await withLedger(ledger=>ledger.replace(`M5\t${id}\tComplete\tproduction-available`,`M5\t${id}\tComplete\tcomponent-only`),async ledgerPath=>{
      await assert.rejects(()=>validateLedger({ledgerPath,sourcePlanPath}),new RegExp(`production class component-only does not match audited production-available for ${id}`));
    });
  }
});

test("rejects a published milestone matrix that drifts from the audited map", async () => {
  await withLedgerAndStatus(
    (ledger) => ledger,
    (status) => {
      const expected = "| M1 | 68 | 57 | 11 | 0 | 0 |";
      assert.ok(status.includes(expected), "matrix-drift fixture must match the current M1 row");
      return status.replace(expected, "| M1 | 68 | 58 | 10 | 0 | 0 |");
    },
    async ({ ledgerPath, statusPath }) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath, statusPath }),
        /documentation matrix does not match audited milestone counts/,
      );
    },
  );
});

test("rejects a published availability summary that drifts from the audited ledger", async () => {
  await withLedgerAndStatus(
    (ledger) => ledger,
    (status) => {
      const expected = "| Production-available | 503 |";
      assert.ok(status.includes(expected), "summary-drift fixture must match the current total");
      return status.replace(expected, "| Production-available | 496 |");
    },
    async ({ ledgerPath, statusPath }) => {
      await assert.rejects(
        () => validateLedger({ ledgerPath, sourcePlanPath, statusPath }),
        /documentation summary does not match audited class counts/,
      );
    },
  );
});

test("Original Agents requirements cannot gain production credit from historical composition or component checks", async (t) => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const owners = await readFile(path.join(repositoryRoot, "docs/internal/implementation_production_availability_owners_v1.5.tsv"), "utf8");
  for (const id of ["M4-50a", "M4-50b1", "M4-50b2", "M4-50b3", "M4-50c", "M4-50"]) await t.test(id, async () => {
    const original = ledger.split("\n").find((line) => line.split("\t")[1] === id);
    assert.ok(original);
    const row = original.split("\t");
    assert.equal(row[2], "Complete", "retain the historical execution record");
    assert.equal(row[3], "component-only", "source gaps and missing deployed acceptance prohibit production credit");
    assert.equal(row[4], "T10-product-ui");
    assert.ok(owners.split("\n").includes(`${id}\tT10-product-ui`));
    assert.ok(row[5].startsWith("audited shipped composition:"), "retain prior evidence before its explicit correction");
    const directory = await mkdtemp(path.join(os.tmpdir(), "agents-availability-"));
    try {
      const promoted = [...row]; promoted[3] = "production-available";
      const altered = path.join(directory, "ledger.tsv");
      const balanced = ledger.replace(original, promoted.join("\t")).replace("M4\tM4-51\tComplete\tproduction-available\t", "M4\tM4-51\tComplete\tcomponent-only\t");
      assert.notEqual(balanced, ledger.replace(original, promoted.join("\t")), "retain milestone totals while challenging per-task admission");
      await writeFile(altered, balanced);
      await assert.rejects(validateLedger({ ledgerPath: altered }), new RegExp(`production class production-available does not match audited component-only for ${id}`));
    } finally { await rm(directory, { recursive: true, force: true }); }
  });
});


test("Original health requirements cannot gain production credit from contradictory required dependency classification", async (t) => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const owners = await readFile(path.join(repositoryRoot, "docs/internal/implementation_production_availability_owners_v1.5.tsv"), "utf8");
  for (const id of ["M7-29", "M7-30", "M7-40d"]) await t.test(id, async () => {
    const original = ledger.split("\n").find((line) => line.split("\t")[1] === id);
    assert.ok(original);
    const row = original.split("\t");
    assert.equal(row[2], "Complete", "retain historical execution status");
    assert.equal(row[3], "component-only", "source contradiction and unverified repair prohibit production credit");
    assert.equal(row[4], "T14-data-workflows");
    assert.ok(owners.split("\n").includes(`${id}\tT14-data-workflows`));
    assert.ok(row[5].startsWith("audited shipped composition:"));
    const directory = await mkdtemp(path.join(os.tmpdir(), "health-availability-"));
    try {
      const promoted = [...row]; promoted[3] = "production-available";
      const altered = path.join(directory, "ledger.tsv");
      const balanced = ledger.replace(original, promoted.join("\t")).replace("M7\tM7-31\tComplete\tproduction-available\t", "M7\tM7-31\tComplete\tcomponent-only\t");
      assert.notEqual(balanced, ledger.replace(original, promoted.join("\t")));
      await writeFile(altered, balanced);
      await assert.rejects(validateLedger({ ledgerPath: altered }), new RegExp(`production class production-available does not match audited component-only for ${id}`));
    } finally { await rm(directory, { recursive: true, force: true }); }
  });
});


test("Original Agent API contracts cannot gain production credit from rejected current authorization paths", async (t) => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  const owners = await readFile(path.join(repositoryRoot, "docs/internal/implementation_production_availability_owners_v1.5.tsv"), "utf8");
  for (const id of ["M4-04", "M4-05", "M4-06", "M4-07", "M4-08"]) await t.test(id, async () => {
    const original = ledger.split("\n").find((line) => line.split("\t")[1] === id);
    assert.ok(original);
    const row = original.split("\t");
    assert.equal(row[2], "Complete", "retain historical execution status");
    assert.equal(row[3], "component-only", "source refusal and unverified repair prohibit production credit");
    assert.equal(row[4], "T05-inventory-cutover");
    assert.ok(owners.split("\n").includes(`${id}\tT05-inventory-cutover`));
    assert.ok(row[5].startsWith("audited shipped composition:"));
    const directory = await mkdtemp(path.join(os.tmpdir(), "agent-read-availability-"));
    try {
      const promoted = [...row]; promoted[3] = "production-available";
      const altered = path.join(directory, "ledger.tsv");
      const balanced = ledger.replace(original, promoted.join("\t")).replace("M4\tM4-51\tComplete\tproduction-available\t", "M4\tM4-51\tComplete\tcomponent-only\t");
      assert.notEqual(balanced, ledger.replace(original, promoted.join("\t")));
      await writeFile(altered, balanced);
      await assert.rejects(validateLedger({ ledgerPath: altered }), new RegExp(`production class production-available does not match audited component-only for ${id}`));
    } finally { await rm(directory, { recursive: true, force: true }); }
  });
});

test("customer-edge composition retains component status until current render and deployed acceptance", async () => {
  const ledger = await readFile(canonicalLedgerPath, "utf8");
  for (const id of ["M8-10", "M8-14", "M8-57a", "M8-57b", "M8-57c", "M8-57"]) {
    const row = ledger.trimEnd().split("\n").map(line => line.split("\t")).find(columns => columns[1] === id);
    assert.equal(row?.[3], "component-only", `${id} requires the supported customer-edge render`);
    await withLedger(value => value.replace(`M8\t${id}\tComplete\tcomponent-only\t`, `M8\t${id}\tComplete\tproduction-available\t`), async ledgerPath => {
      await assert.rejects(() => validateLedger({ ledgerPath, sourcePlanPath }), new RegExp(`production class production-available does not match audited component-only for ${id}`));
    });
    await withLedger(value => value.replace(`M8\t${id}\tComplete\tcomponent-only\t`, `M8\t${id}\tComplete\tmissing\t`), async ledgerPath => {
      await assert.rejects(() => validateLedger({ ledgerPath, sourcePlanPath }), new RegExp(`production class missing does not match audited component-only for ${id}`));
    });
  }
});
